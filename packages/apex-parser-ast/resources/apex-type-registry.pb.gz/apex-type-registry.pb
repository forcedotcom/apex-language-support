
2026-04-17T19:29:32.419Z@cc5b1bed73b4b2b54f40f0b2d0dce59bbcfc50d56c52c8144cc42d0afb9efa54�
apexpages.actionAction	ApexPages *Mapexlib://resources/StandardApexLibrary/ApexPages/Action.cls#ApexPages.Action2<apexlib://resources/StandardApexLibrary/ApexPages/Action.cls8�
apexpages.component	Component	ApexPages *Sapexlib://resources/StandardApexLibrary/ApexPages/Component.cls#ApexPages.Component2?apexlib://resources/StandardApexLibrary/ApexPages/Component.cls8�
 apexpages.ideastandardcontrollerIdeaStandardController	ApexPages *mapexlib://resources/StandardApexLibrary/ApexPages/IdeaStandardController.cls#ApexPages.IdeaStandardController2Lapexlib://resources/StandardApexLibrary/ApexPages/IdeaStandardController.cls8�
#apexpages.ideastandardsetcontrollerIdeaStandardSetController	ApexPages *sapexlib://resources/StandardApexLibrary/ApexPages/IdeaStandardSetController.cls#ApexPages.IdeaStandardSetController2Oapexlib://resources/StandardApexLibrary/ApexPages/IdeaStandardSetController.cls8�
3apexpages.knowledgearticleversionstandardcontroller)KnowledgeArticleVersionStandardController	ApexPages *�apexlib://resources/StandardApexLibrary/ApexPages/KnowledgeArticleVersionStandardController.cls#ApexPages.KnowledgeArticleVersionStandardController2_apexlib://resources/StandardApexLibrary/ApexPages/KnowledgeArticleVersionStandardController.cls8�
apexpages.messageMessage	ApexPages *Oapexlib://resources/StandardApexLibrary/ApexPages/Message.cls#ApexPages.Message2=apexlib://resources/StandardApexLibrary/ApexPages/Message.cls8�
apexpages.standardcontrollerStandardController	ApexPages *eapexlib://resources/StandardApexLibrary/ApexPages/StandardController.cls#ApexPages.StandardController2Hapexlib://resources/StandardApexLibrary/ApexPages/StandardController.cls8�
apexpages.standardsetcontrollerStandardSetController	ApexPages *kapexlib://resources/StandardApexLibrary/ApexPages/StandardSetController.cls#ApexPages.StandardSetController2Kapexlib://resources/StandardApexLibrary/ApexPages/StandardSetController.cls8�
applauncher.appmenuAppMenuAppLauncher *Sapexlib://resources/StandardApexLibrary/AppLauncher/AppMenu.cls#AppLauncher.AppMenu2?apexlib://resources/StandardApexLibrary/AppLauncher/AppMenu.cls8�
approval.lockresult
LockResultApproval *Sapexlib://resources/StandardApexLibrary/Approval/LockResult.cls#Approval.LockResult2?apexlib://resources/StandardApexLibrary/Approval/LockResult.cls8�
approval.processrequestProcessRequestApproval *[apexlib://resources/StandardApexLibrary/Approval/ProcessRequest.cls#Approval.ProcessRequest2Capexlib://resources/StandardApexLibrary/Approval/ProcessRequest.cls8�
approval.processresultProcessResultApproval *Yapexlib://resources/StandardApexLibrary/Approval/ProcessResult.cls#Approval.ProcessResult2Bapexlib://resources/StandardApexLibrary/Approval/ProcessResult.cls8�
approval.processsubmitrequestProcessSubmitRequestApproval *gapexlib://resources/StandardApexLibrary/Approval/ProcessSubmitRequest.cls#Approval.ProcessSubmitRequest2Iapexlib://resources/StandardApexLibrary/Approval/ProcessSubmitRequest.cls8�
approval.processworkitemrequestProcessWorkitemRequestApproval *kapexlib://resources/StandardApexLibrary/Approval/ProcessWorkitemRequest.cls#Approval.ProcessWorkitemRequest2Kapexlib://resources/StandardApexLibrary/Approval/ProcessWorkitemRequest.cls8�
approval.unlockresultUnlockResultApproval *Wapexlib://resources/StandardApexLibrary/Approval/UnlockResult.cls#Approval.UnlockResult2Aapexlib://resources/StandardApexLibrary/Approval/UnlockResult.cls8�
auth.authconfigurationAuthConfigurationAuth *Yapexlib://resources/StandardApexLibrary/Auth/AuthConfiguration.cls#Auth.AuthConfiguration2Bapexlib://resources/StandardApexLibrary/Auth/AuthConfiguration.cls8�
auth.authprovidercallbackstateAuthProviderCallbackStateAuth *iapexlib://resources/StandardApexLibrary/Auth/AuthProviderCallbackState.cls#Auth.AuthProviderCallbackState2Japexlib://resources/StandardApexLibrary/Auth/AuthProviderCallbackState.cls8�
auth.authproviderpluginAuthProviderPluginAuth *[apexlib://resources/StandardApexLibrary/Auth/AuthProviderPlugin.cls#Auth.AuthProviderPlugin2Capexlib://resources/StandardApexLibrary/Auth/AuthProviderPlugin.cls8�
auth.authproviderpluginclassAuthProviderPluginClassAuth *eapexlib://resources/StandardApexLibrary/Auth/AuthProviderPluginClass.cls#Auth.AuthProviderPluginClass2Hapexlib://resources/StandardApexLibrary/Auth/AuthProviderPluginClass.cls8�
 auth.authproviderpluginexceptionAuthProviderPluginExceptionAuth *mapexlib://resources/StandardApexLibrary/Auth/AuthProviderPluginException.cls#Auth.AuthProviderPluginException2Lapexlib://resources/StandardApexLibrary/Auth/AuthProviderPluginException.cls8�
auth.authprovidertokenresponseAuthProviderTokenResponseAuth *iapexlib://resources/StandardApexLibrary/Auth/AuthProviderTokenResponse.cls#Auth.AuthProviderTokenResponse2Japexlib://resources/StandardApexLibrary/Auth/AuthProviderTokenResponse.cls8�
auth.authtoken	AuthTokenAuth *Iapexlib://resources/StandardApexLibrary/Auth/AuthToken.cls#Auth.AuthToken2:apexlib://resources/StandardApexLibrary/Auth/AuthToken.cls8�
auth.communitiesutilCommunitiesUtilAuth *Uapexlib://resources/StandardApexLibrary/Auth/CommunitiesUtil.cls#Auth.CommunitiesUtil2@apexlib://resources/StandardApexLibrary/Auth/CommunitiesUtil.cls8�
auth.configurableselfreghandlerConfigurableSelfRegHandlerAuth *kapexlib://resources/StandardApexLibrary/Auth/ConfigurableSelfRegHandler.cls#Auth.ConfigurableSelfRegHandler2Kapexlib://resources/StandardApexLibrary/Auth/ConfigurableSelfRegHandler.cls8�
#auth.confirmuserregistrationhandlerConfirmUserRegistrationHandlerAuth *sapexlib://resources/StandardApexLibrary/Auth/ConfirmUserRegistrationHandler.cls#Auth.ConfirmUserRegistrationHandler2Oapexlib://resources/StandardApexLibrary/Auth/ConfirmUserRegistrationHandler.cls8�
auth.connectedapppluginConnectedAppPluginAuth *[apexlib://resources/StandardApexLibrary/Auth/ConnectedAppPlugin.cls#Auth.ConnectedAppPlugin2Capexlib://resources/StandardApexLibrary/Auth/ConnectedAppPlugin.cls8�
 auth.connectedapppluginexceptionConnectedAppPluginExceptionAuth *mapexlib://resources/StandardApexLibrary/Auth/ConnectedAppPluginException.cls#Auth.ConnectedAppPluginException2Lapexlib://resources/StandardApexLibrary/Auth/ConnectedAppPluginException.cls8�
)auth.customonetimepassworddeliveryhandler$CustomOneTimePasswordDeliveryHandlerAuth *apexlib://resources/StandardApexLibrary/Auth/CustomOneTimePasswordDeliveryHandler.cls#Auth.CustomOneTimePasswordDeliveryHandler2Uapexlib://resources/StandardApexLibrary/Auth/CustomOneTimePasswordDeliveryHandler.cls8�
(auth.customonetimepassworddeliveryresult#CustomOneTimePasswordDeliveryResultAuth *}apexlib://resources/StandardApexLibrary/Auth/CustomOneTimePasswordDeliveryResult.cls#Auth.CustomOneTimePasswordDeliveryResult2Tapexlib://resources/StandardApexLibrary/Auth/CustomOneTimePasswordDeliveryResult.cls8�
"auth.discoverycustomerrorexceptionDiscoveryCustomErrorExceptionAuth *qapexlib://resources/StandardApexLibrary/Auth/DiscoveryCustomErrorException.cls#Auth.DiscoveryCustomErrorException2Napexlib://resources/StandardApexLibrary/Auth/DiscoveryCustomErrorException.cls8�
"auth.externalclientappoauthhandlerExternalClientAppOauthHandlerAuth *qapexlib://resources/StandardApexLibrary/Auth/ExternalClientAppOauthHandler.cls#Auth.ExternalClientAppOauthHandler2Napexlib://resources/StandardApexLibrary/Auth/ExternalClientAppOauthHandler.cls8�
auth.generateduserdataGeneratedUserDataAuth *Yapexlib://resources/StandardApexLibrary/Auth/GeneratedUserData.cls#Auth.GeneratedUserData2Bapexlib://resources/StandardApexLibrary/Auth/GeneratedUserData.cls8�
$auth.headlessselfregistrationhandlerHeadlessSelfRegistrationHandlerAuth *uapexlib://resources/StandardApexLibrary/Auth/HeadlessSelfRegistrationHandler.cls#Auth.HeadlessSelfRegistrationHandler2Papexlib://resources/StandardApexLibrary/Auth/HeadlessSelfRegistrationHandler.cls8�
!auth.headlessuserdiscoveryhandlerHeadlessUserDiscoveryHandlerAuth *oapexlib://resources/StandardApexLibrary/Auth/HeadlessUserDiscoveryHandler.cls#Auth.HeadlessUserDiscoveryHandler2Mapexlib://resources/StandardApexLibrary/Auth/HeadlessUserDiscoveryHandler.cls8�
"auth.headlessuserdiscoveryresponseHeadlessUserDiscoveryResponseAuth *qapexlib://resources/StandardApexLibrary/Auth/HeadlessUserDiscoveryResponse.cls#Auth.HeadlessUserDiscoveryResponse2Napexlib://resources/StandardApexLibrary/Auth/HeadlessUserDiscoveryResponse.cls8�
auth.httpcalloutmockutilHttpCalloutMockUtilAuth *]apexlib://resources/StandardApexLibrary/Auth/HttpCalloutMockUtil.cls#Auth.HttpCalloutMockUtil2Dapexlib://resources/StandardApexLibrary/Auth/HttpCalloutMockUtil.cls8�
auth.integratingapptypeIntegratingAppTypeAuth *[apexlib://resources/StandardApexLibrary/Auth/IntegratingAppType.cls#Auth.IntegratingAppType2Capexlib://resources/StandardApexLibrary/Auth/IntegratingAppType.cls8�
auth.invocationcontextInvocationContextAuth *Yapexlib://resources/StandardApexLibrary/Auth/InvocationContext.cls#Auth.InvocationContext2Bapexlib://resources/StandardApexLibrary/Auth/InvocationContext.cls8�
auth.jwsJWSAuth *=apexlib://resources/StandardApexLibrary/Auth/JWS.cls#Auth.JWS24apexlib://resources/StandardApexLibrary/Auth/JWS.cls8�
auth.jwtJWTAuth *=apexlib://resources/StandardApexLibrary/Auth/JWT.cls#Auth.JWT24apexlib://resources/StandardApexLibrary/Auth/JWT.cls8�
auth.jwtbearertokenexchangeJWTBearerTokenExchangeAuth *capexlib://resources/StandardApexLibrary/Auth/JWTBearerTokenExchange.cls#Auth.JWTBearerTokenExchange2Gapexlib://resources/StandardApexLibrary/Auth/JWTBearerTokenExchange.cls8�
auth.jwtutilJWTUtilAuth *Eapexlib://resources/StandardApexLibrary/Auth/JWTUtil.cls#Auth.JWTUtil28apexlib://resources/StandardApexLibrary/Auth/JWTUtil.cls8�
auth.jsonvalueoutputJsonValueOutputAuth *Uapexlib://resources/StandardApexLibrary/Auth/JsonValueOutput.cls#Auth.JsonValueOutput2@apexlib://resources/StandardApexLibrary/Auth/JsonValueOutput.cls8�
auth.lightninglogineligibilityLightningLoginEligibilityAuth *iapexlib://resources/StandardApexLibrary/Auth/LightningLoginEligibility.cls#Auth.LightningLoginEligibility2Japexlib://resources/StandardApexLibrary/Auth/LightningLoginEligibility.cls8�
auth.logindiscoveryexceptionLoginDiscoveryExceptionAuth *eapexlib://resources/StandardApexLibrary/Auth/LoginDiscoveryException.cls#Auth.LoginDiscoveryException2Hapexlib://resources/StandardApexLibrary/Auth/LoginDiscoveryException.cls8�
auth.logindiscoveryhandlerLoginDiscoveryHandlerAuth *aapexlib://resources/StandardApexLibrary/Auth/LoginDiscoveryHandler.cls#Auth.LoginDiscoveryHandler2Fapexlib://resources/StandardApexLibrary/Auth/LoginDiscoveryHandler.cls8�
auth.logindiscoverymethodLoginDiscoveryMethodAuth *_apexlib://resources/StandardApexLibrary/Auth/LoginDiscoveryMethod.cls#Auth.LoginDiscoveryMethod2Eapexlib://resources/StandardApexLibrary/Auth/LoginDiscoveryMethod.cls8�
"auth.mydomainlogindiscoveryhandlerMyDomainLoginDiscoveryHandlerAuth *qapexlib://resources/StandardApexLibrary/Auth/MyDomainLoginDiscoveryHandler.cls#Auth.MyDomainLoginDiscoveryHandler2Napexlib://resources/StandardApexLibrary/Auth/MyDomainLoginDiscoveryHandler.cls8�
auth.oauth2tokenexchangetypeOAuth2TokenExchangeTypeAuth *eapexlib://resources/StandardApexLibrary/Auth/OAuth2TokenExchangeType.cls#Auth.OAuth2TokenExchangeType2Hapexlib://resources/StandardApexLibrary/Auth/OAuth2TokenExchangeType.cls8�
auth.oauthrefreshresultOAuthRefreshResultAuth *[apexlib://resources/StandardApexLibrary/Auth/OAuthRefreshResult.cls#Auth.OAuthRefreshResult2Capexlib://resources/StandardApexLibrary/Auth/OAuthRefreshResult.cls8�
auth.oauth2tokenexchangehandlerOauth2TokenExchangeHandlerAuth *kapexlib://resources/StandardApexLibrary/Auth/Oauth2TokenExchangeHandler.cls#Auth.Oauth2TokenExchangeHandler2Kapexlib://resources/StandardApexLibrary/Auth/Oauth2TokenExchangeHandler.cls8�
auth.oauthtoken
OauthTokenAuth *Kapexlib://resources/StandardApexLibrary/Auth/OauthToken.cls#Auth.OauthToken2;apexlib://resources/StandardApexLibrary/Auth/OauthToken.cls8�
auth.oauthtokentypeOauthTokenTypeAuth *Sapexlib://resources/StandardApexLibrary/Auth/OauthTokenType.cls#Auth.OauthTokenType2?apexlib://resources/StandardApexLibrary/Auth/OauthTokenType.cls8�
auth.registrationhandlerRegistrationHandlerAuth *]apexlib://resources/StandardApexLibrary/Auth/RegistrationHandler.cls#Auth.RegistrationHandler2Dapexlib://resources/StandardApexLibrary/Auth/RegistrationHandler.cls8�
auth.samljithandlerSamlJitHandlerAuth *Sapexlib://resources/StandardApexLibrary/Auth/SamlJitHandler.cls#Auth.SamlJitHandler2?apexlib://resources/StandardApexLibrary/Auth/SamlJitHandler.cls8�
auth.sessionlevelSessionLevelAuth *Oapexlib://resources/StandardApexLibrary/Auth/SessionLevel.cls#Auth.SessionLevel2=apexlib://resources/StandardApexLibrary/Auth/SessionLevel.cls8�
auth.sessionmanagementSessionManagementAuth *Yapexlib://resources/StandardApexLibrary/Auth/SessionManagement.cls#Auth.SessionManagement2Bapexlib://resources/StandardApexLibrary/Auth/SessionManagement.cls8�
auth.tokenvalidationresultTokenValidationResultAuth *aapexlib://resources/StandardApexLibrary/Auth/TokenValidationResult.cls#Auth.TokenValidationResult2Fapexlib://resources/StandardApexLibrary/Auth/TokenValidationResult.cls8�
auth.userdataUserDataAuth *Gapexlib://resources/StandardApexLibrary/Auth/UserData.cls#Auth.UserData29apexlib://resources/StandardApexLibrary/Auth/UserData.cls8�
auth.verificationactionVerificationActionAuth *[apexlib://resources/StandardApexLibrary/Auth/VerificationAction.cls#Auth.VerificationAction2Capexlib://resources/StandardApexLibrary/Auth/VerificationAction.cls8�
auth.verificationexceptionVerificationExceptionAuth *aapexlib://resources/StandardApexLibrary/Auth/VerificationException.cls#Auth.VerificationException2Fapexlib://resources/StandardApexLibrary/Auth/VerificationException.cls8�
auth.verificationmethodVerificationMethodAuth *[apexlib://resources/StandardApexLibrary/Auth/VerificationMethod.cls#Auth.VerificationMethod2Capexlib://resources/StandardApexLibrary/Auth/VerificationMethod.cls8�
auth.verificationpolicyVerificationPolicyAuth *[apexlib://resources/StandardApexLibrary/Auth/VerificationPolicy.cls#Auth.VerificationPolicy2Capexlib://resources/StandardApexLibrary/Auth/VerificationPolicy.cls8�
auth.verificationresultVerificationResultAuth *[apexlib://resources/StandardApexLibrary/Auth/VerificationResult.cls#Auth.VerificationResult2Capexlib://resources/StandardApexLibrary/Auth/VerificationResult.cls8�
cache.cachebuilderCacheBuilderCache *Qapexlib://resources/StandardApexLibrary/Cache/CacheBuilder.cls#Cache.CacheBuilder2>apexlib://resources/StandardApexLibrary/Cache/CacheBuilder.cls8�
$cache.cachebuilderexecutionexceptionCacheBuilderExecutionExceptionCache *uapexlib://resources/StandardApexLibrary/Cache/CacheBuilderExecutionException.cls#Cache.CacheBuilderExecutionException2Papexlib://resources/StandardApexLibrary/Cache/CacheBuilderExecutionException.cls8�
"cache.invalidcachebuilderexceptionInvalidCacheBuilderExceptionCache *qapexlib://resources/StandardApexLibrary/Cache/InvalidCacheBuilderException.cls#Cache.InvalidCacheBuilderException2Napexlib://resources/StandardApexLibrary/Cache/InvalidCacheBuilderException.cls8�
cache.invalidparamexceptionInvalidParamExceptionCache *capexlib://resources/StandardApexLibrary/Cache/InvalidParamException.cls#Cache.InvalidParamException2Gapexlib://resources/StandardApexLibrary/Cache/InvalidParamException.cls8�
$cache.itemsizelimitexceededexceptionItemSizeLimitExceededExceptionCache *uapexlib://resources/StandardApexLibrary/Cache/ItemSizeLimitExceededException.cls#Cache.ItemSizeLimitExceededException2Papexlib://resources/StandardApexLibrary/Cache/ItemSizeLimitExceededException.cls8�
	cache.orgOrgCache *?apexlib://resources/StandardApexLibrary/Cache/Org.cls#Cache.Org25apexlib://resources/StandardApexLibrary/Cache/Org.cls8�
cache.orgpartitionOrgPartitionCache *Qapexlib://resources/StandardApexLibrary/Cache/OrgPartition.cls#Cache.OrgPartition2>apexlib://resources/StandardApexLibrary/Cache/OrgPartition.cls8�
cache.partition	PartitionCache *Kapexlib://resources/StandardApexLibrary/Cache/Partition.cls#Cache.Partition2;apexlib://resources/StandardApexLibrary/Cache/Partition.cls8�
,cache.platformcacheinvalidoperationexception&PlatformCacheInvalidOperationExceptionCache *�apexlib://resources/StandardApexLibrary/Cache/PlatformCacheInvalidOperationException.cls#Cache.PlatformCacheInvalidOperationException2Xapexlib://resources/StandardApexLibrary/Cache/PlatformCacheInvalidOperationException.cls8�
cache.sessionSessionCache *Gapexlib://resources/StandardApexLibrary/Cache/Session.cls#Cache.Session29apexlib://resources/StandardApexLibrary/Cache/Session.cls8�
cache.sessionpartitionSessionPartitionCache *Yapexlib://resources/StandardApexLibrary/Cache/SessionPartition.cls#Cache.SessionPartition2Bapexlib://resources/StandardApexLibrary/Cache/SessionPartition.cls8�
cache.visibility
VisibilityCache *Mapexlib://resources/StandardApexLibrary/Cache/Visibility.cls#Cache.Visibility2<apexlib://resources/StandardApexLibrary/Cache/Visibility.cls8�
canvas.applicationcontextApplicationContextCanvas *_apexlib://resources/StandardApexLibrary/Canvas/ApplicationContext.cls#Canvas.ApplicationContext2Eapexlib://resources/StandardApexLibrary/Canvas/ApplicationContext.cls8�
canvas.canvaslifecyclehandlerCanvasLifecycleHandlerCanvas *gapexlib://resources/StandardApexLibrary/Canvas/CanvasLifecycleHandler.cls#Canvas.CanvasLifecycleHandler2Iapexlib://resources/StandardApexLibrary/Canvas/CanvasLifecycleHandler.cls8�
canvas.canvasrenderexceptionCanvasRenderExceptionCanvas *eapexlib://resources/StandardApexLibrary/Canvas/CanvasRenderException.cls#Canvas.CanvasRenderException2Hapexlib://resources/StandardApexLibrary/Canvas/CanvasRenderException.cls8�
canvas.contexttypeenumContextTypeEnumCanvas *Yapexlib://resources/StandardApexLibrary/Canvas/ContextTypeEnum.cls#Canvas.ContextTypeEnum2Bapexlib://resources/StandardApexLibrary/Canvas/ContextTypeEnum.cls8�
canvas.environmentcontextEnvironmentContextCanvas *_apexlib://resources/StandardApexLibrary/Canvas/EnvironmentContext.cls#Canvas.EnvironmentContext2Eapexlib://resources/StandardApexLibrary/Canvas/EnvironmentContext.cls8�
canvas.rendercontextRenderContextCanvas *Uapexlib://resources/StandardApexLibrary/Canvas/RenderContext.cls#Canvas.RenderContext2@apexlib://resources/StandardApexLibrary/Canvas/RenderContext.cls8�
canvas.testTestCanvas *Capexlib://resources/StandardApexLibrary/Canvas/Test.cls#Canvas.Test27apexlib://resources/StandardApexLibrary/Canvas/Test.cls8�
chatteranswers.accountcreatorAccountCreatorChatterAnswers *gapexlib://resources/StandardApexLibrary/ChatterAnswers/AccountCreator.cls#ChatterAnswers.AccountCreator2Iapexlib://resources/StandardApexLibrary/ChatterAnswers/AccountCreator.cls8�
*commercebuygrp.buyergroupevaluationserviceBuyerGroupEvaluationServiceCommerceBuyGrp *�apexlib://resources/StandardApexLibrary/CommerceBuyGrp/BuyerGroupEvaluationService.cls#CommerceBuyGrp.BuyerGroupEvaluationService2Vapexlib://resources/StandardApexLibrary/CommerceBuyGrp/BuyerGroupEvaluationService.cls8�
 commercebuygrp.buyergrouprequestBuyerGroupRequestCommerceBuyGrp *mapexlib://resources/StandardApexLibrary/CommerceBuyGrp/BuyerGroupRequest.cls#CommerceBuyGrp.BuyerGroupRequest2Lapexlib://resources/StandardApexLibrary/CommerceBuyGrp/BuyerGroupRequest.cls8�
!commercebuygrp.buyergroupresponseBuyerGroupResponseCommerceBuyGrp *oapexlib://resources/StandardApexLibrary/CommerceBuyGrp/BuyerGroupResponse.cls#CommerceBuyGrp.BuyerGroupResponse2Mapexlib://resources/StandardApexLibrary/CommerceBuyGrp/BuyerGroupResponse.cls8�
commerceextension.extensioninfoExtensionInfoCommerceExtension *kapexlib://resources/StandardApexLibrary/CommerceExtension/ExtensionInfo.cls#CommerceExtension.ExtensionInfo2Kapexlib://resources/StandardApexLibrary/CommerceExtension/ExtensionInfo.cls8�
commerceextension.resolution
ResolutionCommerceExtension *eapexlib://resources/StandardApexLibrary/CommerceExtension/Resolution.cls#CommerceExtension.Resolution2Hapexlib://resources/StandardApexLibrary/CommerceExtension/Resolution.cls8�
%commerceextension.resolutionexceptionResolutionExceptionCommerceExtension *wapexlib://resources/StandardApexLibrary/CommerceExtension/ResolutionException.cls#CommerceExtension.ResolutionException2Qapexlib://resources/StandardApexLibrary/CommerceExtension/ResolutionException.cls8�
"commerceextension.resolutionstatesResolutionStatesCommerceExtension *qapexlib://resources/StandardApexLibrary/CommerceExtension/ResolutionStates.cls#CommerceExtension.ResolutionStates2Napexlib://resources/StandardApexLibrary/CommerceExtension/ResolutionStates.cls8�
$commerceextension.resolutionstrategyResolutionStrategyCommerceExtension *uapexlib://resources/StandardApexLibrary/CommerceExtension/ResolutionStrategy.cls#CommerceExtension.ResolutionStrategy2Papexlib://resources/StandardApexLibrary/CommerceExtension/ResolutionStrategy.cls8�
!commercepayments.abstractresponseAbstractResponseCommercePayments *oapexlib://resources/StandardApexLibrary/CommercePayments/AbstractResponse.cls#CommercePayments.AbstractResponse2Mapexlib://resources/StandardApexLibrary/CommercePayments/AbstractResponse.cls8�
,commercepayments.abstracttransactionresponseAbstractTransactionResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/AbstractTransactionResponse.cls#CommercePayments.AbstractTransactionResponse2Xapexlib://resources/StandardApexLibrary/CommercePayments/AbstractTransactionResponse.cls8�
"commercepayments.accountholdertypeAccountHolderTypeCommercePayments *qapexlib://resources/StandardApexLibrary/CommercePayments/AccountHolderType.cls#CommercePayments.AccountHolderType2Napexlib://resources/StandardApexLibrary/CommercePayments/AccountHolderType.cls8�
commercepayments.accounttypeAccountTypeCommercePayments *eapexlib://resources/StandardApexLibrary/CommercePayments/AccountType.cls#CommercePayments.AccountType2Hapexlib://resources/StandardApexLibrary/CommercePayments/AccountType.cls8�
commercepayments.addressrequestAddressRequestCommercePayments *kapexlib://resources/StandardApexLibrary/CommercePayments/AddressRequest.cls#CommercePayments.AddressRequest2Kapexlib://resources/StandardApexLibrary/CommercePayments/AddressRequest.cls8�
0commercepayments.alternativepaymentmethodrequestAlternativePaymentMethodRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/AlternativePaymentMethodRequest.cls#CommercePayments.AlternativePaymentMethodRequest2\apexlib://resources/StandardApexLibrary/CommercePayments/AlternativePaymentMethodRequest.cls8�
1commercepayments.alternativepaymentmethodresponse AlternativePaymentMethodResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/AlternativePaymentMethodResponse.cls#CommercePayments.AlternativePaymentMethodResponse2]apexlib://resources/StandardApexLibrary/CommercePayments/AlternativePaymentMethodResponse.cls8�
#commercepayments.auditparamsrequestAuditParamsRequestCommercePayments *sapexlib://resources/StandardApexLibrary/CommercePayments/AuditParamsRequest.cls#CommercePayments.AuditParamsRequest2Oapexlib://resources/StandardApexLibrary/CommercePayments/AuditParamsRequest.cls8�
,commercepayments.authapipaymentmethodrequestAuthApiPaymentMethodRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/AuthApiPaymentMethodRequest.cls#CommercePayments.AuthApiPaymentMethodRequest2Xapexlib://resources/StandardApexLibrary/CommercePayments/AuthApiPaymentMethodRequest.cls8�
%commercepayments.authorizationrequestAuthorizationRequestCommercePayments *wapexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationRequest.cls#CommercePayments.AuthorizationRequest2Qapexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationRequest.cls8�
&commercepayments.authorizationresponseAuthorizationResponseCommercePayments *yapexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationResponse.cls#CommercePayments.AuthorizationResponse2Rapexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationResponse.cls8�
-commercepayments.authorizationreversalrequestAuthorizationReversalRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationReversalRequest.cls#CommercePayments.AuthorizationReversalRequest2Yapexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationReversalRequest.cls8�
.commercepayments.authorizationreversalresponseAuthorizationReversalResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationReversalResponse.cls#CommercePayments.AuthorizationReversalResponse2Zapexlib://resources/StandardApexLibrary/CommercePayments/AuthorizationReversalResponse.cls8�
)commercepayments.bankpaymentmethodrequestBankPaymentMethodRequestCommercePayments *apexlib://resources/StandardApexLibrary/CommercePayments/BankPaymentMethodRequest.cls#CommercePayments.BankPaymentMethodRequest2Uapexlib://resources/StandardApexLibrary/CommercePayments/BankPaymentMethodRequest.cls8�
*commercepayments.bankpaymentmethodresponseBankPaymentMethodResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/BankPaymentMethodResponse.cls#CommercePayments.BankPaymentMethodResponse2Vapexlib://resources/StandardApexLibrary/CommercePayments/BankPaymentMethodResponse.cls8�
commercepayments.banktypeBankTypeCommercePayments *_apexlib://resources/StandardApexLibrary/CommercePayments/BankType.cls#CommercePayments.BankType2Eapexlib://resources/StandardApexLibrary/CommercePayments/BankType.cls8�
,commercepayments.baseapipaymentmethodrequestBaseApiPaymentMethodRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/BaseApiPaymentMethodRequest.cls#CommercePayments.BaseApiPaymentMethodRequest2Xapexlib://resources/StandardApexLibrary/CommercePayments/BaseApiPaymentMethodRequest.cls8�
!commercepayments.basenotificationBaseNotificationCommercePayments *oapexlib://resources/StandardApexLibrary/CommercePayments/BaseNotification.cls#CommercePayments.BaseNotification2Mapexlib://resources/StandardApexLibrary/CommercePayments/BaseNotification.cls8�
)commercepayments.basepaymentmethodrequestBasePaymentMethodRequestCommercePayments *apexlib://resources/StandardApexLibrary/CommercePayments/BasePaymentMethodRequest.cls#CommercePayments.BasePaymentMethodRequest2Uapexlib://resources/StandardApexLibrary/CommercePayments/BasePaymentMethodRequest.cls8�
commercepayments.baserequestBaseRequestCommercePayments *eapexlib://resources/StandardApexLibrary/CommercePayments/BaseRequest.cls#CommercePayments.BaseRequest2Hapexlib://resources/StandardApexLibrary/CommercePayments/BaseRequest.cls8�
$commercepayments.capturenotificationCaptureNotificationCommercePayments *uapexlib://resources/StandardApexLibrary/CommercePayments/CaptureNotification.cls#CommercePayments.CaptureNotification2Papexlib://resources/StandardApexLibrary/CommercePayments/CaptureNotification.cls8�
commercepayments.capturerequestCaptureRequestCommercePayments *kapexlib://resources/StandardApexLibrary/CommercePayments/CaptureRequest.cls#CommercePayments.CaptureRequest2Kapexlib://resources/StandardApexLibrary/CommercePayments/CaptureRequest.cls8�
 commercepayments.captureresponseCaptureResponseCommercePayments *mapexlib://resources/StandardApexLibrary/CommercePayments/CaptureResponse.cls#CommercePayments.CaptureResponse2Lapexlib://resources/StandardApexLibrary/CommercePayments/CaptureResponse.cls8�
commercepayments.cardcategoryCardCategoryCommercePayments *gapexlib://resources/StandardApexLibrary/CommercePayments/CardCategory.cls#CommercePayments.CardCategory2Iapexlib://resources/StandardApexLibrary/CommercePayments/CardCategory.cls8�
)commercepayments.cardpaymentmethodrequestCardPaymentMethodRequestCommercePayments *apexlib://resources/StandardApexLibrary/CommercePayments/CardPaymentMethodRequest.cls#CommercePayments.CardPaymentMethodRequest2Uapexlib://resources/StandardApexLibrary/CommercePayments/CardPaymentMethodRequest.cls8�
*commercepayments.cardpaymentmethodresponseCardPaymentMethodResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/CardPaymentMethodResponse.cls#CommercePayments.CardPaymentMethodResponse2Vapexlib://resources/StandardApexLibrary/CommercePayments/CardPaymentMethodResponse.cls8�
commercepayments.cardtypeCardTypeCommercePayments *_apexlib://resources/StandardApexLibrary/CommercePayments/CardType.cls#CommercePayments.CardType2Eapexlib://resources/StandardApexLibrary/CommercePayments/CardType.cls8�
'commercepayments.custommetadatatypeinfoCustomMetadataTypeInfoCommercePayments *{apexlib://resources/StandardApexLibrary/CommercePayments/CustomMetadataTypeInfo.cls#CommercePayments.CustomMetadataTypeInfo2Sapexlib://resources/StandardApexLibrary/CommercePayments/CustomMetadataTypeInfo.cls8�
%commercepayments.gatewayerrorresponseGatewayErrorResponseCommercePayments *wapexlib://resources/StandardApexLibrary/CommercePayments/GatewayErrorResponse.cls#CommercePayments.GatewayErrorResponse2Qapexlib://resources/StandardApexLibrary/CommercePayments/GatewayErrorResponse.cls8�
,commercepayments.gatewaynotificationresponseGatewayNotificationResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/GatewayNotificationResponse.cls#CommercePayments.GatewayNotificationResponse2Xapexlib://resources/StandardApexLibrary/CommercePayments/GatewayNotificationResponse.cls8�
 commercepayments.gatewayresponseGatewayResponseCommercePayments *mapexlib://resources/StandardApexLibrary/CommercePayments/GatewayResponse.cls#CommercePayments.GatewayResponse2Lapexlib://resources/StandardApexLibrary/CommercePayments/GatewayResponse.cls8�
#commercepayments.notificationclientNotificationClientCommercePayments *sapexlib://resources/StandardApexLibrary/CommercePayments/NotificationClient.cls#CommercePayments.NotificationClient2Oapexlib://resources/StandardApexLibrary/CommercePayments/NotificationClient.cls8�
'commercepayments.notificationsaveresultNotificationSaveResultCommercePayments *{apexlib://resources/StandardApexLibrary/CommercePayments/NotificationSaveResult.cls#CommercePayments.NotificationSaveResult2Sapexlib://resources/StandardApexLibrary/CommercePayments/NotificationSaveResult.cls8�
#commercepayments.notificationstatusNotificationStatusCommercePayments *sapexlib://resources/StandardApexLibrary/CommercePayments/NotificationStatus.cls#CommercePayments.NotificationStatus2Oapexlib://resources/StandardApexLibrary/CommercePayments/NotificationStatus.cls8�
&commercepayments.paymentgatewayadapterPaymentGatewayAdapterCommercePayments *yapexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayAdapter.cls#CommercePayments.PaymentGatewayAdapter2Rapexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayAdapter.cls8�
+commercepayments.paymentgatewayasyncadapterPaymentGatewayAsyncAdapterCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayAsyncAdapter.cls#CommercePayments.PaymentGatewayAsyncAdapter2Wapexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayAsyncAdapter.cls8�
&commercepayments.paymentgatewaycontextPaymentGatewayContextCommercePayments *yapexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayContext.cls#CommercePayments.PaymentGatewayContext2Rapexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayContext.cls8�
2commercepayments.paymentgatewaynotificationcontext!PaymentGatewayNotificationContextCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayNotificationContext.cls#CommercePayments.PaymentGatewayNotificationContext2^apexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayNotificationContext.cls8�
2commercepayments.paymentgatewaynotificationrequest!PaymentGatewayNotificationRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayNotificationRequest.cls#CommercePayments.PaymentGatewayNotificationRequest2^apexlib://resources/StandardApexLibrary/CommercePayments/PaymentGatewayNotificationRequest.cls8�
-commercepayments.paymentmethoddetailsresponsePaymentMethodDetailsResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodDetailsResponse.cls#CommercePayments.PaymentMethodDetailsResponse2Yapexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodDetailsResponse.cls8�
$commercepayments.paymentmethodidtypePaymentMethodIdTypeCommercePayments *uapexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodIdType.cls#CommercePayments.PaymentMethodIdType2Papexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodIdType.cls8�
1commercepayments.paymentmethodtokenizationrequest PaymentMethodTokenizationRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodTokenizationRequest.cls#CommercePayments.PaymentMethodTokenizationRequest2]apexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodTokenizationRequest.cls8�
2commercepayments.paymentmethodtokenizationresponse!PaymentMethodTokenizationResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodTokenizationResponse.cls#CommercePayments.PaymentMethodTokenizationResponse2^apexlib://resources/StandardApexLibrary/CommercePayments/PaymentMethodTokenizationResponse.cls8�
commercepayments.paymentshttpPaymentsHttpCommercePayments *gapexlib://resources/StandardApexLibrary/CommercePayments/PaymentsHttp.cls#CommercePayments.PaymentsHttp2Iapexlib://resources/StandardApexLibrary/CommercePayments/PaymentsHttp.cls8�
0commercepayments.postauthapipaymentmethodrequestPostAuthApiPaymentMethodRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PostAuthApiPaymentMethodRequest.cls#CommercePayments.PostAuthApiPaymentMethodRequest2\apexlib://resources/StandardApexLibrary/CommercePayments/PostAuthApiPaymentMethodRequest.cls8�
)commercepayments.postauthorizationrequestPostAuthorizationRequestCommercePayments *apexlib://resources/StandardApexLibrary/CommercePayments/PostAuthorizationRequest.cls#CommercePayments.PostAuthorizationRequest2Uapexlib://resources/StandardApexLibrary/CommercePayments/PostAuthorizationRequest.cls8�
*commercepayments.postauthorizationresponsePostAuthorizationResponseCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/PostAuthorizationResponse.cls#CommercePayments.PostAuthorizationResponse2Vapexlib://resources/StandardApexLibrary/CommercePayments/PostAuthorizationResponse.cls8�
-commercepayments.referencedrefundnotificationReferencedRefundNotificationCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/ReferencedRefundNotification.cls#CommercePayments.ReferencedRefundNotification2Yapexlib://resources/StandardApexLibrary/CommercePayments/ReferencedRefundNotification.cls8�
(commercepayments.referencedrefundrequestReferencedRefundRequestCommercePayments *}apexlib://resources/StandardApexLibrary/CommercePayments/ReferencedRefundRequest.cls#CommercePayments.ReferencedRefundRequest2Tapexlib://resources/StandardApexLibrary/CommercePayments/ReferencedRefundRequest.cls8�
)commercepayments.referencedrefundresponseReferencedRefundResponseCommercePayments *apexlib://resources/StandardApexLibrary/CommercePayments/ReferencedRefundResponse.cls#CommercePayments.ReferencedRefundResponse2Uapexlib://resources/StandardApexLibrary/CommercePayments/ReferencedRefundResponse.cls8�
commercepayments.refundrequestRefundRequestCommercePayments *iapexlib://resources/StandardApexLibrary/CommercePayments/RefundRequest.cls#CommercePayments.RefundRequest2Japexlib://resources/StandardApexLibrary/CommercePayments/RefundRequest.cls8�
commercepayments.requesttypeRequestTypeCommercePayments *eapexlib://resources/StandardApexLibrary/CommercePayments/RequestType.cls#CommercePayments.RequestType2Hapexlib://resources/StandardApexLibrary/CommercePayments/RequestType.cls8�
commercepayments.retrycategoryRetryCategoryCommercePayments *iapexlib://resources/StandardApexLibrary/CommercePayments/RetryCategory.cls#CommercePayments.RetryCategory2Japexlib://resources/StandardApexLibrary/CommercePayments/RetryCategory.cls8�
commercepayments.retrydecisionRetryDecisionCommercePayments *iapexlib://resources/StandardApexLibrary/CommercePayments/RetryDecision.cls#CommercePayments.RetryDecision2Japexlib://resources/StandardApexLibrary/CommercePayments/RetryDecision.cls8�
,commercepayments.saleapipaymentmethodrequestSaleApiPaymentMethodRequestCommercePayments *�apexlib://resources/StandardApexLibrary/CommercePayments/SaleApiPaymentMethodRequest.cls#CommercePayments.SaleApiPaymentMethodRequest2Xapexlib://resources/StandardApexLibrary/CommercePayments/SaleApiPaymentMethodRequest.cls8�
!commercepayments.salenotificationSaleNotificationCommercePayments *oapexlib://resources/StandardApexLibrary/CommercePayments/SaleNotification.cls#CommercePayments.SaleNotification2Mapexlib://resources/StandardApexLibrary/CommercePayments/SaleNotification.cls8�
commercepayments.salerequestSaleRequestCommercePayments *eapexlib://resources/StandardApexLibrary/CommercePayments/SaleRequest.cls#CommercePayments.SaleRequest2Hapexlib://resources/StandardApexLibrary/CommercePayments/SaleRequest.cls8�
commercepayments.saleresponseSaleResponseCommercePayments *gapexlib://resources/StandardApexLibrary/CommercePayments/SaleResponse.cls#CommercePayments.SaleResponse2Iapexlib://resources/StandardApexLibrary/CommercePayments/SaleResponse.cls8�
%commercepayments.salesforceresultcodeSalesforceResultCodeCommercePayments *wapexlib://resources/StandardApexLibrary/CommercePayments/SalesforceResultCode.cls#CommercePayments.SalesforceResultCode2Qapexlib://resources/StandardApexLibrary/CommercePayments/SalesforceResultCode.cls8�
)commercepayments.salesforceresultcodeinfoSalesforceResultCodeInfoCommercePayments *apexlib://resources/StandardApexLibrary/CommercePayments/SalesforceResultCodeInfo.cls#CommercePayments.SalesforceResultCodeInfo2Uapexlib://resources/StandardApexLibrary/CommercePayments/SalesforceResultCodeInfo.cls8�
'commercepayments.standardentryclasscodeStandardEntryClassCodeCommercePayments *{apexlib://resources/StandardApexLibrary/CommercePayments/StandardEntryClassCode.cls#CommercePayments.StandardEntryClassCode2Sapexlib://resources/StandardApexLibrary/CommercePayments/StandardEntryClassCode.cls8�
%commercepayments.tokenizenotificationTokenizeNotificationCommercePayments *wapexlib://resources/StandardApexLibrary/CommercePayments/TokenizeNotification.cls#CommercePayments.TokenizeNotification2Qapexlib://resources/StandardApexLibrary/CommercePayments/TokenizeNotification.cls8�
'commercetax.abstracttransactionresponseAbstractTransactionResponseCommerceTax *{apexlib://resources/StandardApexLibrary/CommerceTax/AbstractTransactionResponse.cls#CommerceTax.AbstractTransactionResponse2Sapexlib://resources/StandardApexLibrary/CommerceTax/AbstractTransactionResponse.cls8�
commercetax.addressresponseAddressResponseCommerceTax *capexlib://resources/StandardApexLibrary/CommerceTax/AddressResponse.cls#CommerceTax.AddressResponse2Gapexlib://resources/StandardApexLibrary/CommerceTax/AddressResponse.cls8�
commercetax.addressesresponseAddressesResponseCommerceTax *gapexlib://resources/StandardApexLibrary/CommerceTax/AddressesResponse.cls#CommerceTax.AddressesResponse2Iapexlib://resources/StandardApexLibrary/CommerceTax/AddressesResponse.cls8�
!commercetax.amountdetailsresponseAmountDetailsResponseCommerceTax *oapexlib://resources/StandardApexLibrary/CommerceTax/AmountDetailsResponse.cls#CommerceTax.AmountDetailsResponse2Mapexlib://resources/StandardApexLibrary/CommerceTax/AmountDetailsResponse.cls8�
commercetax.calculatetaxrequestCalculateTaxRequestCommerceTax *kapexlib://resources/StandardApexLibrary/CommerceTax/CalculateTaxRequest.cls#CommerceTax.CalculateTaxRequest2Kapexlib://resources/StandardApexLibrary/CommerceTax/CalculateTaxRequest.cls8�
 commercetax.calculatetaxresponseCalculateTaxResponseCommerceTax *mapexlib://resources/StandardApexLibrary/CommerceTax/CalculateTaxResponse.cls#CommerceTax.CalculateTaxResponse2Lapexlib://resources/StandardApexLibrary/CommerceTax/CalculateTaxResponse.cls8�
commercetax.calculatetaxtypeCalculateTaxTypeCommerceTax *eapexlib://resources/StandardApexLibrary/CommerceTax/CalculateTaxType.cls#CommerceTax.CalculateTaxType2Hapexlib://resources/StandardApexLibrary/CommerceTax/CalculateTaxType.cls8�
'commercetax.customtaxattributesresponseCustomTaxAttributesResponseCommerceTax *{apexlib://resources/StandardApexLibrary/CommerceTax/CustomTaxAttributesResponse.cls#CommerceTax.CustomTaxAttributesResponse2Sapexlib://resources/StandardApexLibrary/CommerceTax/CustomTaxAttributesResponse.cls8�
commercetax.errorresponseErrorResponseCommerceTax *_apexlib://resources/StandardApexLibrary/CommerceTax/ErrorResponse.cls#CommerceTax.ErrorResponse2Eapexlib://resources/StandardApexLibrary/CommerceTax/ErrorResponse.cls8�
%commercetax.headertaxaddressesrequestHeaderTaxAddressesRequestCommerceTax *wapexlib://resources/StandardApexLibrary/CommerceTax/HeaderTaxAddressesRequest.cls#CommerceTax.HeaderTaxAddressesRequest2Qapexlib://resources/StandardApexLibrary/CommerceTax/HeaderTaxAddressesRequest.cls8�
commercetax.impositionresponseImpositionResponseCommerceTax *iapexlib://resources/StandardApexLibrary/CommerceTax/ImpositionResponse.cls#CommerceTax.ImpositionResponse2Japexlib://resources/StandardApexLibrary/CommerceTax/ImpositionResponse.cls8�
 commercetax.jurisdictionresponseJurisdictionResponseCommerceTax *mapexlib://resources/StandardApexLibrary/CommerceTax/JurisdictionResponse.cls#CommerceTax.JurisdictionResponse2Lapexlib://resources/StandardApexLibrary/CommerceTax/JurisdictionResponse.cls8�
commercetax.lineitemresponseLineItemResponseCommerceTax *eapexlib://resources/StandardApexLibrary/CommerceTax/LineItemResponse.cls#CommerceTax.LineItemResponse2Hapexlib://resources/StandardApexLibrary/CommerceTax/LineItemResponse.cls8�
#commercetax.linetaxaddressesrequestLineTaxAddressesRequestCommerceTax *sapexlib://resources/StandardApexLibrary/CommerceTax/LineTaxAddressesRequest.cls#CommerceTax.LineTaxAddressesRequest2Oapexlib://resources/StandardApexLibrary/CommerceTax/LineTaxAddressesRequest.cls8�
commercetax.requesttypeRequestTypeCommerceTax *[apexlib://resources/StandardApexLibrary/CommerceTax/RequestType.cls#CommerceTax.RequestType2Capexlib://resources/StandardApexLibrary/CommerceTax/RequestType.cls8�
commercetax.resultcode
ResultCodeCommerceTax *Yapexlib://resources/StandardApexLibrary/CommerceTax/ResultCode.cls#CommerceTax.ResultCode2Bapexlib://resources/StandardApexLibrary/CommerceTax/ResultCode.cls8�
commercetax.ruledetailsresponseRuleDetailsResponseCommerceTax *kapexlib://resources/StandardApexLibrary/CommerceTax/RuleDetailsResponse.cls#CommerceTax.RuleDetailsResponse2Kapexlib://resources/StandardApexLibrary/CommerceTax/RuleDetailsResponse.cls8�
commercetax.taxaddressrequestTaxAddressRequestCommerceTax *gapexlib://resources/StandardApexLibrary/CommerceTax/TaxAddressRequest.cls#CommerceTax.TaxAddressRequest2Iapexlib://resources/StandardApexLibrary/CommerceTax/TaxAddressRequest.cls8�
commercetax.taxaddressesrequestTaxAddressesRequestCommerceTax *kapexlib://resources/StandardApexLibrary/CommerceTax/TaxAddressesRequest.cls#CommerceTax.TaxAddressesRequest2Kapexlib://resources/StandardApexLibrary/CommerceTax/TaxAddressesRequest.cls8�
commercetax.taxapiexceptionTaxApiExceptionCommerceTax *capexlib://resources/StandardApexLibrary/CommerceTax/TaxApiException.cls#CommerceTax.TaxApiException2Gapexlib://resources/StandardApexLibrary/CommerceTax/TaxApiException.cls8�
%commercetax.taxcustomerdetailsrequestTaxCustomerDetailsRequestCommerceTax *wapexlib://resources/StandardApexLibrary/CommerceTax/TaxCustomerDetailsRequest.cls#CommerceTax.TaxCustomerDetailsRequest2Qapexlib://resources/StandardApexLibrary/CommerceTax/TaxCustomerDetailsRequest.cls8�
commercetax.taxdetailsresponseTaxDetailsResponseCommerceTax *iapexlib://resources/StandardApexLibrary/CommerceTax/TaxDetailsResponse.cls#CommerceTax.TaxDetailsResponse2Japexlib://resources/StandardApexLibrary/CommerceTax/TaxDetailsResponse.cls8�
commercetax.taxengineadapterTaxEngineAdapterCommerceTax *eapexlib://resources/StandardApexLibrary/CommerceTax/TaxEngineAdapter.cls#CommerceTax.TaxEngineAdapter2Hapexlib://resources/StandardApexLibrary/CommerceTax/TaxEngineAdapter.cls8�
commercetax.taxenginecontextTaxEngineContextCommerceTax *eapexlib://resources/StandardApexLibrary/CommerceTax/TaxEngineContext.cls#CommerceTax.TaxEngineContext2Hapexlib://resources/StandardApexLibrary/CommerceTax/TaxEngineContext.cls8�
commercetax.taxlineitemrequestTaxLineItemRequestCommerceTax *iapexlib://resources/StandardApexLibrary/CommerceTax/TaxLineItemRequest.cls#CommerceTax.TaxLineItemRequest2Japexlib://resources/StandardApexLibrary/CommerceTax/TaxLineItemRequest.cls8�
#commercetax.taxsellerdetailsrequestTaxSellerDetailsRequestCommerceTax *sapexlib://resources/StandardApexLibrary/CommerceTax/TaxSellerDetailsRequest.cls#CommerceTax.TaxSellerDetailsRequest2Oapexlib://resources/StandardApexLibrary/CommerceTax/TaxSellerDetailsRequest.cls8�
!commercetax.taxtransactionrequestTaxTransactionRequestCommerceTax *oapexlib://resources/StandardApexLibrary/CommerceTax/TaxTransactionRequest.cls#CommerceTax.TaxTransactionRequest2Mapexlib://resources/StandardApexLibrary/CommerceTax/TaxTransactionRequest.cls8�
 commercetax.taxtransactionstatusTaxTransactionStatusCommerceTax *mapexlib://resources/StandardApexLibrary/CommerceTax/TaxTransactionStatus.cls#CommerceTax.TaxTransactionStatus2Lapexlib://resources/StandardApexLibrary/CommerceTax/TaxTransactionStatus.cls8�
commercetax.taxtransactiontypeTaxTransactionTypeCommerceTax *iapexlib://resources/StandardApexLibrary/CommerceTax/TaxTransactionType.cls#CommerceTax.TaxTransactionType2Japexlib://resources/StandardApexLibrary/CommerceTax/TaxTransactionType.cls8�
compression.levelLevelCompression *Oapexlib://resources/StandardApexLibrary/Compression/Level.cls#Compression.Level2=apexlib://resources/StandardApexLibrary/Compression/Level.cls8�
compression.methodMethodCompression *Qapexlib://resources/StandardApexLibrary/Compression/Method.cls#Compression.Method2>apexlib://resources/StandardApexLibrary/Compression/Method.cls8�
compression.zipentryZipEntryCompression *Uapexlib://resources/StandardApexLibrary/Compression/ZipEntry.cls#Compression.ZipEntry2@apexlib://resources/StandardApexLibrary/Compression/ZipEntry.cls8�
compression.zipexceptionZipExceptionCompression *]apexlib://resources/StandardApexLibrary/Compression/ZipException.cls#Compression.ZipException2Dapexlib://resources/StandardApexLibrary/Compression/ZipException.cls8�
compression.zipreader	ZipReaderCompression *Wapexlib://resources/StandardApexLibrary/Compression/ZipReader.cls#Compression.ZipReader2Aapexlib://resources/StandardApexLibrary/Compression/ZipReader.cls8�
compression.zipwriter	ZipWriterCompression *Wapexlib://resources/StandardApexLibrary/Compression/ZipWriter.cls#Compression.ZipWriter2Aapexlib://resources/StandardApexLibrary/Compression/ZipWriter.cls8�
2connectapi.abstractbasesequenceinputrepresentation'AbstractBaseSequenceInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AbstractBaseSequenceInputRepresentation.cls#ConnectApi.AbstractBaseSequenceInputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/AbstractBaseSequenceInputRepresentation.cls8�
connectapi.abstractcartitemAbstractCartItem
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/AbstractCartItem.cls#ConnectApi.AbstractCartItem2Gapexlib://resources/StandardApexLibrary/ConnectApi/AbstractCartItem.cls8�
'connectapi.abstractcheckoutaddressinputAbstractCheckoutAddressInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/AbstractCheckoutAddressInput.cls#ConnectApi.AbstractCheckoutAddressInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/AbstractCheckoutAddressInput.cls8�
%connectapi.abstractcontenthubitemtypeAbstractContentHubItemType
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/AbstractContentHubItemType.cls#ConnectApi.AbstractContentHubItemType2Qapexlib://resources/StandardApexLibrary/ConnectApi/AbstractContentHubItemType.cls8�
(connectapi.abstractdirectoryentrysummaryAbstractDirectoryEntrySummary
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/AbstractDirectoryEntrySummary.cls#ConnectApi.AbstractDirectoryEntrySummary2Tapexlib://resources/StandardApexLibrary/ConnectApi/AbstractDirectoryEntrySummary.cls8�
'connectapi.abstractextensioninformationAbstractExtensionInformation
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/AbstractExtensionInformation.cls#ConnectApi.AbstractExtensionInformation2Sapexlib://resources/StandardApexLibrary/ConnectApi/AbstractExtensionInformation.cls8�
(connectapi.abstractgatewaycommonresponseAbstractGatewayCommonResponse
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/AbstractGatewayCommonResponse.cls#ConnectApi.AbstractGatewayCommonResponse2Tapexlib://resources/StandardApexLibrary/ConnectApi/AbstractGatewayCommonResponse.cls8�
"connectapi.abstractgatewayresponseAbstractGatewayResponse
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/AbstractGatewayResponse.cls#ConnectApi.AbstractGatewayResponse2Napexlib://resources/StandardApexLibrary/ConnectApi/AbstractGatewayResponse.cls8�
connectapi.abstractlistAbstractList
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/AbstractList.cls#ConnectApi.AbstractList2Capexlib://resources/StandardApexLibrary/ConnectApi/AbstractList.cls8�
6connectapi.abstractmanagedcontentchannelrepresentation+AbstractManagedContentChannelRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AbstractManagedContentChannelRepresentation.cls#ConnectApi.AbstractManagedContentChannelRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/AbstractManagedContentChannelRepresentation.cls8�
1connectapi.abstractmanagedcontentdeliverydocument&AbstractManagedContentDeliveryDocument
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AbstractManagedContentDeliveryDocument.cls#ConnectApi.AbstractManagedContentDeliveryDocument2]apexlib://resources/StandardApexLibrary/ConnectApi/AbstractManagedContentDeliveryDocument.cls8�
*connectapi.abstractmanagedcontentreferenceAbstractManagedContentReference
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AbstractManagedContentReference.cls#ConnectApi.AbstractManagedContentReference2Vapexlib://resources/StandardApexLibrary/ConnectApi/AbstractManagedContentReference.cls8�
connectapi.abstractmessagebodyAbstractMessageBody
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/AbstractMessageBody.cls#ConnectApi.AbstractMessageBody2Japexlib://resources/StandardApexLibrary/ConnectApi/AbstractMessageBody.cls8�
connectapi.abstractnbaactionAbstractNBAAction
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/AbstractNBAAction.cls#ConnectApi.AbstractNBAAction2Hapexlib://resources/StandardApexLibrary/ConnectApi/AbstractNBAAction.cls8�
connectapi.abstractnbatargetAbstractNBATarget
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/AbstractNBATarget.cls#ConnectApi.AbstractNBATarget2Hapexlib://resources/StandardApexLibrary/ConnectApi/AbstractNBATarget.cls8�
*connectapi.abstractpicklistvalueattributesAbstractPicklistValueAttributes
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AbstractPicklistValueAttributes.cls#ConnectApi.AbstractPicklistValueAttributes2Vapexlib://resources/StandardApexLibrary/ConnectApi/AbstractPicklistValueAttributes.cls8�
!connectapi.abstractrecommendationAbstractRecommendation
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecommendation.cls#ConnectApi.AbstractRecommendation2Mapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecommendation.cls8�
,connectapi.abstractrecommendationexplanation!AbstractRecommendationExplanation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecommendationExplanation.cls#ConnectApi.AbstractRecommendationExplanation2Xapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecommendationExplanation.cls8�
connectapi.abstractrecordfieldAbstractRecordField
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecordField.cls#ConnectApi.AbstractRecordField2Japexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecordField.cls8�
connectapi.abstractrecordviewAbstractRecordView
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecordView.cls#ConnectApi.AbstractRecordView2Iapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRecordView.cls8�
!connectapi.abstractrepositoryfileAbstractRepositoryFile
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRepositoryFile.cls#ConnectApi.AbstractRepositoryFile2Mapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRepositoryFile.cls8�
#connectapi.abstractrepositoryfolderAbstractRepositoryFolder
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRepositoryFolder.cls#ConnectApi.AbstractRepositoryFolder2Oapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRepositoryFolder.cls8�
!connectapi.abstractrepositoryitemAbstractRepositoryItem
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRepositoryItem.cls#ConnectApi.AbstractRepositoryItem2Mapexlib://resources/StandardApexLibrary/ConnectApi/AbstractRepositoryItem.cls8�
&connectapi.abstractusermissionactivityAbstractUserMissionActivity
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/AbstractUserMissionActivity.cls#ConnectApi.AbstractUserMissionActivity2Rapexlib://resources/StandardApexLibrary/ConnectApi/AbstractUserMissionActivity.cls8�
 connectapi.accountholdertypeenumAccountHolderTypeEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/AccountHolderTypeEnum.cls#ConnectApi.AccountHolderTypeEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/AccountHolderTypeEnum.cls8�
connectapi.accounttypeenumAccountTypeEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/AccountTypeEnum.cls#ConnectApi.AccountTypeEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/AccountTypeEnum.cls8�
(connectapi.actioninfoinputrepresentationActionInfoInputRepresentation
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/ActionInfoInputRepresentation.cls#ConnectApi.ActionInfoInputRepresentation2Tapexlib://resources/StandardApexLibrary/ConnectApi/ActionInfoInputRepresentation.cls8�
)connectapi.actioninfooutputrepresentationActionInfoOutputRepresentation
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ActionInfoOutputRepresentation.cls#ConnectApi.ActionInfoOutputRepresentation2Uapexlib://resources/StandardApexLibrary/ConnectApi/ActionInfoOutputRepresentation.cls8�
connectapi.actionlinkdefinitionActionLinkDefinition
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkDefinition.cls#ConnectApi.ActionLinkDefinition2Kapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkDefinition.cls8�
$connectapi.actionlinkdefinitioninputActionLinkDefinitionInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkDefinitionInput.cls#ConnectApi.ActionLinkDefinitionInput2Papexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkDefinitionInput.cls8�
#connectapi.actionlinkdiagnosticinfoActionLinkDiagnosticInfo
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkDiagnosticInfo.cls#ConnectApi.ActionLinkDiagnosticInfo2Oapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkDiagnosticInfo.cls8�
&connectapi.actionlinkexecutionsallowedActionLinkExecutionsAllowed
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkExecutionsAllowed.cls#ConnectApi.ActionLinkExecutionsAllowed2Rapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkExecutionsAllowed.cls8�
$connectapi.actionlinkgroupdefinitionActionLinkGroupDefinition
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkGroupDefinition.cls#ConnectApi.ActionLinkGroupDefinition2Papexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkGroupDefinition.cls8�
)connectapi.actionlinkgroupdefinitioninputActionLinkGroupDefinitionInput
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkGroupDefinitionInput.cls#ConnectApi.ActionLinkGroupDefinitionInput2Uapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkGroupDefinitionInput.cls8�
)connectapi.actionlinktemplatebindinginputActionLinkTemplateBindingInput
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkTemplateBindingInput.cls#ConnectApi.ActionLinkTemplateBindingInput2Uapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkTemplateBindingInput.cls8�
connectapi.actionlinktypeenumActionLinkTypeEnum
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkTypeEnum.cls#ConnectApi.ActionLinkTypeEnum2Iapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinkTypeEnum.cls8�
connectapi.actionlinksActionLinks
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinks.cls#ConnectApi.ActionLinks2Bapexlib://resources/StandardApexLibrary/ConnectApi/ActionLinks.cls8�
connectapi.activation
Activation
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/Activation.cls#ConnectApi.Activation2Aapexlib://resources/StandardApexLibrary/ConnectApi/Activation.cls8�
4connectapi.activationadditionalattributesconfiginput)ActivationAdditionalAttributesConfigInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationAdditionalAttributesConfigInput.cls#ConnectApi.ActivationAdditionalAttributesConfigInput2`apexlib://resources/StandardApexLibrary/ConnectApi/ActivationAdditionalAttributesConfigInput.cls8�
connectapi.activationattributeActivationAttribute
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ActivationAttribute.cls#ConnectApi.ActivationAttribute2Japexlib://resources/StandardApexLibrary/ConnectApi/ActivationAttribute.cls8�
$connectapi.activationattributeconfigActivationAttributeConfig
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ActivationAttributeConfig.cls#ConnectApi.ActivationAttributeConfig2Papexlib://resources/StandardApexLibrary/ConnectApi/ActivationAttributeConfig.cls8�
connectapi.activationcollectionActivationCollection
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ActivationCollection.cls#ConnectApi.ActivationCollection2Kapexlib://resources/StandardApexLibrary/ConnectApi/ActivationCollection.cls8�
,connectapi.activationcontactpointfieldconfig!ActivationContactPointFieldConfig
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointFieldConfig.cls#ConnectApi.ActivationContactPointFieldConfig2Xapexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointFieldConfig.cls8�
&connectapi.activationcontactpointinputActivationContactPointInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointInput.cls#ConnectApi.ActivationContactPointInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointInput.cls8�
-connectapi.activationcontactpointsourceconfig"ActivationContactPointSourceConfig
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointSourceConfig.cls#ConnectApi.ActivationContactPointSourceConfig2Yapexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointSourceConfig.cls8�
-connectapi.activationcontactpointsfieldconfig"ActivationContactPointsFieldConfig
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointsFieldConfig.cls#ConnectApi.ActivationContactPointsFieldConfig2Yapexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointsFieldConfig.cls8�
.connectapi.activationcontactpointssourceconfig#ActivationContactPointsSourceConfig
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointsSourceConfig.cls#ConnectApi.ActivationContactPointsSourceConfig2Zapexlib://resources/StandardApexLibrary/ConnectApi/ActivationContactPointsSourceConfig.cls8�
connectapi.activationdataActivationData
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ActivationData.cls#ConnectApi.ActivationData2Eapexlib://resources/StandardApexLibrary/ConnectApi/ActivationData.cls8�
%connectapi.activationdatasourceconfigActivationDataSourceConfig
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ActivationDataSourceConfig.cls#ConnectApi.ActivationDataSourceConfig2Qapexlib://resources/StandardApexLibrary/ConnectApi/ActivationDataSourceConfig.cls8�
 connectapi.activationdatasourcesActivationDataSources
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ActivationDataSources.cls#ConnectApi.ActivationDataSources2Lapexlib://resources/StandardApexLibrary/ConnectApi/ActivationDataSources.cls8�
$connectapi.activationdefinitioninputActivationDefinitionInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ActivationDefinitionInput.cls#ConnectApi.ActivationDefinitionInput2Papexlib://resources/StandardApexLibrary/ConnectApi/ActivationDefinitionInput.cls8�
-connectapi.activationplatformcreationtypeenum"ActivationPlatformCreationTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformCreationTypeEnum.cls#ConnectApi.ActivationPlatformCreationTypeEnum2Yapexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformCreationTypeEnum.cls8�
3connectapi.activationplatformcustomerfilesourceenum(ActivationPlatformCustomerFileSourceEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformCustomerFileSourceEnum.cls#ConnectApi.ActivationPlatformCustomerFileSourceEnum2_apexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformCustomerFileSourceEnum.cls8�
,connectapi.activationplatformprivacytypeenum!ActivationPlatformPrivacyTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformPrivacyTypeEnum.cls#ConnectApi.ActivationPlatformPrivacyTypeEnum2Xapexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformPrivacyTypeEnum.cls8�
'connectapi.activationplatformstatusenumActivationPlatformStatusEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformStatusEnum.cls#ConnectApi.ActivationPlatformStatusEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformStatusEnum.cls8�
%connectapi.activationplatformtypeenumActivationPlatformTypeEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformTypeEnum.cls#ConnectApi.ActivationPlatformTypeEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/ActivationPlatformTypeEnum.cls8�
connectapi.activationstatusenumActivationStatusEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ActivationStatusEnum.cls#ConnectApi.ActivationStatusEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/ActivationStatusEnum.cls8�
connectapi.activationtargetActivationTarget
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/ActivationTarget.cls#ConnectApi.ActivationTarget2Gapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTarget.cls8�
%connectapi.activationtargetcollectionActivationTargetCollection
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetCollection.cls#ConnectApi.ActivationTargetCollection2Qapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetCollection.cls8�
 connectapi.activationtargetinputActivationTargetInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetInput.cls#ConnectApi.ActivationTargetInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetInput.cls8�
%connectapi.activationtargetstatusenumActivationTargetStatusEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetStatusEnum.cls#ConnectApi.ActivationTargetStatusEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetStatusEnum.cls8�
"connectapi.activationtargetsubjectActivationTargetSubject
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetSubject.cls#ConnectApi.ActivationTargetSubject2Napexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetSubject.cls8�
-connectapi.activationtargetsubjectconfiginput"ActivationTargetSubjectConfigInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetSubjectConfigInput.cls#ConnectApi.ActivationTargetSubjectConfigInput2Yapexlib://resources/StandardApexLibrary/ConnectApi/ActivationTargetSubjectConfigInput.cls8�
connectapi.activitysharinginputActivitySharingInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ActivitySharingInput.cls#ConnectApi.ActivitySharingInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/ActivitySharingInput.cls8�
 connectapi.activitysharingresultActivitySharingResult
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ActivitySharingResult.cls#ConnectApi.ActivitySharingResult2Lapexlib://resources/StandardApexLibrary/ConnectApi/ActivitySharingResult.cls8�
"connectapi.activitysharingtypeenumActivitySharingTypeEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ActivitySharingTypeEnum.cls#ConnectApi.ActivitySharingTypeEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/ActivitySharingTypeEnum.cls8�
connectapi.actorActor
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Actor.cls#ConnectApi.Actor2<apexlib://resources/StandardApexLibrary/ConnectApi/Actor.cls8�
connectapi.actorwithidActorWithId
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/ActorWithId.cls#ConnectApi.ActorWithId2Bapexlib://resources/StandardApexLibrary/ConnectApi/ActorWithId.cls8�
connectapi.addressAddress
ConnectApi *Qapexlib://resources/StandardApexLibrary/ConnectApi/Address.cls#ConnectApi.Address2>apexlib://resources/StandardApexLibrary/ConnectApi/Address.cls8�
connectapi.addressrequestAddressRequest
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/AddressRequest.cls#ConnectApi.AddressRequest2Eapexlib://resources/StandardApexLibrary/ConnectApi/AddressRequest.cls8�
(connectapi.adjustiteminputrepresentationAdjustItemInputRepresentation
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/AdjustItemInputRepresentation.cls#ConnectApi.AdjustItemInputRepresentation2Tapexlib://resources/StandardApexLibrary/ConnectApi/AdjustItemInputRepresentation.cls8�
4connectapi.adjustorderitemsummaryinputrepresentation)AdjustOrderItemSummaryInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AdjustOrderItemSummaryInputRepresentation.cls#ConnectApi.AdjustOrderItemSummaryInputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/AdjustOrderItemSummaryInputRepresentation.cls8�
1connectapi.adjustordersummaryoutputrepresentation&AdjustOrderSummaryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AdjustOrderSummaryOutputRepresentation.cls#ConnectApi.AdjustOrderSummaryOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/AdjustOrderSummaryOutputRepresentation.cls8�
$connectapi.adjustmentamountscopeenumAdjustmentAmountScopeEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/AdjustmentAmountScopeEnum.cls#ConnectApi.AdjustmentAmountScopeEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/AdjustmentAmountScopeEnum.cls8�
connectapi.adjustmenttypeenumAdjustmentTypeEnum
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/AdjustmentTypeEnum.cls#ConnectApi.AdjustmentTypeEnum2Iapexlib://resources/StandardApexLibrary/ConnectApi/AdjustmentTypeEnum.cls8�
connectapi.alternativeAlternative
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/Alternative.cls#ConnectApi.Alternative2Bapexlib://resources/StandardApexLibrary/ConnectApi/Alternative.cls8�
connectapi.alternativeinputAlternativeInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/AlternativeInput.cls#ConnectApi.AlternativeInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/AlternativeInput.cls8�
#connectapi.alternativepaymentmethodAlternativePaymentMethod
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/AlternativePaymentMethod.cls#ConnectApi.AlternativePaymentMethod2Oapexlib://resources/StandardApexLibrary/ConnectApi/AlternativePaymentMethod.cls8�
)connectapi.alternativepaymentmethodoutputAlternativePaymentMethodOutput
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/AlternativePaymentMethodOutput.cls#ConnectApi.AlternativePaymentMethodOutput2Uapexlib://resources/StandardApexLibrary/ConnectApi/AlternativePaymentMethodOutput.cls8�
connectapi.announcementAnnouncement
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/Announcement.cls#ConnectApi.Announcement2Capexlib://resources/StandardApexLibrary/ConnectApi/Announcement.cls8�
connectapi.announcementinputAnnouncementInput
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/AnnouncementInput.cls#ConnectApi.AnnouncementInput2Hapexlib://resources/StandardApexLibrary/ConnectApi/AnnouncementInput.cls8�
connectapi.announcementpageAnnouncementPage
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/AnnouncementPage.cls#ConnectApi.AnnouncementPage2Gapexlib://resources/StandardApexLibrary/ConnectApi/AnnouncementPage.cls8�
connectapi.announcementsAnnouncements
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/Announcements.cls#ConnectApi.Announcements2Dapexlib://resources/StandardApexLibrary/ConnectApi/Announcements.cls8�
connectapi.applicationenumApplicationEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ApplicationEnum.cls#ConnectApi.ApplicationEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/ApplicationEnum.cls8�
connectapi.approvalattachmentApprovalAttachment
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ApprovalAttachment.cls#ConnectApi.ApprovalAttachment2Iapexlib://resources/StandardApexLibrary/ConnectApi/ApprovalAttachment.cls8�
connectapi.approvalcapabilityApprovalCapability
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ApprovalCapability.cls#ConnectApi.ApprovalCapability2Iapexlib://resources/StandardApexLibrary/ConnectApi/ApprovalCapability.cls8�
connectapi.approvalintentApprovalIntent
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ApprovalIntent.cls#ConnectApi.ApprovalIntent2Eapexlib://resources/StandardApexLibrary/ConnectApi/ApprovalIntent.cls8�
$connectapi.approvalposttemplatefieldApprovalPostTemplateField
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ApprovalPostTemplateField.cls#ConnectApi.ApprovalPostTemplateField2Papexlib://resources/StandardApexLibrary/ConnectApi/ApprovalPostTemplateField.cls8�
connectapi.articleitemArticleItem
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/ArticleItem.cls#ConnectApi.ArticleItem2Bapexlib://resources/StandardApexLibrary/ConnectApi/ArticleItem.cls8�
connectapi.articlesummaryArticleSummary
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ArticleSummary.cls#ConnectApi.ArticleSummary2Eapexlib://resources/StandardApexLibrary/ConnectApi/ArticleSummary.cls8�
)connectapi.articletopicassignmentjobinputArticleTopicAssignmentJobInput
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ArticleTopicAssignmentJobInput.cls#ConnectApi.ArticleTopicAssignmentJobInput2Uapexlib://resources/StandardApexLibrary/ConnectApi/ArticleTopicAssignmentJobInput.cls8�
connectapi.articletopicjobenumArticleTopicJobEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ArticleTopicJobEnum.cls#ConnectApi.ArticleTopicJobEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/ArticleTopicJobEnum.cls8�
-connectapi.associaterecordswithrecipientinput"AssociateRecordsWithRecipientInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AssociateRecordsWithRecipientInput.cls#ConnectApi.AssociateRecordsWithRecipientInput2Yapexlib://resources/StandardApexLibrary/ConnectApi/AssociateRecordsWithRecipientInput.cls8�
&connectapi.associatedactionscapabilityAssociatedActionsCapability
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/AssociatedActionsCapability.cls#ConnectApi.AssociatedActionsCapability2Rapexlib://resources/StandardApexLibrary/ConnectApi/AssociatedActionsCapability.cls8�
+connectapi.associatedactionscapabilityinput AssociatedActionsCapabilityInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AssociatedActionsCapabilityInput.cls#ConnectApi.AssociatedActionsCapabilityInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/AssociatedActionsCapabilityInput.cls8�
connectapi.asyncoperationstatusAsyncOperationStatus
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/AsyncOperationStatus.cls#ConnectApi.AsyncOperationStatus2Kapexlib://resources/StandardApexLibrary/ConnectApi/AsyncOperationStatus.cls8�
$connectapi.asyncoutputrepresentationAsyncOutputRepresentation
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/AsyncOutputRepresentation.cls#ConnectApi.AsyncOutputRepresentation2Papexlib://resources/StandardApexLibrary/ConnectApi/AsyncOutputRepresentation.cls8�
connectapi.attributefilterAttributeFilter
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/AttributeFilter.cls#ConnectApi.AttributeFilter2Fapexlib://resources/StandardApexLibrary/ConnectApi/AttributeFilter.cls8�
$connectapi.attributefilterexpressionAttributeFilterExpression
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/AttributeFilterExpression.cls#ConnectApi.AttributeFilterExpression2Papexlib://resources/StandardApexLibrary/ConnectApi/AttributeFilterExpression.cls8�
connectapi.attributefilterinputAttributeFilterInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/AttributeFilterInput.cls#ConnectApi.AttributeFilterInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/AttributeFilterInput.cls8�
+connectapi.attributelimitingexpressioninput AttributeLimitingExpressionInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AttributeLimitingExpressionInput.cls#ConnectApi.AttributeLimitingExpressionInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/AttributeLimitingExpressionInput.cls8�
*connectapi.attributesetinputrepresentationAttributeSetInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AttributeSetInputRepresentation.cls#ConnectApi.AttributeSetInputRepresentation2Vapexlib://resources/StandardApexLibrary/ConnectApi/AttributeSetInputRepresentation.cls8�
connectapi.audienceAudience
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/Audience.cls#ConnectApi.Audience2?apexlib://resources/StandardApexLibrary/ConnectApi/Audience.cls8�
connectapi.audiencecollectionAudienceCollection
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCollection.cls#ConnectApi.AudienceCollection2Iapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCollection.cls8�
connectapi.audiencecriteriaAudienceCriteria
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteria.cls#ConnectApi.AudienceCriteria2Gapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteria.cls8�
!connectapi.audiencecriteriadetailAudienceCriteriaDetail
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaDetail.cls#ConnectApi.AudienceCriteriaDetail2Mapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaDetail.cls8�
 connectapi.audiencecriteriainputAudienceCriteriaInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaInput.cls#ConnectApi.AudienceCriteriaInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaInput.cls8�
'connectapi.audiencecriteriaoperatorenumAudienceCriteriaOperatorEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaOperatorEnum.cls#ConnectApi.AudienceCriteriaOperatorEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaOperatorEnum.cls8�
connectapi.audiencecriteriatypeAudienceCriteriaType
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaType.cls#ConnectApi.AudienceCriteriaType2Kapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriteriaType.cls8�
"connectapi.audiencecriteriondetailAudienceCriterionDetail
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriterionDetail.cls#ConnectApi.AudienceCriterionDetail2Napexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriterionDetail.cls8�
!connectapi.audiencecriterioninputAudienceCriterionInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriterionInput.cls#ConnectApi.AudienceCriterionInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriterionInput.cls8�
&connectapi.audiencecriterionvalueinputAudienceCriterionValueInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriterionValueInput.cls#ConnectApi.AudienceCriterionValueInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/AudienceCriterionValueInput.cls8�
 connectapi.audiencedmocollectionAudienceDMOCollection
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/AudienceDMOCollection.cls#ConnectApi.AudienceDMOCollection2Lapexlib://resources/StandardApexLibrary/ConnectApi/AudienceDMOCollection.cls8�
#connectapi.audiencedmodeltatypeenumAudienceDMODeltaTypeEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/AudienceDMODeltaTypeEnum.cls#ConnectApi.AudienceDMODeltaTypeEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/AudienceDMODeltaTypeEnum.cls8�
connectapi.audienceinputAudienceInput
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/AudienceInput.cls#ConnectApi.AudienceInput2Dapexlib://resources/StandardApexLibrary/ConnectApi/AudienceInput.cls8�
connectapi.audiencetargetAudienceTarget
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/AudienceTarget.cls#ConnectApi.AudienceTarget2Eapexlib://resources/StandardApexLibrary/ConnectApi/AudienceTarget.cls8�
#connectapi.audiencetargetassignmentAudienceTargetAssignment
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/AudienceTargetAssignment.cls#ConnectApi.AudienceTargetAssignment2Oapexlib://resources/StandardApexLibrary/ConnectApi/AudienceTargetAssignment.cls8�
connectapi.auditparamsrequestAuditParamsRequest
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/AuditParamsRequest.cls#ConnectApi.AuditParamsRequest2Iapexlib://resources/StandardApexLibrary/ConnectApi/AuditParamsRequest.cls8�
&connectapi.authapipaymentmethodrequestAuthApiPaymentMethodRequest
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/AuthApiPaymentMethodRequest.cls#ConnectApi.AuthApiPaymentMethodRequest2Rapexlib://resources/StandardApexLibrary/ConnectApi/AuthApiPaymentMethodRequest.cls8�
connectapi.authprotocolenumAuthProtocolEnum
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/AuthProtocolEnum.cls#ConnectApi.AuthProtocolEnum2Gapexlib://resources/StandardApexLibrary/ConnectApi/AuthProtocolEnum.cls8�
&connectapi.authreversalgatewayresponseAuthReversalGatewayResponse
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/AuthReversalGatewayResponse.cls#ConnectApi.AuthReversalGatewayResponse2Rapexlib://resources/StandardApexLibrary/ConnectApi/AuthReversalGatewayResponse.cls8�
'connectapi.authorizationgatewayresponseAuthorizationGatewayResponse
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationGatewayResponse.cls#ConnectApi.AuthorizationGatewayResponse2Sapexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationGatewayResponse.cls8�
connectapi.authorizationrequestAuthorizationRequest
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationRequest.cls#ConnectApi.AuthorizationRequest2Kapexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationRequest.cls8�
 connectapi.authorizationresponseAuthorizationResponse
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationResponse.cls#ConnectApi.AuthorizationResponse2Lapexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationResponse.cls8�
'connectapi.authorizationreversalrequestAuthorizationReversalRequest
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationReversalRequest.cls#ConnectApi.AuthorizationReversalRequest2Sapexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationReversalRequest.cls8�
(connectapi.authorizationreversalresponseAuthorizationReversalResponse
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationReversalResponse.cls#ConnectApi.AuthorizationReversalResponse2Tapexlib://resources/StandardApexLibrary/ConnectApi/AuthorizationReversalResponse.cls8�
0connectapi.availablelocationoutputrepresentation%AvailableLocationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AvailableLocationOutputRepresentation.cls#ConnectApi.AvailableLocationOutputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/AvailableLocationOutputRepresentation.cls8�
4connectapi.averagedistanceresultoutputrepresentation)AverageDistanceResultOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/AverageDistanceResultOutputRepresentation.cls#ConnectApi.AverageDistanceResultOutputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/AverageDistanceResultOutputRepresentation.cls8�
2connectapi.balancestatepreviewoutputrepresentation'BalanceStatePreviewOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BalanceStatePreviewOutputRepresentation.cls#ConnectApi.BalanceStatePreviewOutputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/BalanceStatePreviewOutputRepresentation.cls8�
#connectapi.bankpaymentmethodrequestBankPaymentMethodRequest
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/BankPaymentMethodRequest.cls#ConnectApi.BankPaymentMethodRequest2Oapexlib://resources/StandardApexLibrary/ConnectApi/BankPaymentMethodRequest.cls8�
connectapi.banktypeenumBankTypeEnum
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/BankTypeEnum.cls#ConnectApi.BankTypeEnum2Capexlib://resources/StandardApexLibrary/ConnectApi/BankTypeEnum.cls8�
connectapi.bannercapabilityBannerCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/BannerCapability.cls#ConnectApi.BannerCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/BannerCapability.cls8�
connectapi.bannerphotoBannerPhoto
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/BannerPhoto.cls#ConnectApi.BannerPhoto2Bapexlib://resources/StandardApexLibrary/ConnectApi/BannerPhoto.cls8�
connectapi.bannerphotoinputBannerPhotoInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/BannerPhotoInput.cls#ConnectApi.BannerPhotoInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/BannerPhotoInput.cls8�
connectapi.bannerstyleenumBannerStyleEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/BannerStyleEnum.cls#ConnectApi.BannerStyleEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/BannerStyleEnum.cls8�
&connectapi.baseapipaymentmethodrequestBaseApiPaymentMethodRequest
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/BaseApiPaymentMethodRequest.cls#ConnectApi.BaseApiPaymentMethodRequest2Rapexlib://resources/StandardApexLibrary/ConnectApi/BaseApiPaymentMethodRequest.cls8�
(connectapi.baseasyncoutputrepresentationBaseAsyncOutputRepresentation
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/BaseAsyncOutputRepresentation.cls#ConnectApi.BaseAsyncOutputRepresentation2Tapexlib://resources/StandardApexLibrary/ConnectApi/BaseAsyncOutputRepresentation.cls8�
connectapi.basecomparisonBaseComparison
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/BaseComparison.cls#ConnectApi.BaseComparison2Eapexlib://resources/StandardApexLibrary/ConnectApi/BaseComparison.cls8�
connectapi.basecomparisoninputBaseComparisonInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/BaseComparisonInput.cls#ConnectApi.BaseComparisonInput2Japexlib://resources/StandardApexLibrary/ConnectApi/BaseComparisonInput.cls8�
*connectapi.baseinvoiceoutputrepresentationBaseInvoiceOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BaseInvoiceOutputRepresentation.cls#ConnectApi.BaseInvoiceOutputRepresentation2Vapexlib://resources/StandardApexLibrary/ConnectApi/BaseInvoiceOutputRepresentation.cls8�
#connectapi.basemanagedsocialaccountBaseManagedSocialAccount
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/BaseManagedSocialAccount.cls#ConnectApi.BaseManagedSocialAccount2Oapexlib://resources/StandardApexLibrary/ConnectApi/BaseManagedSocialAccount.cls8�
#connectapi.baseoutputrepresentationBaseOutputRepresentation
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/BaseOutputRepresentation.cls#ConnectApi.BaseOutputRepresentation2Oapexlib://resources/StandardApexLibrary/ConnectApi/BaseOutputRepresentation.cls8�
#connectapi.basepaymentmethodrequestBasePaymentMethodRequest
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/BasePaymentMethodRequest.cls#ConnectApi.BasePaymentMethodRequest2Oapexlib://resources/StandardApexLibrary/ConnectApi/BasePaymentMethodRequest.cls8�
connectapi.baserequestBaseRequest
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/BaseRequest.cls#ConnectApi.BaseRequest2Bapexlib://resources/StandardApexLibrary/ConnectApi/BaseRequest.cls8�
"connectapi.basictemplateattachmentBasicTemplateAttachment
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/BasicTemplateAttachment.cls#ConnectApi.BasicTemplateAttachment2Napexlib://resources/StandardApexLibrary/ConnectApi/BasicTemplateAttachment.cls8�
connectapi.batchinput
BatchInput
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/BatchInput.cls#ConnectApi.BatchInput2Aapexlib://resources/StandardApexLibrary/ConnectApi/BatchInput.cls8�
connectapi.batchresultBatchResult
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/BatchResult.cls#ConnectApi.BatchResult2Bapexlib://resources/StandardApexLibrary/ConnectApi/BatchResult.cls8�
connectapi.billingfrequencyenumBillingFrequencyEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/BillingFrequencyEnum.cls#ConnectApi.BillingFrequencyEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/BillingFrequencyEnum.cls8�
connectapi.binaryinputBinaryInput
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/BinaryInput.cls#ConnectApi.BinaryInput2Bapexlib://resources/StandardApexLibrary/ConnectApi/BinaryInput.cls8�
connectapi.blankrecordfieldBlankRecordField
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/BlankRecordField.cls#ConnectApi.BlankRecordField2Gapexlib://resources/StandardApexLibrary/ConnectApi/BlankRecordField.cls8�
connectapi.bookmarksummaryBookmarkSummary
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/BookmarkSummary.cls#ConnectApi.BookmarkSummary2Fapexlib://resources/StandardApexLibrary/ConnectApi/BookmarkSummary.cls8�
connectapi.bookmarkscapabilityBookmarksCapability
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/BookmarksCapability.cls#ConnectApi.BookmarksCapability2Japexlib://resources/StandardApexLibrary/ConnectApi/BookmarksCapability.cls8�
#connectapi.bookmarkscapabilityinputBookmarksCapabilityInput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/BookmarksCapabilityInput.cls#ConnectApi.BookmarksCapabilityInput2Oapexlib://resources/StandardApexLibrary/ConnectApi/BookmarksCapabilityInput.cls8�
connectapi.booleanlistBooleanList
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/BooleanList.cls#ConnectApi.BooleanList2Bapexlib://resources/StandardApexLibrary/ConnectApi/BooleanList.cls8�
 connectapi.botinforepresentationBotInfoRepresentation
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/BotInfoRepresentation.cls#ConnectApi.BotInfoRepresentation2Lapexlib://resources/StandardApexLibrary/ConnectApi/BotInfoRepresentation.cls8�
connectapi.botversionactivationBotVersionActivation
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/BotVersionActivation.cls#ConnectApi.BotVersionActivation2Kapexlib://resources/StandardApexLibrary/ConnectApi/BotVersionActivation.cls8�
#connectapi.botversionactivationinfoBotVersionActivationInfo
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/BotVersionActivationInfo.cls#ConnectApi.BotVersionActivationInfo2Oapexlib://resources/StandardApexLibrary/ConnectApi/BotVersionActivationInfo.cls8�
$connectapi.botversionactivationinputBotVersionActivationInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/BotVersionActivationInput.cls#ConnectApi.BotVersionActivationInput2Papexlib://resources/StandardApexLibrary/ConnectApi/BotVersionActivationInput.cls8�
connectapi.bundlecapabilityBundleCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/BundleCapability.cls#ConnectApi.BundleCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/BundleCapability.cls8�
0connectapi.busobjassociationsinputrepresentation%BusObjAssociationsInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusObjAssociationsInputRepresentation.cls#ConnectApi.BusObjAssociationsInputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/BusObjAssociationsInputRepresentation.cls8�
1connectapi.busobjassociationsoutputrepresentation&BusObjAssociationsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusObjAssociationsOutputRepresentation.cls#ConnectApi.BusObjAssociationsOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/BusObjAssociationsOutputRepresentation.cls8�
$connectapi.busobjinputrepresentationBusObjInputRepresentation
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/BusObjInputRepresentation.cls#ConnectApi.BusObjInputRepresentation2Papexlib://resources/StandardApexLibrary/ConnectApi/BusObjInputRepresentation.cls8�
,connectapi.busobjinsightsinputrepresentation!BusObjInsightsInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusObjInsightsInputRepresentation.cls#ConnectApi.BusObjInsightsInputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/BusObjInsightsInputRepresentation.cls8�
-connectapi.busobjinsightsoutputrepresentation"BusObjInsightsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusObjInsightsOutputRepresentation.cls#ConnectApi.BusObjInsightsOutputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/BusObjInsightsOutputRepresentation.cls8�
%connectapi.busobjoutputrepresentationBusObjOutputRepresentation
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/BusObjOutputRepresentation.cls#ConnectApi.BusObjOutputRepresentation2Qapexlib://resources/StandardApexLibrary/ConnectApi/BusObjOutputRepresentation.cls8�
2connectapi.busobjrecommendationinputrepresentation'BusObjRecommendationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusObjRecommendationInputRepresentation.cls#ConnectApi.BusObjRecommendationInputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/BusObjRecommendationInputRepresentation.cls8�
4connectapi.busobjrecommendationsoutputrepresentation)BusObjRecommendationsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusObjRecommendationsOutputRepresentation.cls#ConnectApi.BusObjRecommendationsOutputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/BusObjRecommendationsOutputRepresentation.cls8�
,connectapi.busobjsummaryoutputrepresentation!BusObjSummaryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusObjSummaryOutputRepresentation.cls#ConnectApi.BusObjSummaryOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/BusObjSummaryOutputRepresentation.cls8�
0connectapi.businessobjectivesinputrepresentation%BusinessObjectivesInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusinessObjectivesInputRepresentation.cls#ConnectApi.BusinessObjectivesInputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/BusinessObjectivesInputRepresentation.cls8�
1connectapi.businessobjectivesoutputrepresentation&BusinessObjectivesOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusinessObjectivesOutputRepresentation.cls#ConnectApi.BusinessObjectivesOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/BusinessObjectivesOutputRepresentation.cls8�
8connectapi.businessobjectivessummaryoutputrepresentation-BusinessObjectivesSummaryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/BusinessObjectivesSummaryOutputRepresentation.cls#ConnectApi.BusinessObjectivesSummaryOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/BusinessObjectivesSummaryOutputRepresentation.cls8�
connectapi.calculatecartinputCalculateCartInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CalculateCartInput.cls#ConnectApi.CalculateCartInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/CalculateCartInput.cls8�
connectapi.calculatecartresultCalculateCartResult
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CalculateCartResult.cls#ConnectApi.CalculateCartResult2Japexlib://resources/StandardApexLibrary/ConnectApi/CalculateCartResult.cls8�
connectapi.calculatetaxrequestCalculateTaxRequest
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CalculateTaxRequest.cls#ConnectApi.CalculateTaxRequest2Japexlib://resources/StandardApexLibrary/ConnectApi/CalculateTaxRequest.cls8�
connectapi.calculatetaxresponseCalculateTaxResponse
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CalculateTaxResponse.cls#ConnectApi.CalculateTaxResponse2Kapexlib://resources/StandardApexLibrary/ConnectApi/CalculateTaxResponse.cls8�
connectapi.calculatetaxtypeenumCalculateTaxTypeEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CalculateTaxTypeEnum.cls#ConnectApi.CalculateTaxTypeEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/CalculateTaxTypeEnum.cls8�
&connectapi.callcollaborationcapabilityCallCollaborationCapability
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CallCollaborationCapability.cls#ConnectApi.CallCollaborationCapability2Rapexlib://resources/StandardApexLibrary/ConnectApi/CallCollaborationCapability.cls8�
connectapi.calloutstatusenumCalloutStatusEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/CalloutStatusEnum.cls#ConnectApi.CalloutStatusEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/CalloutStatusEnum.cls8�
7connectapi.cancelallorderitemsasyncoutputrepresentation,CancelAllOrderItemsAsyncOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CancelAllOrderItemsAsyncOutputRepresentation.cls#ConnectApi.CancelAllOrderItemsAsyncOutputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/CancelAllOrderItemsAsyncOutputRepresentation.cls8�
1connectapi.cancelallorderitemsinputrepresentation&CancelAllOrderItemsInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CancelAllOrderItemsInputRepresentation.cls#ConnectApi.CancelAllOrderItemsInputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/CancelAllOrderItemsInputRepresentation.cls8�
!connectapi.candidateanswersstatusCandidateAnswersStatus
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CandidateAnswersStatus.cls#ConnectApi.CandidateAnswersStatus2Mapexlib://resources/StandardApexLibrary/ConnectApi/CandidateAnswersStatus.cls8�
 connectapi.canvasattachmentinputCanvasAttachmentInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CanvasAttachmentInput.cls#ConnectApi.CanvasAttachmentInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/CanvasAttachmentInput.cls8�
connectapi.canvascapabilityCanvasCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CanvasCapability.cls#ConnectApi.CanvasCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/CanvasCapability.cls8�
 connectapi.canvascapabilityinputCanvasCapabilityInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CanvasCapabilityInput.cls#ConnectApi.CanvasCapabilityInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/CanvasCapabilityInput.cls8�
#connectapi.canvastemplateattachmentCanvasTemplateAttachment
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/CanvasTemplateAttachment.cls#ConnectApi.CanvasTemplateAttachment2Oapexlib://resources/StandardApexLibrary/ConnectApi/CanvasTemplateAttachment.cls8�
-connectapi.capacityrequestinputrepresentation"CapacityRequestInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CapacityRequestInputRepresentation.cls#ConnectApi.CapacityRequestInputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/CapacityRequestInputRepresentation.cls8�
/connectapi.capacityresponseoutputrepresentation$CapacityResponseOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CapacityResponseOutputRepresentation.cls#ConnectApi.CapacityResponseOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/CapacityResponseOutputRepresentation.cls8�
&connectapi.capi_feeditemattachmenttypeCapi_FeedItemAttachmentType
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/Capi_FeedItemAttachmentType.cls#ConnectApi.Capi_FeedItemAttachmentType2Rapexlib://resources/StandardApexLibrary/ConnectApi/Capi_FeedItemAttachmentType.cls8�
!connectapi.capturegatewayresponseCaptureGatewayResponse
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CaptureGatewayResponse.cls#ConnectApi.CaptureGatewayResponse2Mapexlib://resources/StandardApexLibrary/ConnectApi/CaptureGatewayResponse.cls8�
connectapi.capturerequestCaptureRequest
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CaptureRequest.cls#ConnectApi.CaptureRequest2Eapexlib://resources/StandardApexLibrary/ConnectApi/CaptureRequest.cls8�
connectapi.captureresponseCaptureResponse
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CaptureResponse.cls#ConnectApi.CaptureResponse2Fapexlib://resources/StandardApexLibrary/ConnectApi/CaptureResponse.cls8�
connectapi.cardcategoryenumCardCategoryEnum
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CardCategoryEnum.cls#ConnectApi.CardCategoryEnum2Gapexlib://resources/StandardApexLibrary/ConnectApi/CardCategoryEnum.cls8�
"connectapi.cardpaymentmethodoutputCardPaymentMethodOutput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/CardPaymentMethodOutput.cls#ConnectApi.CardPaymentMethodOutput2Napexlib://resources/StandardApexLibrary/ConnectApi/CardPaymentMethodOutput.cls8�
#connectapi.cardpaymentmethodrequestCardPaymentMethodRequest
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/CardPaymentMethodRequest.cls#ConnectApi.CardPaymentMethodRequest2Oapexlib://resources/StandardApexLibrary/ConnectApi/CardPaymentMethodRequest.cls8�
connectapi.cardtypeenumCardTypeEnum
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/CardTypeEnum.cls#ConnectApi.CardTypeEnum2Capexlib://resources/StandardApexLibrary/ConnectApi/CardTypeEnum.cls8�
connectapi.cartcoupon
CartCoupon
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/CartCoupon.cls#ConnectApi.CartCoupon2Aapexlib://resources/StandardApexLibrary/ConnectApi/CartCoupon.cls8�
connectapi.cartcouponcollectionCartCouponCollection
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CartCouponCollection.cls#ConnectApi.CartCouponCollection2Kapexlib://resources/StandardApexLibrary/ConnectApi/CartCouponCollection.cls8�
connectapi.cartcouponinputCartCouponInput
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CartCouponInput.cls#ConnectApi.CartCouponInput2Fapexlib://resources/StandardApexLibrary/ConnectApi/CartCouponInput.cls8�
connectapi.cartcouponlistCartCouponList
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CartCouponList.cls#ConnectApi.CartCouponList2Eapexlib://resources/StandardApexLibrary/ConnectApi/CartCouponList.cls8�
$connectapi.cartevaluateshippinginputCartEvaluateShippingInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CartEvaluateShippingInput.cls#ConnectApi.CartEvaluateShippingInput2Papexlib://resources/StandardApexLibrary/ConnectApi/CartEvaluateShippingInput.cls8�
connectapi.cartevaluatetaxinputCartEvaluateTaxInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CartEvaluateTaxInput.cls#ConnectApi.CartEvaluateTaxInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/CartEvaluateTaxInput.cls8�
connectapi.cartinput	CartInput
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/CartInput.cls#ConnectApi.CartInput2@apexlib://resources/StandardApexLibrary/ConnectApi/CartInput.cls8�
connectapi.cartitemCartItem
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/CartItem.cls#ConnectApi.CartItem2?apexlib://resources/StandardApexLibrary/ConnectApi/CartItem.cls8�
connectapi.cartitembasicCartItemBasic
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CartItemBasic.cls#ConnectApi.CartItemBasic2Dapexlib://resources/StandardApexLibrary/ConnectApi/CartItemBasic.cls8�
connectapi.cartitembasicresultCartItemBasicResult
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CartItemBasicResult.cls#ConnectApi.CartItemBasicResult2Japexlib://resources/StandardApexLibrary/ConnectApi/CartItemBasicResult.cls8�
connectapi.cartitemcollectionCartItemCollection
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CartItemCollection.cls#ConnectApi.CartItemCollection2Iapexlib://resources/StandardApexLibrary/ConnectApi/CartItemCollection.cls8�
connectapi.cartiteminputCartItemInput
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CartItemInput.cls#ConnectApi.CartItemInput2Dapexlib://resources/StandardApexLibrary/ConnectApi/CartItemInput.cls8�
connectapi.cartitemproductCartItemProduct
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CartItemProduct.cls#ConnectApi.CartItemProduct2Fapexlib://resources/StandardApexLibrary/ConnectApi/CartItemProduct.cls8�
9connectapi.cartitempromotioncollectioninputrepresentation.CartItemPromotionCollectionInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CartItemPromotionCollectionInputRepresentation.cls#ConnectApi.CartItemPromotionCollectionInputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/CartItemPromotionCollectionInputRepresentation.cls8�
:connectapi.cartitempromotioncollectionoutputrepresentation/CartItemPromotionCollectionOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CartItemPromotionCollectionOutputRepresentation.cls#ConnectApi.CartItemPromotionCollectionOutputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/CartItemPromotionCollectionOutputRepresentation.cls8�
/connectapi.cartitempromotioninputrepresentation$CartItemPromotionInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CartItemPromotionInputRepresentation.cls#ConnectApi.CartItemPromotionInputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/CartItemPromotionInputRepresentation.cls8�
connectapi.cartitemresultCartItemResult
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CartItemResult.cls#ConnectApi.CartItemResult2Eapexlib://resources/StandardApexLibrary/ConnectApi/CartItemResult.cls8�
 connectapi.cartitemsortorderenumCartItemSortOrderEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CartItemSortOrderEnum.cls#ConnectApi.CartItemSortOrderEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/CartItemSortOrderEnum.cls8�
connectapi.cartitemsubtypeenumCartItemSubTypeEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CartItemSubTypeEnum.cls#ConnectApi.CartItemSubTypeEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/CartItemSubTypeEnum.cls8�
connectapi.cartitemtypeenumCartItemTypeEnum
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CartItemTypeEnum.cls#ConnectApi.CartItemTypeEnum2Gapexlib://resources/StandardApexLibrary/ConnectApi/CartItemTypeEnum.cls8�
connectapi.cartitemwithoutpriceCartItemWithoutPrice
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CartItemWithoutPrice.cls#ConnectApi.CartItemWithoutPrice2Kapexlib://resources/StandardApexLibrary/ConnectApi/CartItemWithoutPrice.cls8�
connectapi.cartmessageCartMessage
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/CartMessage.cls#ConnectApi.CartMessage2Bapexlib://resources/StandardApexLibrary/ConnectApi/CartMessage.cls8�
"connectapi.cartmessageseverityenumCartMessageSeverityEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/CartMessageSeverityEnum.cls#ConnectApi.CartMessageSeverityEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/CartMessageSeverityEnum.cls8�
connectapi.cartmessagessummaryCartMessagesSummary
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CartMessagesSummary.cls#ConnectApi.CartMessagesSummary2Japexlib://resources/StandardApexLibrary/ConnectApi/CartMessagesSummary.cls8�
&connectapi.cartmessagesvisibilityinputCartMessagesVisibilityInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CartMessagesVisibilityInput.cls#ConnectApi.CartMessagesVisibilityInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/CartMessagesVisibilityInput.cls8�
'connectapi.cartmessagesvisibilityresultCartMessagesVisibilityResult
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/CartMessagesVisibilityResult.cls#ConnectApi.CartMessagesVisibilityResult2Sapexlib://resources/StandardApexLibrary/ConnectApi/CartMessagesVisibilityResult.cls8�
connectapi.cartproductattributeCartProductAttribute
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CartProductAttribute.cls#ConnectApi.CartProductAttribute2Kapexlib://resources/StandardApexLibrary/ConnectApi/CartProductAttribute.cls8�
"connectapi.cartpromotioncollectionCartPromotionCollection
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionCollection.cls#ConnectApi.CartPromotionCollection2Napexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionCollection.cls8�
connectapi.cartpromotionlistCartPromotionList
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionList.cls#ConnectApi.CartPromotionList2Hapexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionList.cls8�
,connectapi.cartpromotionoutputrepresentation!CartPromotionOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionOutputRepresentation.cls#ConnectApi.CartPromotionOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionOutputRepresentation.cls8�
 connectapi.cartpromotiontypeenumCartPromotionTypeEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionTypeEnum.cls#ConnectApi.CartPromotionTypeEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/CartPromotionTypeEnum.cls8�
#connectapi.cartshippingaddressinputCartShippingAddressInput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/CartShippingAddressInput.cls#ConnectApi.CartShippingAddressInput2Oapexlib://resources/StandardApexLibrary/ConnectApi/CartShippingAddressInput.cls8�
connectapi.cartstatusenumCartStatusEnum
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CartStatusEnum.cls#ConnectApi.CartStatusEnum2Eapexlib://resources/StandardApexLibrary/ConnectApi/CartStatusEnum.cls8�
connectapi.cartsummaryCartSummary
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/CartSummary.cls#ConnectApi.CartSummary2Bapexlib://resources/StandardApexLibrary/ConnectApi/CartSummary.cls8�
connectapi.carttaxtypeenumCartTaxTypeEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CartTaxTypeEnum.cls#ConnectApi.CartTaxTypeEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/CartTaxTypeEnum.cls8�
connectapi.carttowishlistinputCartToWishlistInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CartToWishlistInput.cls#ConnectApi.CartToWishlistInput2Japexlib://resources/StandardApexLibrary/ConnectApi/CartToWishlistInput.cls8�
connectapi.carttowishlistresultCartToWishlistResult
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CartToWishlistResult.cls#ConnectApi.CartToWishlistResult2Kapexlib://resources/StandardApexLibrary/ConnectApi/CartToWishlistResult.cls8�
connectapi.carttypeenumCartTypeEnum
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/CartTypeEnum.cls#ConnectApi.CartTypeEnum2Capexlib://resources/StandardApexLibrary/ConnectApi/CartTypeEnum.cls8�
connectapi.caseactorenumCaseActorEnum
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CaseActorEnum.cls#ConnectApi.CaseActorEnum2Dapexlib://resources/StandardApexLibrary/ConnectApi/CaseActorEnum.cls8�
connectapi.casecommentCaseComment
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/CaseComment.cls#ConnectApi.CaseComment2Bapexlib://resources/StandardApexLibrary/ConnectApi/CaseComment.cls8�
 connectapi.casecommentcapabilityCaseCommentCapability
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CaseCommentCapability.cls#ConnectApi.CaseCommentCapability2Lapexlib://resources/StandardApexLibrary/ConnectApi/CaseCommentCapability.cls8�
#connectapi.casecommenteventtypeenumCaseCommentEventTypeEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/CaseCommentEventTypeEnum.cls#ConnectApi.CaseCommentEventTypeEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/CaseCommentEventTypeEnum.cls8�
,connectapi.casestatuspicklistvalueattributes!CaseStatusPicklistValueAttributes
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CaseStatusPicklistValueAttributes.cls#ConnectApi.CaseStatusPicklistValueAttributes2Xapexlib://resources/StandardApexLibrary/ConnectApi/CaseStatusPicklistValueAttributes.cls8�
connectapi.cdpactionresponseCdpActionResponse
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/CdpActionResponse.cls#ConnectApi.CdpActionResponse2Hapexlib://resources/StandardApexLibrary/ConnectApi/CdpActionResponse.cls8�
connectapi.cdpactivationCdpActivation
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CdpActivation.cls#ConnectApi.CdpActivation2Dapexlib://resources/StandardApexLibrary/ConnectApi/CdpActivation.cls8�
connectapi.cdpactivationtargetCdpActivationTarget
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CdpActivationTarget.cls#ConnectApi.CdpActivationTarget2Japexlib://resources/StandardApexLibrary/ConnectApi/CdpActivationTarget.cls8�
connectapi.cdpassetreferenceCdpAssetReference
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/CdpAssetReference.cls#ConnectApi.CdpAssetReference2Hapexlib://resources/StandardApexLibrary/ConnectApi/CdpAssetReference.cls8�
!connectapi.cdpassetreferenceinputCdpAssetReferenceInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CdpAssetReferenceInput.cls#ConnectApi.CdpAssetReferenceInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/CdpAssetReferenceInput.cls8�
connectapi.cdpaudiencedmoCdpAudienceDMO
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CdpAudienceDMO.cls#ConnectApi.CdpAudienceDMO2Eapexlib://resources/StandardApexLibrary/ConnectApi/CdpAudienceDMO.cls8�
connectapi.cdpcalculatedinsightCdpCalculatedInsight
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsight.cls#ConnectApi.CdpCalculatedInsight2Kapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsight.cls8�
)connectapi.cdpcalculatedinsightdatasourceCdpCalculatedInsightDataSource
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightDataSource.cls#ConnectApi.CdpCalculatedInsightDataSource2Uapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightDataSource.cls8�
(connectapi.cdpcalculatedinsightdimensionCdpCalculatedInsightDimension
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightDimension.cls#ConnectApi.CdpCalculatedInsightDimension2Tapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightDimension.cls8�
$connectapi.cdpcalculatedinsightinputCdpCalculatedInsightInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightInput.cls#ConnectApi.CdpCalculatedInsightInput2Papexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightInput.cls8�
&connectapi.cdpcalculatedinsightmeasureCdpCalculatedInsightMeasure
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightMeasure.cls#ConnectApi.CdpCalculatedInsightMeasure2Rapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightMeasure.cls8�
%connectapi.cdpcalculatedinsightoutputCdpCalculatedInsightOutput
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightOutput.cls#ConnectApi.CdpCalculatedInsightOutput2Qapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightOutput.cls8�
#connectapi.cdpcalculatedinsightpageCdpCalculatedInsightPage
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightPage.cls#ConnectApi.CdpCalculatedInsightPage2Oapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightPage.cls8�
'connectapi.cdpcalculatedinsightpagedataCdpCalculatedInsightPageData
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightPageData.cls#ConnectApi.CdpCalculatedInsightPageData2Sapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightPageData.cls8�
Cconnectapi.cdpcalculatedinsightstandardactionresponserepresentation8CdpCalculatedInsightStandardActionResponseRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightStandardActionResponseRepresentation.cls#ConnectApi.CdpCalculatedInsightStandardActionResponseRepresentation2oapexlib://resources/StandardApexLibrary/ConnectApi/CdpCalculatedInsightStandardActionResponseRepresentation.cls8�
connectapi.cdpconnectionCdpConnection
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CdpConnection.cls#ConnectApi.CdpConnection2Dapexlib://resources/StandardApexLibrary/ConnectApi/CdpConnection.cls8�
connectapi.cdpdataspaceCdpDataSpace
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/CdpDataSpace.cls#ConnectApi.CdpDataSpace2Capexlib://resources/StandardApexLibrary/ConnectApi/CdpDataSpace.cls8�
connectapi.cdpdatastreamsCdpDataStreams
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CdpDataStreams.cls#ConnectApi.CdpDataStreams2Eapexlib://resources/StandardApexLibrary/ConnectApi/CdpDataStreams.cls8�
connectapi.cdpdgmetadataCdpDgMetadata
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CdpDgMetadata.cls#ConnectApi.CdpDgMetadata2Dapexlib://resources/StandardApexLibrary/ConnectApi/CdpDgMetadata.cls8�
connectapi.cdperrorresponseCdpErrorResponse
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CdpErrorResponse.cls#ConnectApi.CdpErrorResponse2Gapexlib://resources/StandardApexLibrary/ConnectApi/CdpErrorResponse.cls8�
 connectapi.cdpidentityresolutionCdpIdentityResolution
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolution.cls#ConnectApi.CdpIdentityResolution2Lapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolution.cls8�
+connectapi.cdpidentityresolutionconfiginput CdpIdentityResolutionConfigInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionConfigInput.cls#ConnectApi.CdpIdentityResolutionConfigInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionConfigInput.cls8�
0connectapi.cdpidentityresolutionconfigpatchinput%CdpIdentityResolutionConfigPatchInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionConfigPatchInput.cls#ConnectApi.CdpIdentityResolutionConfigPatchInput2\apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionConfigPatchInput.cls8�
1connectapi.cdpidentityresolutionconfigurationtype&CdpIdentityResolutionConfigurationType
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionConfigurationType.cls#ConnectApi.CdpIdentityResolutionConfigurationType2]apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionConfigurationType.cls8�
.connectapi.cdpidentityresolutionmatchcriterion#CdpIdentityResolutionMatchCriterion
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterion.cls#ConnectApi.CdpIdentityResolutionMatchCriterion2Zapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterion.cls8�
4connectapi.cdpidentityresolutionmatchcriterionoutput)CdpIdentityResolutionMatchCriterionOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterionOutput.cls#ConnectApi.CdpIdentityResolutionMatchCriterionOutput2`apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterionOutput.cls8�
Econnectapi.cdpidentityresolutionmatchcriterionpartyidentificationinfo:CdpIdentityResolutionMatchCriterionPartyIdentificationInfo
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterionPartyIdentificationInfo.cls#ConnectApi.CdpIdentityResolutionMatchCriterionPartyIdentificationInfo2qapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterionPartyIdentificationInfo.cls8�
Kconnectapi.cdpidentityresolutionmatchcriterionpartyidentificationinfooutput@CdpIdentityResolutionMatchCriterionPartyIdentificationInfoOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterionPartyIdentificationInfoOutput.cls#ConnectApi.CdpIdentityResolutionMatchCriterionPartyIdentificationInfoOutput2wapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchCriterionPartyIdentificationInfoOutput.cls8�
/connectapi.cdpidentityresolutionmatchmethodtype$CdpIdentityResolutionMatchMethodType
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchMethodType.cls#ConnectApi.CdpIdentityResolutionMatchMethodType2[apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchMethodType.cls8�
)connectapi.cdpidentityresolutionmatchruleCdpIdentityResolutionMatchRule
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchRule.cls#ConnectApi.CdpIdentityResolutionMatchRule2Uapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchRule.cls8�
/connectapi.cdpidentityresolutionmatchruleoutput$CdpIdentityResolutionMatchRuleOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchRuleOutput.cls#ConnectApi.CdpIdentityResolutionMatchRuleOutput2[apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionMatchRuleOutput.cls8�
&connectapi.cdpidentityresolutionoutputCdpIdentityResolutionOutput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionOutput.cls#ConnectApi.CdpIdentityResolutionOutput2Rapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionOutput.cls8�
7connectapi.cdpidentityresolutionreconciliationfieldrule,CdpIdentityResolutionReconciliationFieldRule
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationFieldRule.cls#ConnectApi.CdpIdentityResolutionReconciliationFieldRule2capexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationFieldRule.cls8�
=connectapi.cdpidentityresolutionreconciliationfieldruleoutput2CdpIdentityResolutionReconciliationFieldRuleOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationFieldRuleOutput.cls#ConnectApi.CdpIdentityResolutionReconciliationFieldRuleOutput2iapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationFieldRuleOutput.cls8�
2connectapi.cdpidentityresolutionreconciliationrule'CdpIdentityResolutionReconciliationRule
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationRule.cls#ConnectApi.CdpIdentityResolutionReconciliationRule2^apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationRule.cls8�
8connectapi.cdpidentityresolutionreconciliationruleoutput-CdpIdentityResolutionReconciliationRuleOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationRuleOutput.cls#ConnectApi.CdpIdentityResolutionReconciliationRuleOutput2dapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationRuleOutput.cls8�
6connectapi.cdpidentityresolutionreconciliationruletype+CdpIdentityResolutionReconciliationRuleType
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationRuleType.cls#ConnectApi.CdpIdentityResolutionReconciliationRuleType2bapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationRuleType.cls8�
4connectapi.cdpidentityresolutionreconciliationsource)CdpIdentityResolutionReconciliationSource
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationSource.cls#ConnectApi.CdpIdentityResolutionReconciliationSource2`apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationSource.cls8�
:connectapi.cdpidentityresolutionreconciliationsourceoutput/CdpIdentityResolutionReconciliationSourceOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationSourceOutput.cls#ConnectApi.CdpIdentityResolutionReconciliationSourceOutput2fapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionReconciliationSourceOutput.cls8�
+connectapi.cdpidentityresolutionrunnowinput CdpIdentityResolutionRunNowInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionRunNowInput.cls#ConnectApi.CdpIdentityResolutionRunNowInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionRunNowInput.cls8�
,connectapi.cdpidentityresolutionrunnowoutput!CdpIdentityResolutionRunNowOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionRunNowOutput.cls#ConnectApi.CdpIdentityResolutionRunNowOutput2Xapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionRunNowOutput.cls8�
0connectapi.cdpidentityresolutionrunnowresultcode%CdpIdentityResolutionRunNowResultCode
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionRunNowResultCode.cls#ConnectApi.CdpIdentityResolutionRunNowResultCode2\apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionRunNowResultCode.cls8�
'connectapi.cdpidentityresolutionsoutputCdpIdentityResolutionsOutput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionsOutput.cls#ConnectApi.CdpIdentityResolutionsOutput2Sapexlib://resources/StandardApexLibrary/ConnectApi/CdpIdentityResolutionsOutput.cls8�
)connectapi.cdpmlaggregatepredictconditionCdpMlAggregatePredictCondition
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/CdpMlAggregatePredictCondition.cls#ConnectApi.CdpMlAggregatePredictCondition2Uapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlAggregatePredictCondition.cls8�
#connectapi.cdpmlaggregatepredictionCdpMlAggregatePrediction
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlAggregatePrediction.cls#ConnectApi.CdpMlAggregatePrediction2Oapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlAggregatePrediction.cls8�
 connectapi.cdpmlbasepredictinputCdpMlBasePredictInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlBasePredictInput.cls#ConnectApi.CdpMlBasePredictInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlBasePredictInput.cls8�
'connectapi.cdpmlmodelpredictiontypeenumCdpMlModelPredictionTypeEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/CdpMlModelPredictionTypeEnum.cls#ConnectApi.CdpMlModelPredictionTypeEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlModelPredictionTypeEnum.cls8�
2connectapi.cdpmlpredictaggregatefunctionstatusenum'CdpMlPredictAggregateFunctionStatusEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictAggregateFunctionStatusEnum.cls#ConnectApi.CdpMlPredictAggregateFunctionStatusEnum2^apexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictAggregateFunctionStatusEnum.cls8�
0connectapi.cdpmlpredictaggregatefunctiontypeenum%CdpMlPredictAggregateFunctionTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictAggregateFunctionTypeEnum.cls#ConnectApi.CdpMlPredictAggregateFunctionTypeEnum2\apexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictAggregateFunctionTypeEnum.cls8�
connectapi.cdpmlpredictresultCdpMlPredictResult
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictResult.cls#ConnectApi.CdpMlPredictResult2Iapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictResult.cls8�
connectapi.cdpmlpredictsettingsCdpMlPredictSettings
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictSettings.cls#ConnectApi.CdpMlPredictSettings2Kapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictSettings.cls8�
$connectapi.cdpmlpredictsettingsinputCdpMlPredictSettingsInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictSettingsInput.cls#ConnectApi.CdpMlPredictSettingsInput2Papexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictSettingsInput.cls8�
!connectapi.cdpmlpredictstatusenumCdpMlPredictStatusEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictStatusEnum.cls#ConnectApi.CdpMlPredictStatusEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictStatusEnum.cls8�
connectapi.cdpmlpredicttypeenumCdpMlPredictTypeEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictTypeEnum.cls#ConnectApi.CdpMlPredictTypeEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictTypeEnum.cls8�
connectapi.cdpmlpredictionbaseCdpMlPredictionBase
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictionBase.cls#ConnectApi.CdpMlPredictionBase2Japexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictionBase.cls8�
*connectapi.cdpmlpredictioncontributionbaseCdpMlPredictionContributionBase
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictionContributionBase.cls#ConnectApi.CdpMlPredictionContributionBase2Vapexlib://resources/StandardApexLibrary/ConnectApi/CdpMlPredictionContributionBase.cls8�
connectapi.cdpqueryCdpQuery
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/CdpQuery.cls#ConnectApi.CdpQuery2?apexlib://resources/StandardApexLibrary/ConnectApi/CdpQuery.cls8�
$connectapi.cdpquerydatagraphmetadataCdpQueryDataGraphMetadata
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryDataGraphMetadata.cls#ConnectApi.CdpQueryDataGraphMetadata2Papexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryDataGraphMetadata.cls8�
connectapi.cdpquerydataoutputCdpQueryDataOutput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryDataOutput.cls#ConnectApi.CdpQueryDataOutput2Iapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryDataOutput.cls8�
connectapi.cdpqueryinputCdpQueryInput
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryInput.cls#ConnectApi.CdpQueryInput2Dapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryInput.cls8�
connectapi.cdpquerymetadataitemCdpQueryMetadataItem
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryMetadataItem.cls#ConnectApi.CdpQueryMetadataItem2Kapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryMetadataItem.cls8�
!connectapi.cdpquerymetadataoutputCdpQueryMetadataOutput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryMetadataOutput.cls#ConnectApi.CdpQueryMetadataOutput2Mapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryMetadataOutput.cls8�
connectapi.cdpqueryoutputCdpQueryOutput
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryOutput.cls#ConnectApi.CdpQueryOutput2Eapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryOutput.cls8�
connectapi.cdpqueryoutputv2CdpQueryOutputV2
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryOutputV2.cls#ConnectApi.CdpQueryOutputV22Gapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryOutputV2.cls8�
connectapi.cdpqueryv2rowCdpQueryV2Row
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryV2Row.cls#ConnectApi.CdpQueryV2Row2Dapexlib://resources/StandardApexLibrary/ConnectApi/CdpQueryV2Row.cls8�
connectapi.cdpsegment
CdpSegment
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegment.cls#ConnectApi.CdpSegment2Aapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegment.cls8�
!connectapi.cdpsegmentactionoutputCdpSegmentActionOutput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentActionOutput.cls#ConnectApi.CdpSegmentActionOutput2Mapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentActionOutput.cls8�
$connectapi.cdpsegmentcontaineroutputCdpSegmentContainerOutput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentContainerOutput.cls#ConnectApi.CdpSegmentContainerOutput2Papexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentContainerOutput.cls8�
connectapi.cdpsegmentdbtinputCdpSegmentDbtInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtInput.cls#ConnectApi.CdpSegmentDbtInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtInput.cls8�
connectapi.cdpsegmentdbtmodelCdpSegmentDbtModel
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtModel.cls#ConnectApi.CdpSegmentDbtModel2Iapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtModel.cls8�
"connectapi.cdpsegmentdbtmodelinputCdpSegmentDbtModelInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtModelInput.cls#ConnectApi.CdpSegmentDbtModelInput2Napexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtModelInput.cls8�
 connectapi.cdpsegmentdbtpipelineCdpSegmentDbtPipeline
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtPipeline.cls#ConnectApi.CdpSegmentDbtPipeline2Lapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentDbtPipeline.cls8�
connectapi.cdpsegmentinputCdpSegmentInput
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentInput.cls#ConnectApi.CdpSegmentInput2Fapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentInput.cls8�
!connectapi.cdpsegmentmemberoutputCdpSegmentMemberOutput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentMemberOutput.cls#ConnectApi.CdpSegmentMemberOutput2Mapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentMemberOutput.cls8�
$connectapi.cdpsegmentmemberrowoutputCdpSegmentMemberRowOutput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentMemberRowOutput.cls#ConnectApi.CdpSegmentMemberRowOutput2Papexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentMemberRowOutput.cls8�
*connectapi.cdpsegmentmembershiptableoutputCdpSegmentMembershipTableOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentMembershipTableOutput.cls#ConnectApi.CdpSegmentMembershipTableOutput2Vapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentMembershipTableOutput.cls8�
connectapi.cdpsegmentoutputCdpSegmentOutput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentOutput.cls#ConnectApi.CdpSegmentOutput2Gapexlib://resources/StandardApexLibrary/ConnectApi/CdpSegmentOutput.cls8�
connectapi.cdpmachinelearningCdpMachineLearning
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/Cdpmachinelearning.cls#ConnectApi.CdpMachineLearning2Iapexlib://resources/StandardApexLibrary/ConnectApi/Cdpmachinelearning.cls8�
$connectapi.changeinputrepresentationChangeInputRepresentation
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ChangeInputRepresentation.cls#ConnectApi.ChangeInputRepresentation2Papexlib://resources/StandardApexLibrary/ConnectApi/ChangeInputRepresentation.cls8�
+connectapi.changeitemfeeinputrepresentation ChangeItemFeeInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemFeeInputRepresentation.cls#ConnectApi.ChangeItemFeeInputRepresentation2Wapexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemFeeInputRepresentation.cls8�
.connectapi.changeitemfeetaxinputrepresentation#ChangeItemFeeTaxInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemFeeTaxInputRepresentation.cls#ConnectApi.ChangeItemFeeTaxInputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemFeeTaxInputRepresentation.cls8�
2connectapi.changeitemfeewithtaxinputrepresentation'ChangeItemFeeWithTaxInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemFeeWithTaxInputRepresentation.cls#ConnectApi.ChangeItemFeeWithTaxInputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemFeeWithTaxInputRepresentation.cls8�
(connectapi.changeiteminputrepresentationChangeItemInputRepresentation
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemInputRepresentation.cls#ConnectApi.ChangeItemInputRepresentation2Tapexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemInputRepresentation.cls8�
)connectapi.changeitemoutputrepresentationChangeItemOutputRepresentation
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemOutputRepresentation.cls#ConnectApi.ChangeItemOutputRepresentation2Uapexlib://resources/StandardApexLibrary/ConnectApi/ChangeItemOutputRepresentation.cls8�
2connectapi.changeordersinvoiceoutputrepresentation'ChangeOrdersInvoiceOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ChangeOrdersInvoiceOutputRepresentation.cls#ConnectApi.ChangeOrdersInvoiceOutputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/ChangeOrdersInvoiceOutputRepresentation.cls8�
connectapi.chatterChatter
ConnectApi *Qapexlib://resources/StandardApexLibrary/ConnectApi/Chatter.cls#ConnectApi.Chatter2>apexlib://resources/StandardApexLibrary/ConnectApi/Chatter.cls8�
connectapi.chatteractivityChatterActivity
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ChatterActivity.cls#ConnectApi.ChatterActivity2Fapexlib://resources/StandardApexLibrary/ConnectApi/ChatterActivity.cls8�
!connectapi.chatteractivitysummaryChatterActivitySummary
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ChatterActivitySummary.cls#ConnectApi.ChatterActivitySummary2Mapexlib://resources/StandardApexLibrary/ConnectApi/ChatterActivitySummary.cls8�
connectapi.chatterconversationChatterConversation
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ChatterConversation.cls#ConnectApi.ChatterConversation2Japexlib://resources/StandardApexLibrary/ConnectApi/ChatterConversation.cls8�
"connectapi.chatterconversationpageChatterConversationPage
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ChatterConversationPage.cls#ConnectApi.ChatterConversationPage2Napexlib://resources/StandardApexLibrary/ConnectApi/ChatterConversationPage.cls8�
%connectapi.chatterconversationsummaryChatterConversationSummary
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ChatterConversationSummary.cls#ConnectApi.ChatterConversationSummary2Qapexlib://resources/StandardApexLibrary/ConnectApi/ChatterConversationSummary.cls8�
connectapi.chatterfavoritesChatterFavorites
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/ChatterFavorites.cls#ConnectApi.ChatterFavorites2Gapexlib://resources/StandardApexLibrary/ConnectApi/ChatterFavorites.cls8�
connectapi.chatterfeedsChatterFeeds
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ChatterFeeds.cls#ConnectApi.ChatterFeeds2Capexlib://resources/StandardApexLibrary/ConnectApi/ChatterFeeds.cls8�
connectapi.chattergroupChatterGroup
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroup.cls#ConnectApi.ChatterGroup2Capexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroup.cls8�
connectapi.chattergroupdetailChatterGroupDetail
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupDetail.cls#ConnectApi.ChatterGroupDetail2Iapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupDetail.cls8�
connectapi.chattergroupinputChatterGroupInput
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupInput.cls#ConnectApi.ChatterGroupInput2Hapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupInput.cls8�
connectapi.chattergrouppageChatterGroupPage
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupPage.cls#ConnectApi.ChatterGroupPage2Gapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupPage.cls8�
connectapi.chattergroupsummaryChatterGroupSummary
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupSummary.cls#ConnectApi.ChatterGroupSummary2Japexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupSummary.cls8�
"connectapi.chattergroupsummarypageChatterGroupSummaryPage
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupSummaryPage.cls#ConnectApi.ChatterGroupSummaryPage2Napexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroupSummaryPage.cls8�
connectapi.chattergroupsChatterGroups
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroups.cls#ConnectApi.ChatterGroups2Dapexlib://resources/StandardApexLibrary/ConnectApi/ChatterGroups.cls8�
connectapi.chatterlikeChatterLike
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/ChatterLike.cls#ConnectApi.ChatterLike2Bapexlib://resources/StandardApexLibrary/ConnectApi/ChatterLike.cls8�
connectapi.chatterlikepageChatterLikePage
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ChatterLikePage.cls#ConnectApi.ChatterLikePage2Fapexlib://resources/StandardApexLibrary/ConnectApi/ChatterLikePage.cls8�
!connectapi.chatterlikescapabilityChatterLikesCapability
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ChatterLikesCapability.cls#ConnectApi.ChatterLikesCapability2Mapexlib://resources/StandardApexLibrary/ConnectApi/ChatterLikesCapability.cls8�
connectapi.chattermessageChatterMessage
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ChatterMessage.cls#ConnectApi.ChatterMessage2Eapexlib://resources/StandardApexLibrary/ConnectApi/ChatterMessage.cls8�
connectapi.chattermessagepageChatterMessagePage
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ChatterMessagePage.cls#ConnectApi.ChatterMessagePage2Iapexlib://resources/StandardApexLibrary/ConnectApi/ChatterMessagePage.cls8�
connectapi.chattermessagesChatterMessages
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ChatterMessages.cls#ConnectApi.ChatterMessages2Fapexlib://resources/StandardApexLibrary/ConnectApi/ChatterMessages.cls8�
connectapi.chatterstreamChatterStream
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/ChatterStream.cls#ConnectApi.ChatterStream2Dapexlib://resources/StandardApexLibrary/ConnectApi/ChatterStream.cls8�
connectapi.chatterstreaminputChatterStreamInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ChatterStreamInput.cls#ConnectApi.ChatterStreamInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/ChatterStreamInput.cls8�
connectapi.chatterstreampageChatterStreamPage
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/ChatterStreamPage.cls#ConnectApi.ChatterStreamPage2Hapexlib://resources/StandardApexLibrary/ConnectApi/ChatterStreamPage.cls8�
connectapi.chatterusersChatterUsers
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ChatterUsers.cls#ConnectApi.ChatterUsers2Capexlib://resources/StandardApexLibrary/ConnectApi/ChatterUsers.cls8�
connectapi.chunkChunk
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Chunk.cls#ConnectApi.Chunk2<apexlib://resources/StandardApexLibrary/ConnectApi/Chunk.cls8�
connectapi.clientinfo
ClientInfo
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/ClientInfo.cls#ConnectApi.ClientInfo2Aapexlib://resources/StandardApexLibrary/ConnectApi/ClientInfo.cls8�
connectapi.clmClm
ConnectApi *Iapexlib://resources/StandardApexLibrary/ConnectApi/Clm.cls#ConnectApi.Clm2:apexlib://resources/StandardApexLibrary/ConnectApi/Clm.cls8�
connectapi.closecapabilityCloseCapability
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CloseCapability.cls#ConnectApi.CloseCapability2Fapexlib://resources/StandardApexLibrary/ConnectApi/CloseCapability.cls8�
connectapi.clumptypeenumClumpTypeEnum
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/ClumpTypeEnum.cls#ConnectApi.ClumpTypeEnum2Dapexlib://resources/StandardApexLibrary/ConnectApi/ClumpTypeEnum.cls8�
connectapi.commentComment
ConnectApi *Qapexlib://resources/StandardApexLibrary/ConnectApi/Comment.cls#ConnectApi.Comment2>apexlib://resources/StandardApexLibrary/ConnectApi/Comment.cls8�
connectapi.commentcapabilitiesCommentCapabilities
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CommentCapabilities.cls#ConnectApi.CommentCapabilities2Japexlib://resources/StandardApexLibrary/ConnectApi/CommentCapabilities.cls8�
#connectapi.commentcapabilitiesinputCommentCapabilitiesInput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/CommentCapabilitiesInput.cls#ConnectApi.CommentCapabilitiesInput2Oapexlib://resources/StandardApexLibrary/ConnectApi/CommentCapabilitiesInput.cls8�
connectapi.commentinputCommentInput
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/CommentInput.cls#ConnectApi.CommentInput2Capexlib://resources/StandardApexLibrary/ConnectApi/CommentInput.cls8�
connectapi.commentpageCommentPage
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/CommentPage.cls#ConnectApi.CommentPage2Bapexlib://resources/StandardApexLibrary/ConnectApi/CommentPage.cls8�
connectapi.commentsummaryCommentSummary
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CommentSummary.cls#ConnectApi.CommentSummary2Eapexlib://resources/StandardApexLibrary/ConnectApi/CommentSummary.cls8�
connectapi.commenttypeenumCommentTypeEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CommentTypeEnum.cls#ConnectApi.CommentTypeEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/CommentTypeEnum.cls8�
connectapi.commentscapabilityCommentsCapability
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CommentsCapability.cls#ConnectApi.CommentsCapability2Iapexlib://resources/StandardApexLibrary/ConnectApi/CommentsCapability.cls8�
connectapi.commerceactionresultCommerceActionResult
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CommerceActionResult.cls#ConnectApi.CommerceActionResult2Kapexlib://resources/StandardApexLibrary/ConnectApi/CommerceActionResult.cls8�
$connectapi.commerceaddresscollectionCommerceAddressCollection
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressCollection.cls#ConnectApi.CommerceAddressCollection2Papexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressCollection.cls8�
$connectapi.commerceaddressfieldinputCommerceAddressFieldInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressFieldInput.cls#ConnectApi.CommerceAddressFieldInput2Papexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressFieldInput.cls8�
connectapi.commerceaddressinputCommerceAddressInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressInput.cls#ConnectApi.CommerceAddressInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressInput.cls8�
 connectapi.commerceaddressoutputCommerceAddressOutput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressOutput.cls#ConnectApi.CommerceAddressOutput2Lapexlib://resources/StandardApexLibrary/ConnectApi/CommerceAddressOutput.cls8�
"connectapi.commercebuyerexperienceCommerceBuyerExperience
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/CommerceBuyerExperience.cls#ConnectApi.CommerceBuyerExperience2Napexlib://resources/StandardApexLibrary/ConnectApi/CommerceBuyerExperience.cls8�
connectapi.commercecartCommerceCart
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/CommerceCart.cls#ConnectApi.CommerceCart2Capexlib://resources/StandardApexLibrary/ConnectApi/CommerceCart.cls8�
connectapi.commercecatalogCommerceCatalog
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CommerceCatalog.cls#ConnectApi.CommerceCatalog2Fapexlib://resources/StandardApexLibrary/ConnectApi/CommerceCatalog.cls8�
$connectapi.commercecatalogmanagementCommerceCatalogManagement
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CommerceCatalogManagement.cls#ConnectApi.CommerceCatalogManagement2Papexlib://resources/StandardApexLibrary/ConnectApi/CommerceCatalogManagement.cls8�
'connectapi.commerceproductsearchresultsCommerceProductSearchResults
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSearchResults.cls#ConnectApi.CommerceProductSearchResults2Sapexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSearchResults.cls8�
&connectapi.commerceproductsellingmodelCommerceProductSellingModel
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSellingModel.cls#ConnectApi.CommerceProductSellingModel2Rapexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSellingModel.cls8�
!connectapi.commerceproductsummaryCommerceProductSummary
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSummary.cls#ConnectApi.CommerceProductSummary2Mapexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSummary.cls8�
%connectapi.commerceproductsummarypageCommerceProductSummaryPage
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSummaryPage.cls#ConnectApi.CommerceProductSummaryPage2Qapexlib://resources/StandardApexLibrary/ConnectApi/CommerceProductSummaryPage.cls8�
connectapi.commercepromotionsCommercePromotions
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CommercePromotions.cls#ConnectApi.CommercePromotions2Iapexlib://resources/StandardApexLibrary/ConnectApi/CommercePromotions.cls8�
+connectapi.commerceresultrepresentationbase CommerceResultRepresentationBase
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceResultRepresentationBase.cls#ConnectApi.CommerceResultRepresentationBase2Wapexlib://resources/StandardApexLibrary/ConnectApi/CommerceResultRepresentationBase.cls8�
connectapi.commercesearchCommerceSearch
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearch.cls#ConnectApi.CommerceSearch2Eapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearch.cls8�
*connectapi.commercesearchattributetypeenumCommerceSearchAttributeTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchAttributeTypeEnum.cls#ConnectApi.CommerceSearchAttributeTypeEnum2Vapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchAttributeTypeEnum.cls8�
&connectapi.commercesearchconnectfamilyCommerceSearchConnectFamily
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchConnectFamily.cls#ConnectApi.CommerceSearchConnectFamily2Rapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchConnectFamily.cls8�
-connectapi.commercesearchfacetdisplaytypeenum"CommerceSearchFacetDisplayTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchFacetDisplayTypeEnum.cls#ConnectApi.CommerceSearchFacetDisplayTypeEnum2Yapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchFacetDisplayTypeEnum.cls8�
&connectapi.commercesearchfacettypeenumCommerceSearchFacetTypeEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchFacetTypeEnum.cls#ConnectApi.CommerceSearchFacetTypeEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchFacetTypeEnum.cls8�
+connectapi.commercesearchgroupingoptionenum CommerceSearchGroupingOptionEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchGroupingOptionEnum.cls#ConnectApi.CommerceSearchGroupingOptionEnum2Wapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchGroupingOptionEnum.cls8�
connectapi.commercesearchindexCommerceSearchIndex
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndex.cls#ConnectApi.CommerceSearchIndex2Japexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndex.cls8�
+connectapi.commercesearchindexbuildtypeenum CommerceSearchIndexBuildTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexBuildTypeEnum.cls#ConnectApi.CommerceSearchIndexBuildTypeEnum2Wapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexBuildTypeEnum.cls8�
(connectapi.commercesearchindexcollectionCommerceSearchIndexCollection
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexCollection.cls#ConnectApi.CommerceSearchIndexCollection2Tapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexCollection.cls8�
.connectapi.commercesearchindexcreationtypeenum#CommerceSearchIndexCreationTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexCreationTypeEnum.cls#ConnectApi.CommerceSearchIndexCreationTypeEnum2Zapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexCreationTypeEnum.cls8�
!connectapi.commercesearchindexlogCommerceSearchIndexLog
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexLog.cls#ConnectApi.CommerceSearchIndexLog2Mapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexLog.cls8�
+connectapi.commercesearchindexlogcollection CommerceSearchIndexLogCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexLogCollection.cls#ConnectApi.CommerceSearchIndexLogCollection2Wapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexLogCollection.cls8�
(connectapi.commercesearchindexstatusenumCommerceSearchIndexStatusEnum
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexStatusEnum.cls#ConnectApi.CommerceSearchIndexStatusEnum2Tapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexStatusEnum.cls8�
'connectapi.commercesearchindexusageenumCommerceSearchIndexUsageEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexUsageEnum.cls#ConnectApi.CommerceSearchIndexUsageEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchIndexUsageEnum.cls8�
!connectapi.commercesearchsettingsCommerceSearchSettings
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSettings.cls#ConnectApi.CommerceSearchSettings2Mapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSettings.cls8�
*connectapi.commercesearchsortruledirectionCommerceSearchSortRuleDirection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSortRuleDirection.cls#ConnectApi.CommerceSearchSortRuleDirection2Vapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSortRuleDirection.cls8�
,connectapi.commercesearchsortrulelabelsuffix!CommerceSearchSortRuleLabelSuffix
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSortRuleLabelSuffix.cls#ConnectApi.CommerceSearchSortRuleLabelSuffix2Xapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSortRuleLabelSuffix.cls8�
%connectapi.commercesearchsortruletypeCommerceSearchSortRuleType
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSortRuleType.cls#ConnectApi.CommerceSearchSortRuleType2Qapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchSortRuleType.cls8�
+connectapi.commercesearchtopproducttypeenum CommerceSearchTopProductTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchTopProductTypeEnum.cls#ConnectApi.CommerceSearchTopProductTypeEnum2Wapexlib://resources/StandardApexLibrary/ConnectApi/CommerceSearchTopProductTypeEnum.cls8�
connectapi.commercestorepricingCommerceStorePricing
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CommerceStorePricing.cls#ConnectApi.CommerceStorePricing2Kapexlib://resources/StandardApexLibrary/ConnectApi/CommerceStorePricing.cls8�
connectapi.commercewishlistCommerceWishlist
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CommerceWishlist.cls#ConnectApi.CommerceWishlist2Gapexlib://resources/StandardApexLibrary/ConnectApi/CommerceWishlist.cls8�
connectapi.communitiesCommunities
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/Communities.cls#ConnectApi.Communities2Bapexlib://resources/StandardApexLibrary/ConnectApi/Communities.cls8�
connectapi.community	Community
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/Community.cls#ConnectApi.Community2@apexlib://resources/StandardApexLibrary/ConnectApi/Community.cls8�
"connectapi.communityflagreasontypeCommunityFlagReasonType
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/CommunityFlagReasonType.cls#ConnectApi.CommunityFlagReasonType2Napexlib://resources/StandardApexLibrary/ConnectApi/CommunityFlagReasonType.cls8�
connectapi.communityflagtypeCommunityFlagType
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/CommunityFlagType.cls#ConnectApi.CommunityFlagType2Hapexlib://resources/StandardApexLibrary/ConnectApi/CommunityFlagType.cls8�
"connectapi.communityflagvisibilityCommunityFlagVisibility
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/CommunityFlagVisibility.cls#ConnectApi.CommunityFlagVisibility2Napexlib://resources/StandardApexLibrary/ConnectApi/CommunityFlagVisibility.cls8�
connectapi.communitymoderationCommunityModeration
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CommunityModeration.cls#ConnectApi.CommunityModeration2Japexlib://resources/StandardApexLibrary/ConnectApi/CommunityModeration.cls8�
connectapi.communitypageCommunityPage
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/CommunityPage.cls#ConnectApi.CommunityPage2Dapexlib://resources/StandardApexLibrary/ConnectApi/CommunityPage.cls8�
connectapi.communitystatusenumCommunityStatusEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CommunityStatusEnum.cls#ConnectApi.CommunityStatusEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/CommunityStatusEnum.cls8�
connectapi.communitysummaryCommunitySummary
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/CommunitySummary.cls#ConnectApi.CommunitySummary2Gapexlib://resources/StandardApexLibrary/ConnectApi/CommunitySummary.cls8�
connectapi.companyverifysummaryCompanyVerifySummary
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CompanyVerifySummary.cls#ConnectApi.CompanyVerifySummary2Kapexlib://resources/StandardApexLibrary/ConnectApi/CompanyVerifySummary.cls8�
connectapi.complexsegmentComplexSegment
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ComplexSegment.cls#ConnectApi.ComplexSegment2Eapexlib://resources/StandardApexLibrary/ConnectApi/ComplexSegment.cls8�
6connectapi.compositecommerceproductinputrepresentation+CompositeCommerceProductInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CompositeCommerceProductInputRepresentation.cls#ConnectApi.CompositeCommerceProductInputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/CompositeCommerceProductInputRepresentation.cls8�
7connectapi.compositecommerceproductoutputrepresentation,CompositeCommerceProductOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CompositeCommerceProductOutputRepresentation.cls#ConnectApi.CompositeCommerceProductOutputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/CompositeCommerceProductOutputRepresentation.cls8�
9connectapi.compositecommercevariationoutputrepresentation.CompositeCommerceVariationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CompositeCommerceVariationOutputRepresentation.cls#ConnectApi.CompositeCommerceVariationOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/CompositeCommerceVariationOutputRepresentation.cls8�
connectapi.compoundrecordfieldCompoundRecordField
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CompoundRecordField.cls#ConnectApi.CompoundRecordField2Japexlib://resources/StandardApexLibrary/ConnectApi/CompoundRecordField.cls8�
 connectapi.compressionformatenumCompressionFormatEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/CompressionFormatEnum.cls#ConnectApi.CompressionFormatEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/CompressionFormatEnum.cls8�
3connectapi.confirmheldfocapacityinputrepresentation(ConfirmHeldFOCapacityInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityInputRepresentation.cls#ConnectApi.ConfirmHeldFOCapacityInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityInputRepresentation.cls8�
4connectapi.confirmheldfocapacityoutputrepresentation)ConfirmHeldFOCapacityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityOutputRepresentation.cls#ConnectApi.ConfirmHeldFOCapacityOutputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityOutputRepresentation.cls8�
:connectapi.confirmheldfocapacityrequestinputrepresentation/ConfirmHeldFOCapacityRequestInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityRequestInputRepresentation.cls#ConnectApi.ConfirmHeldFOCapacityRequestInputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityRequestInputRepresentation.cls8�
<connectapi.confirmheldfocapacityresponseoutputrepresentation1ConfirmHeldFOCapacityResponseOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityResponseOutputRepresentation.cls#ConnectApi.ConfirmHeldFOCapacityResponseOutputRepresentation2hapexlib://resources/StandardApexLibrary/ConnectApi/ConfirmHeldFOCapacityResponseOutputRepresentation.cls8�
"connectapi.connectactivitytypeenumConnectActivityTypeEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ConnectActivityTypeEnum.cls#ConnectApi.ConnectActivityTypeEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/ConnectActivityTypeEnum.cls8�
connectapi.connectapiexceptionConnectApiException
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ConnectApiException.cls#ConnectApi.ConnectApiException2Japexlib://resources/StandardApexLibrary/ConnectApi/ConnectApiException.cls8�
.connectapi.connectcommerceaddresssortorderenum#ConnectCommerceAddressSortOrderEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConnectCommerceAddressSortOrderEnum.cls#ConnectApi.ConnectCommerceAddressSortOrderEnum2Zapexlib://resources/StandardApexLibrary/ConnectApi/ConnectCommerceAddressSortOrderEnum.cls8�
!connectapi.connectinsightunitenumConnectInsightUnitEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ConnectInsightUnitEnum.cls#ConnectApi.ConnectInsightUnitEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/ConnectInsightUnitEnum.cls8�
'connectapi.connectiondbschemacollectionConnectionDbSchemaCollection
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ConnectionDbSchemaCollection.cls#ConnectApi.ConnectionDbSchemaCollection2Sapexlib://resources/StandardApexLibrary/ConnectApi/ConnectionDbSchemaCollection.cls8�
,connectapi.connectiondbschemacollectioninput!ConnectionDbSchemaCollectionInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConnectionDbSchemaCollectionInput.cls#ConnectApi.ConnectionDbSchemaCollectionInput2Xapexlib://resources/StandardApexLibrary/ConnectApi/ConnectionDbSchemaCollectionInput.cls8�
%connectapi.contactpointattributeinputContactPointAttributeInput
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointAttributeInput.cls#ConnectApi.ContactPointAttributeInput2Qapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointAttributeInput.cls8�
connectapi.contactpointconfigContactPointConfig
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointConfig.cls#ConnectApi.ContactPointConfig2Iapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointConfig.cls8�
'connectapi.contactpointfilterexpressionContactPointFilterExpression
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ContactPointFilterExpression.cls#ConnectApi.ContactPointFilterExpression2Sapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointFilterExpression.cls8�
connectapi.contactpointprefenumContactPointPrefEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointPrefEnum.cls#ConnectApi.ContactPointPrefEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointPrefEnum.cls8�
"connectapi.contactpointsourceinputContactPointSourceInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointSourceInput.cls#ConnectApi.ContactPointSourceInput2Napexlib://resources/StandardApexLibrary/ConnectApi/ContactPointSourceInput.cls8�
-connectapi.contactpointtyperepresentationenum"ContactPointTypeRepresentationEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ContactPointTypeRepresentationEnum.cls#ConnectApi.ContactPointTypeRepresentationEnum2Yapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointTypeRepresentationEnum.cls8�
connectapi.contactpointsconfigContactPointsConfig
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ContactPointsConfig.cls#ConnectApi.ContactPointsConfig2Japexlib://resources/StandardApexLibrary/ConnectApi/ContactPointsConfig.cls8�
connectapi.contentContent
ConnectApi *Qapexlib://resources/StandardApexLibrary/ConnectApi/Content.cls#ConnectApi.Content2>apexlib://resources/StandardApexLibrary/ConnectApi/Content.cls8�
connectapi.contentattachmentContentAttachment
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/ContentAttachment.cls#ConnectApi.ContentAttachment2Hapexlib://resources/StandardApexLibrary/ConnectApi/ContentAttachment.cls8�
!connectapi.contentattachmentinputContentAttachmentInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ContentAttachmentInput.cls#ConnectApi.ContentAttachmentInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/ContentAttachmentInput.cls8�
connectapi.contentcapabilityContentCapability
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/ContentCapability.cls#ConnectApi.ContentCapability2Hapexlib://resources/StandardApexLibrary/ConnectApi/ContentCapability.cls8�
!connectapi.contentcapabilityinputContentCapabilityInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ContentCapabilityInput.cls#ConnectApi.ContentCapabilityInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/ContentCapabilityInput.cls8�
.connectapi.contenthuballoweditemtypecollection#ContentHubAllowedItemTypeCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ContentHubAllowedItemTypeCollection.cls#ConnectApi.ContentHubAllowedItemTypeCollection2Zapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubAllowedItemTypeCollection.cls8�
$connectapi.contenthubfielddefinitionContentHubFieldDefinition
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubFieldDefinition.cls#ConnectApi.ContentHubFieldDefinition2Papexlib://resources/StandardApexLibrary/ConnectApi/ContentHubFieldDefinition.cls8�
$connectapi.contenthubfieldvalueinputContentHubFieldValueInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubFieldValueInput.cls#ConnectApi.ContentHubFieldValueInput2Papexlib://resources/StandardApexLibrary/ConnectApi/ContentHubFieldValueInput.cls8�
#connectapi.contenthubfolderitemtypeContentHubFolderItemType
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubFolderItemType.cls#ConnectApi.ContentHubFolderItemType2Oapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubFolderItemType.cls8�
"connectapi.contenthubgrouptypeenumContentHubGroupTypeEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubGroupTypeEnum.cls#ConnectApi.ContentHubGroupTypeEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/ContentHubGroupTypeEnum.cls8�
connectapi.contenthubiteminputContentHubItemInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemInput.cls#ConnectApi.ContentHubItemInput2Japexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemInput.cls8�
#connectapi.contenthubitemtypedetailContentHubItemTypeDetail
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemTypeDetail.cls#ConnectApi.ContentHubItemTypeDetail2Oapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemTypeDetail.cls8�
!connectapi.contenthubitemtypeenumContentHubItemTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemTypeEnum.cls#ConnectApi.ContentHubItemTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemTypeEnum.cls8�
$connectapi.contenthubitemtypesummaryContentHubItemTypeSummary
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemTypeSummary.cls#ConnectApi.ContentHubItemTypeSummary2Papexlib://resources/StandardApexLibrary/ConnectApi/ContentHubItemTypeSummary.cls8�
#connectapi.contenthubpermissiontypeContentHubPermissionType
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubPermissionType.cls#ConnectApi.ContentHubPermissionType2Oapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubPermissionType.cls8�
!connectapi.contenthubprovidertypeContentHubProviderType
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubProviderType.cls#ConnectApi.ContentHubProviderType2Mapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubProviderType.cls8�
connectapi.contenthubrepositoryContentHubRepository
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepository.cls#ConnectApi.ContentHubRepository2Kapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepository.cls8�
-connectapi.contenthubrepositoryauthentication"ContentHubRepositoryAuthentication
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepositoryAuthentication.cls#ConnectApi.ContentHubRepositoryAuthentication2Yapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepositoryAuthentication.cls8�
)connectapi.contenthubrepositorycollectionContentHubRepositoryCollection
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepositoryCollection.cls#ConnectApi.ContentHubRepositoryCollection2Uapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepositoryCollection.cls8�
'connectapi.contenthubrepositoryfeaturesContentHubRepositoryFeatures
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepositoryFeatures.cls#ConnectApi.ContentHubRepositoryFeatures2Sapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubRepositoryFeatures.cls8�
&connectapi.contenthubstreamsupportenumContentHubStreamSupportEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubStreamSupportEnum.cls#ConnectApi.ContentHubStreamSupportEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubStreamSupportEnum.cls8�
%connectapi.contenthubvariabletypeenumContentHubVariableTypeEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubVariableTypeEnum.cls#ConnectApi.ContentHubVariableTypeEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/ContentHubVariableTypeEnum.cls8�
"connectapi.contentimagefiledetailsContentImageFileDetails
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ContentImageFileDetails.cls#ConnectApi.ContentImageFileDetails2Napexlib://resources/StandardApexLibrary/ConnectApi/ContentImageFileDetails.cls8�
connectapi.contenthub
ContentHub
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/Contenthub.cls#ConnectApi.ContentHub2Aapexlib://resources/StandardApexLibrary/ConnectApi/Contenthub.cls8�
&connectapi.contractinputrepresentationContractInputRepresentation
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ContractInputRepresentation.cls#ConnectApi.ContractInputRepresentation2Rapexlib://resources/StandardApexLibrary/ConnectApi/ContractInputRepresentation.cls8�
'connectapi.contractoutputrepresentationContractOutputRepresentation
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ContractOutputRepresentation.cls#ConnectApi.ContractOutputRepresentation2Sapexlib://resources/StandardApexLibrary/ConnectApi/ContractOutputRepresentation.cls8�
,connectapi.conversationapplicationdefinition!ConversationApplicationDefinition
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConversationApplicationDefinition.cls#ConnectApi.ConversationApplicationDefinition2Xapexlib://resources/StandardApexLibrary/ConnectApi/ConversationApplicationDefinition.cls8�
Aconnectapi.conversationapplicationdefinitiondetailrespresentation6ConversationApplicationDefinitionDetailRespresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConversationApplicationDefinitionDetailRespresentation.cls#ConnectApi.ConversationApplicationDefinitionDetailRespresentation2mapexlib://resources/StandardApexLibrary/ConnectApi/ConversationApplicationDefinitionDetailRespresentation.cls8�
5connectapi.conversationapplicationintegrationtypeenum*ConversationApplicationIntegrationTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ConversationApplicationIntegrationTypeEnum.cls#ConnectApi.ConversationApplicationIntegrationTypeEnum2aapexlib://resources/StandardApexLibrary/ConnectApi/ConversationApplicationIntegrationTypeEnum.cls8�
)connectapi.couponcoderedemptioncollectionCouponCodeRedemptionCollection
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/CouponCodeRedemptionCollection.cls#ConnectApi.CouponCodeRedemptionCollection2Uapexlib://resources/StandardApexLibrary/ConnectApi/CouponCodeRedemptionCollection.cls8�
$connectapi.couponcoderedemptioninputCouponCodeRedemptionInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/CouponCodeRedemptionInput.cls#ConnectApi.CouponCodeRedemptionInput2Papexlib://resources/StandardApexLibrary/ConnectApi/CouponCodeRedemptionInput.cls8�
%connectapi.couponcoderedemptionresultCouponCodeRedemptionResult
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/CouponCodeRedemptionResult.cls#ConnectApi.CouponCodeRedemptionResult2Qapexlib://resources/StandardApexLibrary/ConnectApi/CouponCodeRedemptionResult.cls8�
%connectapi.createcredentialactionenumCreateCredentialActionEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/CreateCredentialActionEnum.cls#ConnectApi.CreateCredentialActionEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/CreateCredentialActionEnum.cls8�
.connectapi.createcreditmemoinputrepresentation#CreateCreditMemoInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateCreditMemoInputRepresentation.cls#ConnectApi.CreateCreditMemoInputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/CreateCreditMemoInputRepresentation.cls8�
/connectapi.createcreditmemooutputrepresentation$CreateCreditMemoOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateCreditMemoOutputRepresentation.cls#ConnectApi.CreateCreditMemoOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/CreateCreditMemoOutputRepresentation.cls8�
;connectapi.createinvoicefromchangeordersinputrepresentation0CreateInvoiceFromChangeOrdersInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateInvoiceFromChangeOrdersInputRepresentation.cls#ConnectApi.CreateInvoiceFromChangeOrdersInputRepresentation2gapexlib://resources/StandardApexLibrary/ConnectApi/CreateInvoiceFromChangeOrdersInputRepresentation.cls8�
Dconnectapi.createmultipleinvoicesfromchangeordersinputrepresentation9CreateMultipleInvoicesFromChangeOrdersInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateMultipleInvoicesFromChangeOrdersInputRepresentation.cls#ConnectApi.CreateMultipleInvoicesFromChangeOrdersInputRepresentation2papexlib://resources/StandardApexLibrary/ConnectApi/CreateMultipleInvoicesFromChangeOrdersInputRepresentation.cls8�
Econnectapi.createmultipleinvoicesfromchangeordersoutputrepresentation:CreateMultipleInvoicesFromChangeOrdersOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateMultipleInvoicesFromChangeOrdersOutputRepresentation.cls#ConnectApi.CreateMultipleInvoicesFromChangeOrdersOutputRepresentation2qapexlib://resources/StandardApexLibrary/ConnectApi/CreateMultipleInvoicesFromChangeOrdersOutputRepresentation.cls8�
7connectapi.createorderpaymentsummaryinputrepresentation,CreateOrderPaymentSummaryInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateOrderPaymentSummaryInputRepresentation.cls#ConnectApi.CreateOrderPaymentSummaryInputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/CreateOrderPaymentSummaryInputRepresentation.cls8�
8connectapi.createorderpaymentsummaryoutputrepresentation-CreateOrderPaymentSummaryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateOrderPaymentSummaryOutputRepresentation.cls#ConnectApi.CreateOrderPaymentSummaryOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/CreateOrderPaymentSummaryOutputRepresentation.cls8�
(connectapi.createserviceappointmentinputCreateServiceAppointmentInput
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/CreateServiceAppointmentInput.cls#ConnectApi.CreateServiceAppointmentInput2Tapexlib://resources/StandardApexLibrary/ConnectApi/CreateServiceAppointmentInput.cls8�
&connectapi.createsocialnamedcredentialCreateSocialNamedCredential
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CreateSocialNamedCredential.cls#ConnectApi.CreateSocialNamedCredential2Rapexlib://resources/StandardApexLibrary/ConnectApi/CreateSocialNamedCredential.cls8�
*connectapi.createwebstoremetaconfigurationCreateWebStoreMetaConfiguration
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CreateWebStoreMetaConfiguration.cls#ConnectApi.CreateWebStoreMetaConfiguration2Vapexlib://resources/StandardApexLibrary/ConnectApi/CreateWebStoreMetaConfiguration.cls8�
connectapi.credential
Credential
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/Credential.cls#ConnectApi.Credential2Aapexlib://resources/StandardApexLibrary/ConnectApi/Credential.cls8�
/connectapi.credentialauthenticationprotocolenum$CredentialAuthenticationProtocolEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CredentialAuthenticationProtocolEnum.cls#ConnectApi.CredentialAuthenticationProtocolEnum2[apexlib://resources/StandardApexLibrary/ConnectApi/CredentialAuthenticationProtocolEnum.cls8�
6connectapi.credentialauthenticationprotocolvariantenum+CredentialAuthenticationProtocolVariantEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CredentialAuthenticationProtocolVariantEnum.cls#ConnectApi.CredentialAuthenticationProtocolVariantEnum2bapexlib://resources/StandardApexLibrary/ConnectApi/CredentialAuthenticationProtocolVariantEnum.cls8�
-connectapi.credentialauthenticationstatusenum"CredentialAuthenticationStatusEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CredentialAuthenticationStatusEnum.cls#ConnectApi.CredentialAuthenticationStatusEnum2Yapexlib://resources/StandardApexLibrary/ConnectApi/CredentialAuthenticationStatusEnum.cls8�
!connectapi.credentialcustomheaderCredentialCustomHeader
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/CredentialCustomHeader.cls#ConnectApi.CredentialCustomHeader2Mapexlib://resources/StandardApexLibrary/ConnectApi/CredentialCustomHeader.cls8�
&connectapi.credentialcustomheaderinputCredentialCustomHeaderInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CredentialCustomHeaderInput.cls#ConnectApi.CredentialCustomHeaderInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/CredentialCustomHeaderInput.cls8�
connectapi.credentialinputCredentialInput
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CredentialInput.cls#ConnectApi.CredentialInput2Fapexlib://resources/StandardApexLibrary/ConnectApi/CredentialInput.cls8�
&connectapi.credentialprincipaltypeenumCredentialPrincipalTypeEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CredentialPrincipalTypeEnum.cls#ConnectApi.CredentialPrincipalTypeEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/CredentialPrincipalTypeEnum.cls8�
connectapi.credentialvalueCredentialValue
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/CredentialValue.cls#ConnectApi.CredentialValue2Fapexlib://resources/StandardApexLibrary/ConnectApi/CredentialValue.cls8�
connectapi.credentialvalueinputCredentialValueInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/CredentialValueInput.cls#ConnectApi.CredentialValueInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/CredentialValueInput.cls8�
(connectapi.creditmemoinputrepresentationCreditMemoInputRepresentation
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/CreditMemoInputRepresentation.cls#ConnectApi.CreditMemoInputRepresentation2Tapexlib://resources/StandardApexLibrary/ConnectApi/CreditMemoInputRepresentation.cls8�
connectapi.curatedentityinputCuratedEntityInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/CuratedEntityInput.cls#ConnectApi.CuratedEntityInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/CuratedEntityInput.cls8�
&connectapi.currencyinfodisplaytypeenumCurrencyInfoDisplayTypeEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/CurrencyInfoDisplayTypeEnum.cls#ConnectApi.CurrencyInfoDisplayTypeEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/CurrencyInfoDisplayTypeEnum.cls8�
connectapi.currencyrecordfieldCurrencyRecordField
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/CurrencyRecordField.cls#ConnectApi.CurrencyRecordField2Japexlib://resources/StandardApexLibrary/ConnectApi/CurrencyRecordField.cls8�
%connectapi.customlistaudiencecriteriaCustomListAudienceCriteria
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/CustomListAudienceCriteria.cls#ConnectApi.CustomListAudienceCriteria2Qapexlib://resources/StandardApexLibrary/ConnectApi/CustomListAudienceCriteria.cls8�
*connectapi.customlistaudiencecriteriainputCustomListAudienceCriteriaInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/CustomListAudienceCriteriaInput.cls#ConnectApi.CustomListAudienceCriteriaInput2Vapexlib://resources/StandardApexLibrary/ConnectApi/CustomListAudienceCriteriaInput.cls8�
connectapi.dmofilterinputDMOFilterInput
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/DMOFilterInput.cls#ConnectApi.DMOFilterInput2Eapexlib://resources/StandardApexLibrary/ConnectApi/DMOFilterInput.cls8�
&connectapi.daoobjectfieldtypequeryenumDaoObjectFieldTypeQueryEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/DaoObjectFieldTypeQueryEnum.cls#ConnectApi.DaoObjectFieldTypeQueryEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/DaoObjectFieldTypeQueryEnum.cls8�
'connectapi.dashboardcomponentattachmentDashboardComponentAttachment
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/DashboardComponentAttachment.cls#ConnectApi.DashboardComponentAttachment2Sapexlib://resources/StandardApexLibrary/ConnectApi/DashboardComponentAttachment.cls8�
%connectapi.dashboardcomponentsnapshotDashboardComponentSnapshot
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/DashboardComponentSnapshot.cls#ConnectApi.DashboardComponentSnapshot2Qapexlib://resources/StandardApexLibrary/ConnectApi/DashboardComponentSnapshot.cls8�
/connectapi.dashboardcomponentsnapshotcapability$DashboardComponentSnapshotCapability
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DashboardComponentSnapshotCapability.cls#ConnectApi.DashboardComponentSnapshotCapability2[apexlib://resources/StandardApexLibrary/ConnectApi/DashboardComponentSnapshotCapability.cls8�
connectapi.datacategorymetadataDataCategoryMetadata
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/DataCategoryMetadata.cls#ConnectApi.DataCategoryMetadata2Kapexlib://resources/StandardApexLibrary/ConnectApi/DataCategoryMetadata.cls8�
#connectapi.datacategoryoperatorenumDataCategoryOperatorEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/DataCategoryOperatorEnum.cls#ConnectApi.DataCategoryOperatorEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/DataCategoryOperatorEnum.cls8�
$connectapi.datacategoryvaluemetadataDataCategoryValueMetadata
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/DataCategoryValueMetadata.cls#ConnectApi.DataCategoryValueMetadata2Papexlib://resources/StandardApexLibrary/ConnectApi/DataCategoryValueMetadata.cls8�
connectapi.dataconnectorDataConnector
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/DataConnector.cls#ConnectApi.DataConnector2Dapexlib://resources/StandardApexLibrary/ConnectApi/DataConnector.cls8�
connectapi.dataconnectorinputDataConnectorInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/DataConnectorInput.cls#ConnectApi.DataConnectorInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/DataConnectorInput.cls8�
 connectapi.dataconnectortypeenumDataConnectorTypeEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/DataConnectorTypeEnum.cls#ConnectApi.DataConnectorTypeEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/DataConnectorTypeEnum.cls8�
(connectapi.dataexportattributesourceenumDataExportAttributeSourceEnum
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/DataExportAttributeSourceEnum.cls#ConnectApi.DataExportAttributeSourceEnum2Tapexlib://resources/StandardApexLibrary/ConnectApi/DataExportAttributeSourceEnum.cls8�
&connectapi.dataexportattributetypeenumDataExportAttributeTypeEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/DataExportAttributeTypeEnum.cls#ConnectApi.DataExportAttributeTypeEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/DataExportAttributeTypeEnum.cls8�
$connectapi.dataexportrefreshmodeenumDataExportRefreshModeEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/DataExportRefreshModeEnum.cls#ConnectApi.DataExportRefreshModeEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/DataExportRefreshModeEnum.cls8�
"connectapi.dataexportrunstatusenumDataExportRunStatusEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/DataExportRunStatusEnum.cls#ConnectApi.DataExportRunStatusEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/DataExportRunStatusEnum.cls8�
connectapi.datagraphfieldDataGraphField
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/DataGraphField.cls#ConnectApi.DataGraphField2Eapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphField.cls8�
connectapi.datagraphidsdmoDataGraphIdsDmo
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphIdsDmo.cls#ConnectApi.DataGraphIdsDmo2Fapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphIdsDmo.cls8�
connectapi.datagraphidsdmofieldDataGraphIdsDmoField
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphIdsDmoField.cls#ConnectApi.DataGraphIdsDmoField2Kapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphIdsDmoField.cls8�
connectapi.datagraphobjectdataDataGraphObjectData
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphObjectData.cls#ConnectApi.DataGraphObjectData2Japexlib://resources/StandardApexLibrary/ConnectApi/DataGraphObjectData.cls8�
"connectapi.datagraphobjecttypeenumDataGraphObjectTypeEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphObjectTypeEnum.cls#ConnectApi.DataGraphObjectTypeEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/DataGraphObjectTypeEnum.cls8�
 connectapi.datagraphrelationshipDataGraphRelationship
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphRelationship.cls#ConnectApi.DataGraphRelationship2Lapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphRelationship.cls8�
connectapi.datagraphstatusenumDataGraphStatusEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphStatusEnum.cls#ConnectApi.DataGraphStatusEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/DataGraphStatusEnum.cls8�
connectapi.datagraphvaluesdmoDataGraphValuesDmo
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphValuesDmo.cls#ConnectApi.DataGraphValuesDmo2Iapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphValuesDmo.cls8�
"connectapi.datagraphvaluesdmofieldDataGraphValuesDmoField
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/DataGraphValuesDmoField.cls#ConnectApi.DataGraphValuesDmoField2Napexlib://resources/StandardApexLibrary/ConnectApi/DataGraphValuesDmoField.cls8�
$connectapi.datasourcenameconfiginputDataSourceNameConfigInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/DataSourceNameConfigInput.cls#ConnectApi.DataSourceNameConfigInput2Papexlib://resources/StandardApexLibrary/ConnectApi/DataSourceNameConfigInput.cls8�
,connectapi.dataspacecollectionrepresentation!DataSpaceCollectionRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DataSpaceCollectionRepresentation.cls#ConnectApi.DataSpaceCollectionRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/DataSpaceCollectionRepresentation.cls8�
&connectapi.dataspaceinforepresentationDataSpaceInfoRepresentation
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/DataSpaceInfoRepresentation.cls#ConnectApi.DataSpaceInfoRepresentation2Rapexlib://resources/StandardApexLibrary/ConnectApi/DataSpaceInfoRepresentation.cls8�
connectapi.dataspacestatusenumDataSpaceStatusEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/DataSpaceStatusEnum.cls#ConnectApi.DataSpaceStatusEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/DataSpaceStatusEnum.cls8�
)connectapi.datastreamactionresponseoutputDataStreamActionResponseOutput
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/DataStreamActionResponseOutput.cls#ConnectApi.DataStreamActionResponseOutput2Uapexlib://resources/StandardApexLibrary/ConnectApi/DataStreamActionResponseOutput.cls8�
connectapi.datacloud	Datacloud
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/Datacloud.cls#ConnectApi.Datacloud2@apexlib://resources/StandardApexLibrary/ConnectApi/Datacloud.cls8�
connectapi.datacloudcompaniesDatacloudCompanies
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudCompanies.cls#ConnectApi.DatacloudCompanies2Iapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudCompanies.cls8�
connectapi.datacloudcompanyDatacloudCompany
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/DatacloudCompany.cls#ConnectApi.DatacloudCompany2Gapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudCompany.cls8�
connectapi.datacloudcontactDatacloudContact
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/DatacloudContact.cls#ConnectApi.DatacloudContact2Gapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudContact.cls8�
connectapi.datacloudcontactsDatacloudContacts
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudContacts.cls#ConnectApi.DatacloudContacts2Hapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudContacts.cls8�
(connectapi.datacloudimportstatustypeenumDatacloudImportStatusTypeEnum
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/DatacloudImportStatusTypeEnum.cls#ConnectApi.DatacloudImportStatusTypeEnum2Tapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudImportStatusTypeEnum.cls8�
connectapi.datacloudorderDatacloudOrder
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/DatacloudOrder.cls#ConnectApi.DatacloudOrder2Eapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudOrder.cls8�
connectapi.datacloudorderinputDatacloudOrderInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudOrderInput.cls#ConnectApi.DatacloudOrderInput2Japexlib://resources/StandardApexLibrary/ConnectApi/DatacloudOrderInput.cls8�
!connectapi.datacloudpurchaseusageDatacloudPurchaseUsage
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudPurchaseUsage.cls#ConnectApi.DatacloudPurchaseUsage2Mapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudPurchaseUsage.cls8�
connectapi.datacloudusertypeDatacloudUserType
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudUserType.cls#ConnectApi.DatacloudUserType2Hapexlib://resources/StandardApexLibrary/ConnectApi/DatacloudUserType.cls8�
-connectapi.dateestimationoutputrepresentation"DateEstimationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DateEstimationOutputRepresentation.cls#ConnectApi.DateEstimationOutputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/DateEstimationOutputRepresentation.cls8�
connectapi.daterecordfieldDateRecordField
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/DateRecordField.cls#ConnectApi.DateRecordField2Fapexlib://resources/StandardApexLibrary/ConnectApi/DateRecordField.cls8�
connectapi.deleteintentDeleteIntent
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/DeleteIntent.cls#ConnectApi.DeleteIntent2Capexlib://resources/StandardApexLibrary/ConnectApi/DeleteIntent.cls8�
connectapi.deleteintentsDeleteIntents
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/DeleteIntents.cls#ConnectApi.DeleteIntents2Dapexlib://resources/StandardApexLibrary/ConnectApi/DeleteIntents.cls8�
!connectapi.deletesocialpostintentDeleteSocialPostIntent
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/DeleteSocialPostIntent.cls#ConnectApi.DeleteSocialPostIntent2Mapexlib://resources/StandardApexLibrary/ConnectApi/DeleteSocialPostIntent.cls8�
-connectapi.deliveryaddressinputrepresentation"DeliveryAddressInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DeliveryAddressInputRepresentation.cls#ConnectApi.DeliveryAddressInputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/DeliveryAddressInputRepresentation.cls8�
/connectapi.deliveryestimateoutputrepresentation$DeliveryEstimateOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DeliveryEstimateOutputRepresentation.cls#ConnectApi.DeliveryEstimateOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/DeliveryEstimateOutputRepresentation.cls8�
6connectapi.deliveryestimationerroroutputrepresentation+DeliveryEstimationErrorOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DeliveryEstimationErrorOutputRepresentation.cls#ConnectApi.DeliveryEstimationErrorOutputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/DeliveryEstimationErrorOutputRepresentation.cls8�
7connectapi.deliveryestimationproductinputrepresentation,DeliveryEstimationProductInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DeliveryEstimationProductInputRepresentation.cls#ConnectApi.DeliveryEstimationProductInputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/DeliveryEstimationProductInputRepresentation.cls8�
connectapi.digestfrequencyenumDigestFrequencyEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/DigestFrequencyEnum.cls#ConnectApi.DigestFrequencyEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/DigestFrequencyEnum.cls8�
connectapi.digestjob	DigestJob
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/DigestJob.cls#ConnectApi.DigestJob2@apexlib://resources/StandardApexLibrary/ConnectApi/DigestJob.cls8�
"connectapi.directmessagecapabilityDirectMessageCapability
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageCapability.cls#ConnectApi.DirectMessageCapability2Napexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageCapability.cls8�
'connectapi.directmessagecapabilityinputDirectMessageCapabilityInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageCapabilityInput.cls#ConnectApi.DirectMessageCapabilityInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageCapabilityInput.cls8�
&connectapi.directmessagememberactivityDirectMessageMemberActivity
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageMemberActivity.cls#ConnectApi.DirectMessageMemberActivity2Rapexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageMemberActivity.cls8�
*connectapi.directmessagememberactivitypageDirectMessageMemberActivityPage
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageMemberActivityPage.cls#ConnectApi.DirectMessageMemberActivityPage2Vapexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageMemberActivityPage.cls8�
"connectapi.directmessagememberpageDirectMessageMemberPage
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageMemberPage.cls#ConnectApi.DirectMessageMemberPage2Napexlib://resources/StandardApexLibrary/ConnectApi/DirectMessageMemberPage.cls8�
!connectapi.directoryentrytypeenumDirectoryEntryTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/DirectoryEntryTypeEnum.cls#ConnectApi.DirectoryEntryTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/DirectoryEntryTypeEnum.cls8�
!connectapi.discounttargettypeenumDiscountTargetTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/DiscountTargetTypeEnum.cls#ConnectApi.DiscountTargetTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/DiscountTargetTypeEnum.cls8�
2connectapi.distancecalculationoutputrepresentation'DistanceCalculationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DistanceCalculationOutputRepresentation.cls#ConnectApi.DistanceCalculationOutputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/DistanceCalculationOutputRepresentation.cls8�
connectapi.distinctfacetvalueDistinctFacetValue
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/DistinctFacetValue.cls#ConnectApi.DistinctFacetValue2Iapexlib://resources/StandardApexLibrary/ConnectApi/DistinctFacetValue.cls8�
:connectapi.distinctfacetvaluedisplaymetadatarepresentation/DistinctFacetValueDisplayMetadataRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DistinctFacetValueDisplayMetadataRepresentation.cls#ConnectApi.DistinctFacetValueDisplayMetadataRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/DistinctFacetValueDisplayMetadataRepresentation.cls8�
'connectapi.distinctvaluerefinementinputDistinctValueRefinementInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/DistinctValueRefinementInput.cls#ConnectApi.DistinctValueRefinementInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/DistinctValueRefinementInput.cls8�
#connectapi.distinctvaluesearchfacetDistinctValueSearchFacet
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/DistinctValueSearchFacet.cls#ConnectApi.DistinctValueSearchFacet2Oapexlib://resources/StandardApexLibrary/ConnectApi/DistinctValueSearchFacet.cls8�
8connectapi.distributepickedquantitiesinputrepresentation-DistributePickedQuantitiesInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DistributePickedQuantitiesInputRepresentation.cls#ConnectApi.DistributePickedQuantitiesInputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/DistributePickedQuantitiesInputRepresentation.cls8�
9connectapi.distributepickedquantitiesoutputrepresentation.DistributePickedQuantitiesOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DistributePickedQuantitiesOutputRepresentation.cls#ConnectApi.DistributePickedQuantitiesOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/DistributePickedQuantitiesOutputRepresentation.cls8�
0connectapi.distributetoordersinputrepresentation%DistributeToOrdersInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/DistributeToOrdersInputRepresentation.cls#ConnectApi.DistributeToOrdersInputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/DistributeToOrdersInputRepresentation.cls8�
connectapi.dmofilter	DmoFilter
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/DmoFilter.cls#ConnectApi.DmoFilter2@apexlib://resources/StandardApexLibrary/ConnectApi/DmoFilter.cls8�
connectapi.dmofilterconfigDmoFilterConfig
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/DmoFilterConfig.cls#ConnectApi.DmoFilterConfig2Fapexlib://resources/StandardApexLibrary/ConnectApi/DmoFilterConfig.cls8�
connectapi.dmofilterlimitDmoFilterLimit
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/DmoFilterLimit.cls#ConnectApi.DmoFilterLimit2Eapexlib://resources/StandardApexLibrary/ConnectApi/DmoFilterLimit.cls8�
connectapi.dmofilterlimitinputDmoFilterLimitInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/DmoFilterLimitInput.cls#ConnectApi.DmoFilterLimitInput2Japexlib://resources/StandardApexLibrary/ConnectApi/DmoFilterLimitInput.cls8�
connectapi.doublelist
DoubleList
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/DoubleList.cls#ConnectApi.DoubleList2Aapexlib://resources/StandardApexLibrary/ConnectApi/DoubleList.cls8�
connectapi.downvotesummaryDownVoteSummary
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/DownVoteSummary.cls#ConnectApi.DownVoteSummary2Fapexlib://resources/StandardApexLibrary/ConnectApi/DownVoteSummary.cls8�
connectapi.editcapabilityEditCapability
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/EditCapability.cls#ConnectApi.EditCapability2Eapexlib://resources/StandardApexLibrary/ConnectApi/EditCapability.cls8�
!connectapi.egressfilenametypeenumEgressFileNameTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/EgressFileNameTypeEnum.cls#ConnectApi.EgressFileNameTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/EgressFileNameTypeEnum.cls8�
 connectapi.egresspropertiesinputEgressPropertiesInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/EgressPropertiesInput.cls#ConnectApi.EgressPropertiesInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/EgressPropertiesInput.cls8�
)connectapi.egresspropertiesrepresentationEgressPropertiesRepresentation
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/EgressPropertiesRepresentation.cls#ConnectApi.EgressPropertiesRepresentation2Uapexlib://resources/StandardApexLibrary/ConnectApi/EgressPropertiesRepresentation.cls8�
*connectapi.einsteinllmgenerationitemoutputEinsteinLLMGenerationItemOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLLMGenerationItemOutput.cls#ConnectApi.EinsteinLLMGenerationItemOutput2Vapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLLMGenerationItemOutput.cls8�
connectapi.einsteinllmEinsteinLLM
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlm.cls#ConnectApi.EinsteinLLM2Bapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlm.cls8�
+connectapi.einsteinllmadditionalconfiginput EinsteinLlmAdditionalConfigInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmAdditionalConfigInput.cls#ConnectApi.EinsteinLlmAdditionalConfigInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmAdditionalConfigInput.cls8�
*connectapi.einsteinllmgenaisourcereferenceEinsteinLlmGenAiSourceReference
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenAiSourceReference.cls#ConnectApi.EinsteinLlmGenAiSourceReference2Vapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenAiSourceReference.cls8�
.connectapi.einsteinllmgenerationcitationoutput#EinsteinLlmGenerationCitationOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationCitationOutput.cls#ConnectApi.EinsteinLlmGenerationCitationOutput2Zapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationCitationOutput.cls8�
4connectapi.einsteinllmgenerationcontentqualityoutput)EinsteinLlmGenerationContentQualityOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationContentQualityOutput.cls#ConnectApi.EinsteinLlmGenerationContentQualityOutput2`apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationContentQualityOutput.cls8�
3connectapi.einsteinllmgenerationgenaicitedreference(EinsteinLlmGenerationGenAiCitedReference
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationGenAiCitedReference.cls#ConnectApi.EinsteinLlmGenerationGenAiCitedReference2_apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationGenAiCitedReference.cls8�
6connectapi.einsteinllmgenerationgenaisourcecontentinfo+EinsteinLlmGenerationGenAiSourceContentInfo
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationGenAiSourceContentInfo.cls#ConnectApi.EinsteinLlmGenerationGenAiSourceContentInfo2bapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationGenAiSourceContentInfo.cls8�
8connectapi.einsteinllmgenerationgenaisourcereferenceinfo-EinsteinLlmGenerationGenAiSourceReferenceInfo
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationGenAiSourceReferenceInfo.cls#ConnectApi.EinsteinLlmGenerationGenAiSourceReferenceInfo2dapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationGenAiSourceReferenceInfo.cls8�
1connectapi.einsteinllmgenerationsafetyscoreoutput&EinsteinLlmGenerationSafetyScoreOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationSafetyScoreOutput.cls#ConnectApi.EinsteinLlmGenerationSafetyScoreOutput2]apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinLlmGenerationSafetyScoreOutput.cls8�
=connectapi.einsteinpromptrecordcollectionoutputrepresentation2EinsteinPromptRecordCollectionOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptRecordCollectionOutputRepresentation.cls#ConnectApi.EinsteinPromptRecordCollectionOutputRepresentation2iapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptRecordCollectionOutputRepresentation.cls8�
2connectapi.einsteinpromptrecordfieldrepresentation'EinsteinPromptRecordFieldRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptRecordFieldRepresentation.cls#ConnectApi.EinsteinPromptRecordFieldRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptRecordFieldRepresentation.cls8�
-connectapi.einsteinpromptrecordrepresentation"EinsteinPromptRecordRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptRecordRepresentation.cls#ConnectApi.EinsteinPromptRecordRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptRecordRepresentation.cls8�
+connectapi.einsteinprompttemplateattachment EinsteinPromptTemplateAttachment
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateAttachment.cls#ConnectApi.EinsteinPromptTemplateAttachment2Wapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateAttachment.cls8�
1connectapi.einsteinprompttemplategenerationserror&EinsteinPromptTemplateGenerationsError
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateGenerationsError.cls#ConnectApi.EinsteinPromptTemplateGenerationsError2]apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateGenerationsError.cls8�
1connectapi.einsteinprompttemplategenerationsinput&EinsteinPromptTemplateGenerationsInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateGenerationsInput.cls#ConnectApi.EinsteinPromptTemplateGenerationsInput2]apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateGenerationsInput.cls8�
:connectapi.einsteinprompttemplategenerationsrepresentation/EinsteinPromptTemplateGenerationsRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateGenerationsRepresentation.cls#ConnectApi.EinsteinPromptTemplateGenerationsRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateGenerationsRepresentation.cls8�
:connectapi.einsteinprompttemplatemaskcontentrepresentation/EinsteinPromptTemplateMaskContentRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateMaskContentRepresentation.cls#ConnectApi.EinsteinPromptTemplateMaskContentRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateMaskContentRepresentation.cls8�
7connectapi.einsteinprompttemplatemaskdatarepresentation,EinsteinPromptTemplateMaskDataRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateMaskDataRepresentation.cls#ConnectApi.EinsteinPromptTemplateMaskDataRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateMaskDataRepresentation.cls8�
;connectapi.einsteinprompttemplatemasksettingsrepresentation0EinsteinPromptTemplateMaskSettingsRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateMaskSettingsRepresentation.cls#ConnectApi.EinsteinPromptTemplateMaskSettingsRepresentation2gapexlib://resources/StandardApexLibrary/ConnectApi/EinsteinPromptTemplateMaskSettingsRepresentation.cls8�
connectapi.emailaddressEmailAddress
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/EmailAddress.cls#ConnectApi.EmailAddress2Capexlib://resources/StandardApexLibrary/ConnectApi/EmailAddress.cls8�
connectapi.emailattachmentEmailAttachment
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/EmailAttachment.cls#ConnectApi.EmailAttachment2Fapexlib://resources/StandardApexLibrary/ConnectApi/EmailAttachment.cls8�
(connectapi.emailmergefieldcollectioninfoEmailMergeFieldCollectionInfo
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/EmailMergeFieldCollectionInfo.cls#ConnectApi.EmailMergeFieldCollectionInfo2Tapexlib://resources/StandardApexLibrary/ConnectApi/EmailMergeFieldCollectionInfo.cls8�
connectapi.emailmergefieldinfoEmailMergeFieldInfo
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/EmailMergeFieldInfo.cls#ConnectApi.EmailMergeFieldInfo2Japexlib://resources/StandardApexLibrary/ConnectApi/EmailMergeFieldInfo.cls8�
!connectapi.emailmergefieldserviceEmailMergeFieldService
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/EmailMergeFieldService.cls#ConnectApi.EmailMergeFieldService2Mapexlib://resources/StandardApexLibrary/ConnectApi/EmailMergeFieldService.cls8�
connectapi.emailmessageEmailMessage
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/EmailMessage.cls#ConnectApi.EmailMessage2Capexlib://resources/StandardApexLibrary/ConnectApi/EmailMessage.cls8�
!connectapi.emailmessagecapabilityEmailMessageCapability
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageCapability.cls#ConnectApi.EmailMessageCapability2Mapexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageCapability.cls8�
$connectapi.emailmessagedirectionenumEmailMessageDirectionEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageDirectionEnum.cls#ConnectApi.EmailMessageDirectionEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageDirectionEnum.cls8�
connectapi.emailmessagesizeenumEmailMessageSizeEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageSizeEnum.cls#ConnectApi.EmailMessageSizeEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageSizeEnum.cls8�
!connectapi.emailmessagestatusenumEmailMessageStatusEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageStatusEnum.cls#ConnectApi.EmailMessageStatusEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/EmailMessageStatusEnum.cls8�
connectapi.emojiEmoji
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Emoji.cls#ConnectApi.Emoji2<apexlib://resources/StandardApexLibrary/ConnectApi/Emoji.cls8�
connectapi.emojicollectionEmojiCollection
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/EmojiCollection.cls#ConnectApi.EmojiCollection2Fapexlib://resources/StandardApexLibrary/ConnectApi/EmojiCollection.cls8�
connectapi.employeeprofilesEmployeeProfiles
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/EmployeeProfiles.cls#ConnectApi.EmployeeProfiles2Gapexlib://resources/StandardApexLibrary/ConnectApi/EmployeeProfiles.cls8�
!connectapi.enhancedlinkcapabilityEnhancedLinkCapability
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/EnhancedLinkCapability.cls#ConnectApi.EnhancedLinkCapability2Mapexlib://resources/StandardApexLibrary/ConnectApi/EnhancedLinkCapability.cls8�
.connectapi.ensurefundsasyncinputrepresentation#EnsureFundsAsyncInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EnsureFundsAsyncInputRepresentation.cls#ConnectApi.EnsureFundsAsyncInputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/EnsureFundsAsyncInputRepresentation.cls8�
/connectapi.ensurefundsasyncoutputrepresentation$EnsureFundsAsyncOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EnsureFundsAsyncOutputRepresentation.cls#ConnectApi.EnsureFundsAsyncOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/EnsureFundsAsyncOutputRepresentation.cls8�
1connectapi.ensurepaymentcreditinputrepresentation&EnsurePaymentCreditInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EnsurePaymentCreditInputRepresentation.cls#ConnectApi.EnsurePaymentCreditInputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/EnsurePaymentCreditInputRepresentation.cls8�
2connectapi.ensurepaymentcreditoutputrepresentation'EnsurePaymentCreditOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EnsurePaymentCreditOutputRepresentation.cls#ConnectApi.EnsurePaymentCreditOutputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/EnsurePaymentCreditOutputRepresentation.cls8�
0connectapi.ensurerefundsasyncinputrepresentation%EnsureRefundsAsyncInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EnsureRefundsAsyncInputRepresentation.cls#ConnectApi.EnsureRefundsAsyncInputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/EnsureRefundsAsyncInputRepresentation.cls8�
1connectapi.ensurerefundsasyncoutputrepresentation&EnsureRefundsAsyncOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EnsureRefundsAsyncOutputRepresentation.cls#ConnectApi.EnsureRefundsAsyncOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/EnsureRefundsAsyncOutputRepresentation.cls8�
connectapi.entitylabelEntityLabel
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/EntityLabel.cls#ConnectApi.EntityLabel2Bapexlib://resources/StandardApexLibrary/ConnectApi/EntityLabel.cls8�
connectapi.entitylinksegmentEntityLinkSegment
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/EntityLinkSegment.cls#ConnectApi.EntityLinkSegment2Hapexlib://resources/StandardApexLibrary/ConnectApi/EntityLinkSegment.cls8�
!connectapi.entitylinksegmentinputEntityLinkSegmentInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/EntityLinkSegmentInput.cls#ConnectApi.EntityLinkSegmentInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/EntityLinkSegmentInput.cls8�
connectapi.entityrecommendationEntityRecommendation
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/EntityRecommendation.cls#ConnectApi.EntityRecommendation2Kapexlib://resources/StandardApexLibrary/ConnectApi/EntityRecommendation.cls8�
connectapi.errorresponseErrorResponse
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/ErrorResponse.cls#ConnectApi.ErrorResponse2Dapexlib://resources/StandardApexLibrary/ConnectApi/ErrorResponse.cls8�
2connectapi.estimatedeliverydateinputrepresentation'EstimateDeliveryDateInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EstimateDeliveryDateInputRepresentation.cls#ConnectApi.EstimateDeliveryDateInputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/EstimateDeliveryDateInputRepresentation.cls8�
3connectapi.estimatedeliverydateoutputrepresentation(EstimateDeliveryDateOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/EstimateDeliveryDateOutputRepresentation.cls#ConnectApi.EstimateDeliveryDateOutputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/EstimateDeliveryDateOutputRepresentation.cls8�
connectapi.exchanges	Exchanges
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/Exchanges.cls#ConnectApi.Exchanges2@apexlib://resources/StandardApexLibrary/ConnectApi/Exchanges.cls8�
#connectapi.extendedcommercedeliveryExtendedCommerceDelivery
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ExtendedCommerceDelivery.cls#ConnectApi.ExtendedCommerceDelivery2Oapexlib://resources/StandardApexLibrary/ConnectApi/ExtendedCommerceDelivery.cls8�
connectapi.extendedfieldinputExtendedFieldInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ExtendedFieldInput.cls#ConnectApi.ExtendedFieldInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/ExtendedFieldInput.cls8�
connectapi.extension	Extension
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/Extension.cls#ConnectApi.Extension2@apexlib://resources/StandardApexLibrary/ConnectApi/Extension.cls8�
connectapi.extensiondefinitionExtensionDefinition
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionDefinition.cls#ConnectApi.ExtensionDefinition2Japexlib://resources/StandardApexLibrary/ConnectApi/ExtensionDefinition.cls8�
connectapi.extensiondefinitionsExtensionDefinitions
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionDefinitions.cls#ConnectApi.ExtensionDefinitions2Kapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionDefinitions.cls8�
'connectapi.extensioninformationtypeenumExtensionInformationTypeEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ExtensionInformationTypeEnum.cls#ConnectApi.ExtensionInformationTypeEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionInformationTypeEnum.cls8�
connectapi.extensioninputExtensionInput
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ExtensionInput.cls#ConnectApi.ExtensionInput2Eapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionInput.cls8�
connectapi.extensionscapabilityExtensionsCapability
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionsCapability.cls#ConnectApi.ExtensionsCapability2Kapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionsCapability.cls8�
$connectapi.extensionscapabilityinputExtensionsCapabilityInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ExtensionsCapabilityInput.cls#ConnectApi.ExtensionsCapabilityInput2Papexlib://resources/StandardApexLibrary/ConnectApi/ExtensionsCapabilityInput.cls8�
'connectapi.externalauthidentityproviderExternalAuthIdentityProvider
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProvider.cls#ConnectApi.ExternalAuthIdentityProvider2Sapexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProvider.cls8�
1connectapi.externalauthidentityprovidercredential&ExternalAuthIdentityProviderCredential
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredential.cls#ConnectApi.ExternalAuthIdentityProviderCredential2]apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredential.cls8�
6connectapi.externalauthidentityprovidercredentialinput+ExternalAuthIdentityProviderCredentialInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredentialInput.cls#ConnectApi.ExternalAuthIdentityProviderCredentialInput2bapexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredentialInput.cls8�
2connectapi.externalauthidentityprovidercredentials'ExternalAuthIdentityProviderCredentials
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredentials.cls#ConnectApi.ExternalAuthIdentityProviderCredentials2^apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredentials.cls8�
7connectapi.externalauthidentityprovidercredentialsinput,ExternalAuthIdentityProviderCredentialsInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredentialsInput.cls#ConnectApi.ExternalAuthIdentityProviderCredentialsInput2capexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderCredentialsInput.cls8�
,connectapi.externalauthidentityproviderinput!ExternalAuthIdentityProviderInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderInput.cls#ConnectApi.ExternalAuthIdentityProviderInput2Xapexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderInput.cls8�
+connectapi.externalauthidentityproviderlist ExternalAuthIdentityProviderList
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderList.cls#ConnectApi.ExternalAuthIdentityProviderList2Wapexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderList.cls8�
0connectapi.externalauthidentityproviderparameter%ExternalAuthIdentityProviderParameter
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderParameter.cls#ConnectApi.ExternalAuthIdentityProviderParameter2\apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderParameter.cls8�
5connectapi.externalauthidentityproviderparameterinput*ExternalAuthIdentityProviderParameterInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderParameterInput.cls#ConnectApi.ExternalAuthIdentityProviderParameterInput2aapexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderParameterInput.cls8�
8connectapi.externalauthidentityproviderparametertypeenum-ExternalAuthIdentityProviderParameterTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderParameterTypeEnum.cls#ConnectApi.ExternalAuthIdentityProviderParameterTypeEnum2dapexlib://resources/StandardApexLibrary/ConnectApi/ExternalAuthIdentityProviderParameterTypeEnum.cls8�
connectapi.externalcredentialExternalCredential
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredential.cls#ConnectApi.ExternalCredential2Iapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredential.cls8�
"connectapi.externalcredentialinputExternalCredentialInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialInput.cls#ConnectApi.ExternalCredentialInput2Napexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialInput.cls8�
!connectapi.externalcredentiallistExternalCredentialList
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialList.cls#ConnectApi.ExternalCredentialList2Mapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialList.cls8�
&connectapi.externalcredentialparameterExternalCredentialParameter
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialParameter.cls#ConnectApi.ExternalCredentialParameter2Rapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialParameter.cls8�
+connectapi.externalcredentialparameterinput ExternalCredentialParameterInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialParameterInput.cls#ConnectApi.ExternalCredentialParameterInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialParameterInput.cls8�
*connectapi.externalcredentialparametertypeExternalCredentialParameterType
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialParameterType.cls#ConnectApi.ExternalCredentialParameterType2Vapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialParameterType.cls8�
&connectapi.externalcredentialprincipalExternalCredentialPrincipal
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipal.cls#ConnectApi.ExternalCredentialPrincipal2Rapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipal.cls8�
,connectapi.externalcredentialprincipalaccess!ExternalCredentialPrincipalAccess
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipalAccess.cls#ConnectApi.ExternalCredentialPrincipalAccess2Xapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipalAccess.cls8�
0connectapi.externalcredentialprincipalaccesstype%ExternalCredentialPrincipalAccessType
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipalAccessType.cls#ConnectApi.ExternalCredentialPrincipalAccessType2\apexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipalAccessType.cls8�
+connectapi.externalcredentialprincipalinput ExternalCredentialPrincipalInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipalInput.cls#ConnectApi.ExternalCredentialPrincipalInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/ExternalCredentialPrincipalInput.cls8�
 connectapi.externalemailservicesExternalEmailServices
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ExternalEmailServices.cls#ConnectApi.ExternalEmailServices2Lapexlib://resources/StandardApexLibrary/ConnectApi/ExternalEmailServices.cls8�
,connectapi.externalfilepermissioninformation!ExternalFilePermissionInformation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalFilePermissionInformation.cls#ConnectApi.ExternalFilePermissionInformation2Xapexlib://resources/StandardApexLibrary/ConnectApi/ExternalFilePermissionInformation.cls8�
"connectapi.externalitemsharingtypeExternalItemSharingType
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ExternalItemSharingType.cls#ConnectApi.ExternalItemSharingType2Napexlib://resources/StandardApexLibrary/ConnectApi/ExternalItemSharingType.cls8�
!connectapi.externalmanagedaccountExternalManagedAccount
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccount.cls#ConnectApi.ExternalManagedAccount2Mapexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccount.cls8�
.connectapi.externalmanagedaccountaddressoutput#ExternalManagedAccountAddressOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccountAddressOutput.cls#ConnectApi.ExternalManagedAccountAddressOutput2Zapexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccountAddressOutput.cls8�
1connectapi.externalmanagedaccountcollectionoutput&ExternalManagedAccountCollectionOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccountCollectionOutput.cls#ConnectApi.ExternalManagedAccountCollectionOutput2]apexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccountCollectionOutput.cls8�
'connectapi.externalmanagedaccountoutputExternalManagedAccountOutput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccountOutput.cls#ConnectApi.ExternalManagedAccountOutput2Sapexlib://resources/StandardApexLibrary/ConnectApi/ExternalManagedAccountOutput.cls8�
connectapi.facetvalue
FacetValue
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/FacetValue.cls#ConnectApi.FacetValue2Aapexlib://resources/StandardApexLibrary/ConnectApi/FacetValue.cls8�
connectapi.featuresFeatures
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/Features.cls#ConnectApi.Features2?apexlib://resources/StandardApexLibrary/ConnectApi/Features.cls8�
connectapi.feedFeed
ConnectApi *Kapexlib://resources/StandardApexLibrary/ConnectApi/Feed.cls#ConnectApi.Feed2;apexlib://resources/StandardApexLibrary/ConnectApi/Feed.cls8�
connectapi.feedbodyFeedBody
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/FeedBody.cls#ConnectApi.FeedBody2?apexlib://resources/StandardApexLibrary/ConnectApi/FeedBody.cls8�
#connectapi.feedcommentsortorderenumFeedCommentSortOrderEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/FeedCommentSortOrderEnum.cls#ConnectApi.FeedCommentSortOrderEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/FeedCommentSortOrderEnum.cls8�
connectapi.feeddensityenumFeedDensityEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/FeedDensityEnum.cls#ConnectApi.FeedDensityEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/FeedDensityEnum.cls8�
connectapi.feeddirectoryFeedDirectory
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/FeedDirectory.cls#ConnectApi.FeedDirectory2Dapexlib://resources/StandardApexLibrary/ConnectApi/FeedDirectory.cls8�
connectapi.feeddirectoryitemFeedDirectoryItem
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/FeedDirectoryItem.cls#ConnectApi.FeedDirectoryItem2Hapexlib://resources/StandardApexLibrary/ConnectApi/FeedDirectoryItem.cls8�
connectapi.feedelementFeedElement
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/FeedElement.cls#ConnectApi.FeedElement2Bapexlib://resources/StandardApexLibrary/ConnectApi/FeedElement.cls8�
"connectapi.feedelementcapabilitiesFeedElementCapabilities
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilities.cls#ConnectApi.FeedElementCapabilities2Napexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilities.cls8�
'connectapi.feedelementcapabilitiesinputFeedElementCapabilitiesInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilitiesInput.cls#ConnectApi.FeedElementCapabilitiesInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilitiesInput.cls8�
 connectapi.feedelementcapabilityFeedElementCapability
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapability.cls#ConnectApi.FeedElementCapability2Lapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapability.cls8�
%connectapi.feedelementcapabilityinputFeedElementCapabilityInput
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilityInput.cls#ConnectApi.FeedElementCapabilityInput2Qapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilityInput.cls8�
$connectapi.feedelementcapabilitytypeFeedElementCapabilityType
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilityType.cls#ConnectApi.FeedElementCapabilityType2Papexlib://resources/StandardApexLibrary/ConnectApi/FeedElementCapabilityType.cls8�
connectapi.feedelementinputFeedElementInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/FeedElementInput.cls#ConnectApi.FeedElementInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementInput.cls8�
connectapi.feedelementpageFeedElementPage
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementPage.cls#ConnectApi.FeedElementPage2Fapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementPage.cls8�
connectapi.feedelementtypeenumFeedElementTypeEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/FeedElementTypeEnum.cls#ConnectApi.FeedElementTypeEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/FeedElementTypeEnum.cls8�
connectapi.feedenabledentityFeedEnabledEntity
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/FeedEnabledEntity.cls#ConnectApi.FeedEnabledEntity2Hapexlib://resources/StandardApexLibrary/ConnectApi/FeedEnabledEntity.cls8�
connectapi.feedentityiseditableFeedEntityIsEditable
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityIsEditable.cls#ConnectApi.FeedEntityIsEditable2Kapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityIsEditable.cls8�
(connectapi.feedentitynotavailablesummaryFeedEntityNotAvailableSummary
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityNotAvailableSummary.cls#ConnectApi.FeedEntityNotAvailableSummary2Tapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityNotAvailableSummary.cls8�
 connectapi.feedentityreadsummaryFeedEntityReadSummary
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityReadSummary.cls#ConnectApi.FeedEntityReadSummary2Lapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityReadSummary.cls8�
$connectapi.feedentitysharecapabilityFeedEntityShareCapability
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityShareCapability.cls#ConnectApi.FeedEntityShareCapability2Papexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityShareCapability.cls8�
)connectapi.feedentitysharecapabilityinputFeedEntityShareCapabilityInput
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityShareCapabilityInput.cls#ConnectApi.FeedEntityShareCapabilityInput2Uapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityShareCapabilityInput.cls8�
connectapi.feedentitystatusenumFeedEntityStatusEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityStatusEnum.cls#ConnectApi.FeedEntityStatusEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntityStatusEnum.cls8�
connectapi.feedentitysummaryFeedEntitySummary
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntitySummary.cls#ConnectApi.FeedEntitySummary2Hapexlib://resources/StandardApexLibrary/ConnectApi/FeedEntitySummary.cls8�
connectapi.feedfavoriteFeedFavorite
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/FeedFavorite.cls#ConnectApi.FeedFavorite2Capexlib://resources/StandardApexLibrary/ConnectApi/FeedFavorite.cls8�
connectapi.feedfavoritetypeFeedFavoriteType
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/FeedFavoriteType.cls#ConnectApi.FeedFavoriteType2Gapexlib://resources/StandardApexLibrary/ConnectApi/FeedFavoriteType.cls8�
connectapi.feedfavoritesFeedFavorites
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/FeedFavorites.cls#ConnectApi.FeedFavorites2Dapexlib://resources/StandardApexLibrary/ConnectApi/FeedFavorites.cls8�
connectapi.feedfilter
FeedFilter
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/FeedFilter.cls#ConnectApi.FeedFilter2Aapexlib://resources/StandardApexLibrary/ConnectApi/FeedFilter.cls8�
connectapi.feeditemFeedItem
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/FeedItem.cls#ConnectApi.FeedItem2?apexlib://resources/StandardApexLibrary/ConnectApi/FeedItem.cls8�
connectapi.feeditemattachmentFeedItemAttachment
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemAttachment.cls#ConnectApi.FeedItemAttachment2Iapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemAttachment.cls8�
"connectapi.feeditemattachmentinputFeedItemAttachmentInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemAttachmentInput.cls#ConnectApi.FeedItemAttachmentInput2Napexlib://resources/StandardApexLibrary/ConnectApi/FeedItemAttachmentInput.cls8�
connectapi.feediteminputFeedItemInput
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/FeedItemInput.cls#ConnectApi.FeedItemInput2Dapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemInput.cls8�
connectapi.feeditempageFeedItemPage
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/FeedItemPage.cls#ConnectApi.FeedItemPage2Capexlib://resources/StandardApexLibrary/ConnectApi/FeedItemPage.cls8�
connectapi.feeditemsummaryFeedItemSummary
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemSummary.cls#ConnectApi.FeedItemSummary2Fapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemSummary.cls8�
connectapi.feeditemtopicpageFeedItemTopicPage
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemTopicPage.cls#ConnectApi.FeedItemTopicPage2Hapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemTopicPage.cls8�
connectapi.feeditemtypeenumFeedItemTypeEnum
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/FeedItemTypeEnum.cls#ConnectApi.FeedItemTypeEnum2Gapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemTypeEnum.cls8�
connectapi.feeditemtypevisenumFeedItemTypeVisEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/FeedItemTypeVisEnum.cls#ConnectApi.FeedItemTypeVisEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/FeedItemTypeVisEnum.cls8�
connectapi.feedmodifiedinfoFeedModifiedInfo
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/FeedModifiedInfo.cls#ConnectApi.FeedModifiedInfo2Gapexlib://resources/StandardApexLibrary/ConnectApi/FeedModifiedInfo.cls8�
connectapi.feedpollFeedPoll
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/FeedPoll.cls#ConnectApi.FeedPoll2?apexlib://resources/StandardApexLibrary/ConnectApi/FeedPoll.cls8�
connectapi.feedpollchoiceFeedPollChoice
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/FeedPollChoice.cls#ConnectApi.FeedPollChoice2Eapexlib://resources/StandardApexLibrary/ConnectApi/FeedPollChoice.cls8�
connectapi.feedpostsummaryFeedPostSummary
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/FeedPostSummary.cls#ConnectApi.FeedPostSummary2Fapexlib://resources/StandardApexLibrary/ConnectApi/FeedPostSummary.cls8�
connectapi.feedreadsummaryFeedReadSummary
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/FeedReadSummary.cls#ConnectApi.FeedReadSummary2Fapexlib://resources/StandardApexLibrary/ConnectApi/FeedReadSummary.cls8�
connectapi.feedsortorder_enumFeedSortOrder_enum
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/FeedSortOrder_enum.cls#ConnectApi.FeedSortOrder_enum2Iapexlib://resources/StandardApexLibrary/ConnectApi/FeedSortOrder_enum.cls8�
connectapi.feedtypeenumFeedTypeEnum
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/FeedTypeEnum.cls#ConnectApi.FeedTypeEnum2Capexlib://resources/StandardApexLibrary/ConnectApi/FeedTypeEnum.cls8�
!connectapi.fieldchangenamesegmentFieldChangeNameSegment
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeNameSegment.cls#ConnectApi.FieldChangeNameSegment2Mapexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeNameSegment.cls8�
connectapi.fieldchangesegmentFieldChangeSegment
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeSegment.cls#ConnectApi.FieldChangeSegment2Iapexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeSegment.cls8�
"connectapi.fieldchangevaluesegmentFieldChangeValueSegment
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeValueSegment.cls#ConnectApi.FieldChangeValueSegment2Napexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeValueSegment.cls8�
$connectapi.fieldchangevaluetype_enumFieldChangeValueType_enum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeValueType_enum.cls#ConnectApi.FieldChangeValueType_enum2Papexlib://resources/StandardApexLibrary/ConnectApi/FieldChangeValueType_enum.cls8�
connectapi.fieldmetadataFieldMetadata
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/FieldMetadata.cls#ConnectApi.FieldMetadata2Dapexlib://resources/StandardApexLibrary/ConnectApi/FieldMetadata.cls8�
connectapi.fieldserviceFieldService
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/FieldService.cls#ConnectApi.FieldService2Capexlib://resources/StandardApexLibrary/ConnectApi/FieldService.cls8�
connectapi.fieldtypeenumFieldTypeEnum
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/FieldTypeEnum.cls#ConnectApi.FieldTypeEnum2Dapexlib://resources/StandardApexLibrary/ConnectApi/FieldTypeEnum.cls8�
connectapi.fieldvalue
FieldValue
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/FieldValue.cls#ConnectApi.FieldValue2Aapexlib://resources/StandardApexLibrary/ConnectApi/FieldValue.cls8�
connectapi.fileFile
ConnectApi *Kapexlib://resources/StandardApexLibrary/ConnectApi/File.cls#ConnectApi.File2;apexlib://resources/StandardApexLibrary/ConnectApi/File.cls8�
connectapi.fileasset	FileAsset
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/FileAsset.cls#ConnectApi.FileAsset2@apexlib://resources/StandardApexLibrary/ConnectApi/FileAsset.cls8�
connectapi.filedelimiterenumFileDelimiterEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/FileDelimiterEnum.cls#ConnectApi.FileDelimiterEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/FileDelimiterEnum.cls8�
connectapi.fileidinputFileIdInput
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/FileIdInput.cls#ConnectApi.FileIdInput2Bapexlib://resources/StandardApexLibrary/ConnectApi/FileIdInput.cls8�
connectapi.filepreviewFilePreview
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/FilePreview.cls#ConnectApi.FilePreview2Bapexlib://resources/StandardApexLibrary/ConnectApi/FilePreview.cls8�
 connectapi.filepreviewcollectionFilePreviewCollection
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewCollection.cls#ConnectApi.FilePreviewCollection2Lapexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewCollection.cls8�
!connectapi.filepreviewformat_enumFilePreviewFormat_enum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewFormat_enum.cls#ConnectApi.FilePreviewFormat_enum2Mapexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewFormat_enum.cls8�
!connectapi.filepreviewstatus_enumFilePreviewStatus_enum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewStatus_enum.cls#ConnectApi.FilePreviewStatus_enum2Mapexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewStatus_enum.cls8�
connectapi.filepreviewurlFilePreviewUrl
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewUrl.cls#ConnectApi.FilePreviewUrl2Eapexlib://resources/StandardApexLibrary/ConnectApi/FilePreviewUrl.cls8�
!connectapi.filepublishstatus_enumFilePublishStatus_enum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/FilePublishStatus_enum.cls#ConnectApi.FilePublishStatus_enum2Mapexlib://resources/StandardApexLibrary/ConnectApi/FilePublishStatus_enum.cls8�
!connectapi.filesharingoption_enumFileSharingOption_enum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/FileSharingOption_enum.cls#ConnectApi.FileSharingOption_enum2Mapexlib://resources/StandardApexLibrary/ConnectApi/FileSharingOption_enum.cls8�
!connectapi.filesharingprivacyenumFileSharingPrivacyEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/FileSharingPrivacyEnum.cls#ConnectApi.FileSharingPrivacyEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/FileSharingPrivacyEnum.cls8�
connectapi.filesharingtype_enumFileSharingType_enum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/FileSharingType_enum.cls#ConnectApi.FileSharingType_enum2Kapexlib://resources/StandardApexLibrary/ConnectApi/FileSharingType_enum.cls8�
connectapi.filesummaryFileSummary
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/FileSummary.cls#ConnectApi.FileSummary2Bapexlib://resources/StandardApexLibrary/ConnectApi/FileSummary.cls8�
connectapi.filescapabilityFilesCapability
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/FilesCapability.cls#ConnectApi.FilesCapability2Fapexlib://resources/StandardApexLibrary/ConnectApi/FilesCapability.cls8�
connectapi.filescapabilityinputFilesCapabilityInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/FilesCapabilityInput.cls#ConnectApi.FilesCapabilityInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/FilesCapabilityInput.cls8�
 connectapi.filterconjunctionenumFilterConjunctionEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/FilterConjunctionEnum.cls#ConnectApi.FilterConjunctionEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/FilterConjunctionEnum.cls8�
%connectapi.filteroperatordatatypeenumFilterOperatorDataTypeEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/FilterOperatorDataTypeEnum.cls#ConnectApi.FilterOperatorDataTypeEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/FilterOperatorDataTypeEnum.cls8�
connectapi.filteroperatorenumFilterOperatorEnum
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/FilterOperatorEnum.cls#ConnectApi.FilterOperatorEnum2Iapexlib://resources/StandardApexLibrary/ConnectApi/FilterOperatorEnum.cls8�
connectapi.filtersortorderenumFilterSortOrderEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/FilterSortOrderEnum.cls#ConnectApi.FilterSortOrderEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/FilterSortOrderEnum.cls8�
Econnectapi.findrouteswithfewestsplitsgroupusingociinputrepresentation:FindRoutesWithFewestSplitsGroupUsingOCIInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsGroupUsingOCIInputRepresentation.cls#ConnectApi.FindRoutesWithFewestSplitsGroupUsingOCIInputRepresentation2qapexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsGroupUsingOCIInputRepresentation.cls8�
8connectapi.findrouteswithfewestsplitsinputrepresentation-FindRoutesWithFewestSplitsInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsInputRepresentation.cls#ConnectApi.FindRoutesWithFewestSplitsInputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsInputRepresentation.cls8�
9connectapi.findrouteswithfewestsplitsoutputrepresentation.FindRoutesWithFewestSplitsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsOutputRepresentation.cls#ConnectApi.FindRoutesWithFewestSplitsOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsOutputRepresentation.cls8�
@connectapi.findrouteswithfewestsplitsusingociinputrepresentation5FindRoutesWithFewestSplitsUsingOCIInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsUsingOCIInputRepresentation.cls#ConnectApi.FindRoutesWithFewestSplitsUsingOCIInputRepresentation2lapexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsUsingOCIInputRepresentation.cls8�
Dconnectapi.findrouteswithfewestsplitsusingociiteminputrepresentation9FindRoutesWithFewestSplitsUsingOCIItemInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsUsingOCIItemInputRepresentation.cls#ConnectApi.FindRoutesWithFewestSplitsUsingOCIItemInputRepresentation2papexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsUsingOCIItemInputRepresentation.cls8�
Aconnectapi.findrouteswithfewestsplitsusingocioutputrepresentation6FindRoutesWithFewestSplitsUsingOCIOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsUsingOCIOutputRepresentation.cls#ConnectApi.FindRoutesWithFewestSplitsUsingOCIOutputRepresentation2mapexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsUsingOCIOutputRepresentation.cls8�
Fconnectapi.findrouteswithfewestsplitswithinventoryoutputrepresentation;FindRoutesWithFewestSplitsWithInventoryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsWithInventoryOutputRepresentation.cls#ConnectApi.FindRoutesWithFewestSplitsWithInventoryOutputRepresentation2rapexlib://resources/StandardApexLibrary/ConnectApi/FindRoutesWithFewestSplitsWithInventoryOutputRepresentation.cls8�
connectapi.flowapprovalprocessFlowApprovalProcess
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/FlowApprovalProcess.cls#ConnectApi.FlowApprovalProcess2Japexlib://resources/StandardApexLibrary/ConnectApi/FlowApprovalProcess.cls8�
$connectapi.flowapprovalprocessactionFlowApprovalProcessAction
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/FlowApprovalProcessAction.cls#ConnectApi.FlowApprovalProcessAction2Papexlib://resources/StandardApexLibrary/ConnectApi/FlowApprovalProcessAction.cls8�
(connectapi.flowapprovalprocesscollectionFlowApprovalProcessCollection
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/FlowApprovalProcessCollection.cls#ConnectApi.FlowApprovalProcessCollection2Tapexlib://resources/StandardApexLibrary/ConnectApi/FlowApprovalProcessCollection.cls8�
 connectapi.flowapprovalprocessesFlowApprovalProcesses
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/Flowapprovalprocesses.cls#ConnectApi.FlowApprovalProcesses2Lapexlib://resources/StandardApexLibrary/ConnectApi/Flowapprovalprocesses.cls8�
connectapi.followintentsFollowIntents
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/FollowIntents.cls#ConnectApi.FollowIntents2Dapexlib://resources/StandardApexLibrary/ConnectApi/FollowIntents.cls8�
$connectapi.followsocialpersonaintentFollowSocialPersonaIntent
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/FollowSocialPersonaIntent.cls#ConnectApi.FollowSocialPersonaIntent2Papexlib://resources/StandardApexLibrary/ConnectApi/FollowSocialPersonaIntent.cls8�
connectapi.followerpageFollowerPage
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/FollowerPage.cls#ConnectApi.FollowerPage2Capexlib://resources/StandardApexLibrary/ConnectApi/FollowerPage.cls8�
connectapi.followingcountsFollowingCounts
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/FollowingCounts.cls#ConnectApi.FollowingCounts2Fapexlib://resources/StandardApexLibrary/ConnectApi/FollowingCounts.cls8�
connectapi.followingpageFollowingPage
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/FollowingPage.cls#ConnectApi.FollowingPage2Dapexlib://resources/StandardApexLibrary/ConnectApi/FollowingPage.cls8�
connectapi.formForm
ConnectApi *Kapexlib://resources/StandardApexLibrary/ConnectApi/Form.cls#ConnectApi.Form2;apexlib://resources/StandardApexLibrary/ConnectApi/Form.cls8�
connectapi.formfield	FormField
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/FormField.cls#ConnectApi.FormField2@apexlib://resources/StandardApexLibrary/ConnectApi/FormField.cls8�
connectapi.formfieldinputFormFieldInput
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/FormFieldInput.cls#ConnectApi.FormFieldInput2Eapexlib://resources/StandardApexLibrary/ConnectApi/FormFieldInput.cls8�
connectapi.formfields
FormFields
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/FormFields.cls#ConnectApi.FormFields2Aapexlib://resources/StandardApexLibrary/ConnectApi/FormFields.cls8�
connectapi.forminput	FormInput
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/FormInput.cls#ConnectApi.FormInput2@apexlib://resources/StandardApexLibrary/ConnectApi/FormInput.cls8�
connectapi.formsubmissionFormSubmission
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/FormSubmission.cls#ConnectApi.FormSubmission2Eapexlib://resources/StandardApexLibrary/ConnectApi/FormSubmission.cls8�
#connectapi.formsubmissionfieldinputFormSubmissionFieldInput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/FormSubmissionFieldInput.cls#ConnectApi.FormSubmissionFieldInput2Oapexlib://resources/StandardApexLibrary/ConnectApi/FormSubmissionFieldInput.cls8�
connectapi.formsubmissioninputFormSubmissionInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/FormSubmissionInput.cls#ConnectApi.FormSubmissionInput2Japexlib://resources/StandardApexLibrary/ConnectApi/FormSubmissionInput.cls8�
connectapi.formulafiltertypeFormulaFilterType
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/FormulaFilterType.cls#ConnectApi.FormulaFilterType2Hapexlib://resources/StandardApexLibrary/ConnectApi/FormulaFilterType.cls8�
connectapi.formulascopeFormulaScope
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/FormulaScope.cls#ConnectApi.FormulaScope2Capexlib://resources/StandardApexLibrary/ConnectApi/FormulaScope.cls8�
.connectapi.fulfillmentgroupinputrepresentation#FulfillmentGroupInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentGroupInputRepresentation.cls#ConnectApi.FulfillmentGroupInputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentGroupInputRepresentation.cls8�
/connectapi.fulfillmentgroupoutputrepresentation$FulfillmentGroupOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentGroupOutputRepresentation.cls#ConnectApi.FulfillmentGroupOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentGroupOutputRepresentation.cls8�
connectapi.fulfillmentorderFulfillmentOrder
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrder.cls#ConnectApi.FulfillmentOrder2Gapexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrder.cls8�
>connectapi.fulfillmentordercancellineitemsoutputrepresentation3FulfillmentOrderCancelLineItemsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderCancelLineItemsOutputRepresentation.cls#ConnectApi.FulfillmentOrderCancelLineItemsOutputRepresentation2japexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderCancelLineItemsOutputRepresentation.cls8�
.connectapi.fulfillmentorderinputrepresentation#FulfillmentOrderInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderInputRepresentation.cls#ConnectApi.FulfillmentOrderInputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderInputRepresentation.cls8�
5connectapi.fulfillmentorderinvoiceinputrepresentation*FulfillmentOrderInvoiceInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderInvoiceInputRepresentation.cls#ConnectApi.FulfillmentOrderInvoiceInputRepresentation2aapexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderInvoiceInputRepresentation.cls8�
6connectapi.fulfillmentorderinvoiceoutputrepresentation+FulfillmentOrderInvoiceOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderInvoiceOutputRepresentation.cls#ConnectApi.FulfillmentOrderInvoiceOutputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderInvoiceOutputRepresentation.cls8�
6connectapi.fulfillmentorderlineiteminputrepresentation+FulfillmentOrderLineItemInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderLineItemInputRepresentation.cls#ConnectApi.FulfillmentOrderLineItemInputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderLineItemInputRepresentation.cls8�
?connectapi.fulfillmentorderlineitemstocancelinputrepresentation4FulfillmentOrderLineItemsToCancelInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderLineItemsToCancelInputRepresentation.cls#ConnectApi.FulfillmentOrderLineItemsToCancelInputRepresentation2kapexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderLineItemsToCancelInputRepresentation.cls8�
/connectapi.fulfillmentorderoutputrepresentation$FulfillmentOrderOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderOutputRepresentation.cls#ConnectApi.FulfillmentOrderOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/FulfillmentOrderOutputRepresentation.cls8�
connectapi.gatewaylogresponseGatewayLogResponse
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/GatewayLogResponse.cls#ConnectApi.GatewayLogResponse2Iapexlib://resources/StandardApexLibrary/ConnectApi/GatewayLogResponse.cls8�
"connectapi.genericbundlecapabilityGenericBundleCapability
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/GenericBundleCapability.cls#ConnectApi.GenericBundleCapability2Napexlib://resources/StandardApexLibrary/ConnectApi/GenericBundleCapability.cls8�
connectapi.genericfeedelementGenericFeedElement
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/GenericFeedElement.cls#ConnectApi.GenericFeedElement2Iapexlib://resources/StandardApexLibrary/ConnectApi/GenericFeedElement.cls8�
2connectapi.getfocapacityvaluesoutputrepresentation'GetFOCapacityValuesOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/GetFOCapacityValuesOutputRepresentation.cls#ConnectApi.GetFOCapacityValuesOutputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/GetFOCapacityValuesOutputRepresentation.cls8�
8connectapi.getfocapacityvaluesrequestinputrepresentation-GetFOCapacityValuesRequestInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/GetFOCapacityValuesRequestInputRepresentation.cls#ConnectApi.GetFOCapacityValuesRequestInputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/GetFOCapacityValuesRequestInputRepresentation.cls8�
connectapi.globalinfluenceGlobalInfluence
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/GlobalInfluence.cls#ConnectApi.GlobalInfluence2Fapexlib://resources/StandardApexLibrary/ConnectApi/GlobalInfluence.cls8�
%connectapi.goaldefinitioncategoryenumGoalDefinitionCategoryEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/GoalDefinitionCategoryEnum.cls#ConnectApi.GoalDefinitionCategoryEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/GoalDefinitionCategoryEnum.cls8�
!connectapi.grouparchivestatusenumGroupArchiveStatusEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/GroupArchiveStatusEnum.cls#ConnectApi.GroupArchiveStatusEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/GroupArchiveStatusEnum.cls8�
connectapi.groupchattersettingsGroupChatterSettings
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/GroupChatterSettings.cls#ConnectApi.GroupChatterSettings2Kapexlib://resources/StandardApexLibrary/ConnectApi/GroupChatterSettings.cls8�
connectapi.groupemailfreq_enumGroupEmailFreq_enum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/GroupEmailFreq_enum.cls#ConnectApi.GroupEmailFreq_enum2Japexlib://resources/StandardApexLibrary/ConnectApi/GroupEmailFreq_enum.cls8�
connectapi.groupinformationGroupInformation
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/GroupInformation.cls#ConnectApi.GroupInformation2Gapexlib://resources/StandardApexLibrary/ConnectApi/GroupInformation.cls8�
 connectapi.groupinformationinputGroupInformationInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/GroupInformationInput.cls#ConnectApi.GroupInformationInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/GroupInformationInput.cls8�
%connectapi.groupmemrequeststatus_enumGroupMemRequestStatus_enum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/GroupMemRequestStatus_enum.cls#ConnectApi.GroupMemRequestStatus_enum2Qapexlib://resources/StandardApexLibrary/ConnectApi/GroupMemRequestStatus_enum.cls8�
connectapi.groupmemtype_enumGroupMemType_enum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/GroupMemType_enum.cls#ConnectApi.GroupMemType_enum2Hapexlib://resources/StandardApexLibrary/ConnectApi/GroupMemType_enum.cls8�
connectapi.groupmemberGroupMember
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/GroupMember.cls#ConnectApi.GroupMember2Bapexlib://resources/StandardApexLibrary/ConnectApi/GroupMember.cls8�
connectapi.groupmemberpageGroupMemberPage
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/GroupMemberPage.cls#ConnectApi.GroupMemberPage2Fapexlib://resources/StandardApexLibrary/ConnectApi/GroupMemberPage.cls8�
!connectapi.groupmembershiprequestGroupMembershipRequest
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/GroupMembershipRequest.cls#ConnectApi.GroupMembershipRequest2Mapexlib://resources/StandardApexLibrary/ConnectApi/GroupMembershipRequest.cls8�
"connectapi.groupmembershiprequestsGroupMembershipRequests
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/GroupMembershipRequests.cls#ConnectApi.GroupMembershipRequests2Napexlib://resources/StandardApexLibrary/ConnectApi/GroupMembershipRequests.cls8�
connectapi.grouprecordGroupRecord
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/GroupRecord.cls#ConnectApi.GroupRecord2Bapexlib://resources/StandardApexLibrary/ConnectApi/GroupRecord.cls8�
connectapi.grouprecordpageGroupRecordPage
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/GroupRecordPage.cls#ConnectApi.GroupRecordPage2Fapexlib://resources/StandardApexLibrary/ConnectApi/GroupRecordPage.cls8�
)connectapi.groupviralinvitationstatusenumGroupViralInvitationStatusEnum
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/GroupViralInvitationStatusEnum.cls#ConnectApi.GroupViralInvitationStatusEnum2Uapexlib://resources/StandardApexLibrary/ConnectApi/GroupViralInvitationStatusEnum.cls8�
#connectapi.groupvisibilitytype_enumGroupVisibilityType_enum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/GroupVisibilityType_enum.cls#ConnectApi.GroupVisibilityType_enum2Oapexlib://resources/StandardApexLibrary/ConnectApi/GroupVisibilityType_enum.cls8�
connectapi.hashtagsegmentHashtagSegment
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/HashtagSegment.cls#ConnectApi.HashtagSegment2Eapexlib://resources/StandardApexLibrary/ConnectApi/HashtagSegment.cls8�
connectapi.hashtagsegmentinputHashtagSegmentInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/HashtagSegmentInput.cls#ConnectApi.HashtagSegmentInput2Japexlib://resources/StandardApexLibrary/ConnectApi/HashtagSegmentInput.cls8�
connectapi.hidesocialpostintentHideSocialPostIntent
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/HideSocialPostIntent.cls#ConnectApi.HideSocialPostIntent2Kapexlib://resources/StandardApexLibrary/ConnectApi/HideSocialPostIntent.cls8�
,connectapi.holdfocapacityinputrepresentation!HoldFOCapacityInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityInputRepresentation.cls#ConnectApi.HoldFOCapacityInputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityInputRepresentation.cls8�
-connectapi.holdfocapacityoutputrepresentation"HoldFOCapacityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityOutputRepresentation.cls#ConnectApi.HoldFOCapacityOutputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityOutputRepresentation.cls8�
3connectapi.holdfocapacityrequestinputrepresentation(HoldFOCapacityRequestInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityRequestInputRepresentation.cls#ConnectApi.HoldFOCapacityRequestInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityRequestInputRepresentation.cls8�
5connectapi.holdfocapacityresponseoutputrepresentation*HoldFOCapacityResponseOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityResponseOutputRepresentation.cls#ConnectApi.HoldFOCapacityResponseOutputRepresentation2aapexlib://resources/StandardApexLibrary/ConnectApi/HoldFOCapacityResponseOutputRepresentation.cls8�
)connectapi.httpheaderoutputrepresentationHttpHeaderOutputRepresentation
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/HttpHeaderOutputRepresentation.cls#ConnectApi.HttpHeaderOutputRepresentation2Uapexlib://resources/StandardApexLibrary/ConnectApi/HttpHeaderOutputRepresentation.cls8�
+connectapi.ibusinessobjectivesandrecsfamily IBusinessObjectivesAndRecsFamily
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/IBusinessObjectivesAndRecsFamily.cls#ConnectApi.IBusinessObjectivesAndRecsFamily2Wapexlib://resources/StandardApexLibrary/ConnectApi/IBusinessObjectivesAndRecsFamily.cls8�
connectapi.iconIcon
ConnectApi *Kapexlib://resources/StandardApexLibrary/ConnectApi/Icon.cls#ConnectApi.Icon2;apexlib://resources/StandardApexLibrary/ConnectApi/Icon.cls8�
'connectapi.identityproviderauthflowenumIdentityProviderAuthFlowEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/IdentityProviderAuthFlowEnum.cls#ConnectApi.IdentityProviderAuthFlowEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/IdentityProviderAuthFlowEnum.cls8�
+connectapi.identityproviderauthprotocolenum IdentityProviderAuthProtocolEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/IdentityProviderAuthProtocolEnum.cls#ConnectApi.IdentityProviderAuthProtocolEnum2Wapexlib://resources/StandardApexLibrary/ConnectApi/IdentityProviderAuthProtocolEnum.cls8�
)connectapi.identityproviderclientauthenumIdentityProviderClientAuthEnum
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/IdentityProviderClientAuthEnum.cls#ConnectApi.IdentityProviderClientAuthEnum2Uapexlib://resources/StandardApexLibrary/ConnectApi/IdentityProviderClientAuthEnum.cls8�
connectapi.inlineimagesegmentInlineImageSegment
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/InlineImageSegment.cls#ConnectApi.InlineImageSegment2Iapexlib://resources/StandardApexLibrary/ConnectApi/InlineImageSegment.cls8�
"connectapi.inlineimagesegmentinputInlineImageSegmentInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/InlineImageSegmentInput.cls#ConnectApi.InlineImageSegmentInput2Napexlib://resources/StandardApexLibrary/ConnectApi/InlineImageSegmentInput.cls8�
3connectapi.innerensurefundsasyncinputrepresentation(InnerEnsureFundsAsyncInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/InnerEnsureFundsAsyncInputRepresentation.cls#ConnectApi.InnerEnsureFundsAsyncInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/InnerEnsureFundsAsyncInputRepresentation.cls8�
,connectapi.insightvaluesoutputrepresentation!InsightValuesOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/InsightValuesOutputRepresentation.cls#ConnectApi.InsightValuesOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/InsightValuesOutputRepresentation.cls8�
'connectapi.insightsoutputrepresentationInsightsOutputRepresentation
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/InsightsOutputRepresentation.cls#ConnectApi.InsightsOutputRepresentation2Sapexlib://resources/StandardApexLibrary/ConnectApi/InsightsOutputRepresentation.cls8�
!connectapi.interactionscapabilityInteractionsCapability
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/InteractionsCapability.cls#ConnectApi.InteractionsCapability2Mapexlib://resources/StandardApexLibrary/ConnectApi/InteractionsCapability.cls8�
connectapi.invitation
Invitation
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/Invitation.cls#ConnectApi.Invitation2Aapexlib://resources/StandardApexLibrary/ConnectApi/Invitation.cls8�
connectapi.invitationsInvitations
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/Invitations.cls#ConnectApi.Invitations2Bapexlib://resources/StandardApexLibrary/ConnectApi/Invitations.cls8�
connectapi.inviteinputInviteInput
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/InviteInput.cls#ConnectApi.InviteInput2Bapexlib://resources/StandardApexLibrary/ConnectApi/InviteInput.cls8�
*connectapi.invoicetopayinputrepresentationInvoiceToPayInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/InvoiceToPayInputRepresentation.cls#ConnectApi.InvoiceToPayInputRepresentation2Vapexlib://resources/StandardApexLibrary/ConnectApi/InvoiceToPayInputRepresentation.cls8�
*connectapi.itemquantityinputrepresentationItemQuantityInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ItemQuantityInputRepresentation.cls#ConnectApi.ItemQuantityInputRepresentation2Vapexlib://resources/StandardApexLibrary/ConnectApi/ItemQuantityInputRepresentation.cls8�
+connectapi.itemquantityoutputrepresentation ItemQuantityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ItemQuantityOutputRepresentation.cls#ConnectApi.ItemQuantityOutputRepresentation2Wapexlib://resources/StandardApexLibrary/ConnectApi/ItemQuantityOutputRepresentation.cls8�
connectapi.knowledge	Knowledge
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/Knowledge.cls#ConnectApi.Knowledge2@apexlib://resources/StandardApexLibrary/ConnectApi/Knowledge.cls8�
"connectapi.knowledgearticleversionKnowledgeArticleVersion
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/KnowledgeArticleVersion.cls#ConnectApi.KnowledgeArticleVersion2Napexlib://resources/StandardApexLibrary/ConnectApi/KnowledgeArticleVersion.cls8�
,connectapi.knowledgearticleversioncollection!KnowledgeArticleVersionCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/KnowledgeArticleVersionCollection.cls#ConnectApi.KnowledgeArticleVersionCollection2Xapexlib://resources/StandardApexLibrary/ConnectApi/KnowledgeArticleVersionCollection.cls8�
connectapi.labeledrecordfieldLabeledRecordField
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/LabeledRecordField.cls#ConnectApi.LabeledRecordField2Iapexlib://resources/StandardApexLibrary/ConnectApi/LabeledRecordField.cls8�
connectapi.leadinput	LeadInput
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/LeadInput.cls#ConnectApi.LeadInput2@apexlib://resources/StandardApexLibrary/ConnectApi/LeadInput.cls8�
,connectapi.leadstatuspicklistvalueattributes!LeadStatusPicklistValueAttributes
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/LeadStatusPicklistValueAttributes.cls#ConnectApi.LeadStatusPicklistValueAttributes2Xapexlib://resources/StandardApexLibrary/ConnectApi/LeadStatusPicklistValueAttributes.cls8�
(connectapi.lightningextensioninformationLightningExtensionInformation
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/LightningExtensionInformation.cls#ConnectApi.LightningExtensionInformation2Tapexlib://resources/StandardApexLibrary/ConnectApi/LightningExtensionInformation.cls8�
connectapi.lightningschedulerLightningScheduler
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/LightningScheduler.cls#ConnectApi.LightningScheduler2Iapexlib://resources/StandardApexLibrary/ConnectApi/LightningScheduler.cls8�
connectapi.likeintent
LikeIntent
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/LikeIntent.cls#ConnectApi.LikeIntent2Aapexlib://resources/StandardApexLibrary/ConnectApi/LikeIntent.cls8�
connectapi.likeintentsLikeIntents
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/LikeIntents.cls#ConnectApi.LikeIntents2Bapexlib://resources/StandardApexLibrary/ConnectApi/LikeIntents.cls8�
connectapi.likesocialpostintentLikeSocialPostIntent
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/LikeSocialPostIntent.cls#ConnectApi.LikeSocialPostIntent2Kapexlib://resources/StandardApexLibrary/ConnectApi/LikeSocialPostIntent.cls8�
connectapi.likesummaryLikeSummary
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/LikeSummary.cls#ConnectApi.LikeSummary2Bapexlib://resources/StandardApexLibrary/ConnectApi/LikeSummary.cls8�
connectapi.lineitemresponseLineItemResponse
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/LineItemResponse.cls#ConnectApi.LineItemResponse2Gapexlib://resources/StandardApexLibrary/ConnectApi/LineItemResponse.cls8�
connectapi.linkattachmentLinkAttachment
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/LinkAttachment.cls#ConnectApi.LinkAttachment2Eapexlib://resources/StandardApexLibrary/ConnectApi/LinkAttachment.cls8�
connectapi.linkattachmentinputLinkAttachmentInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/LinkAttachmentInput.cls#ConnectApi.LinkAttachmentInput2Japexlib://resources/StandardApexLibrary/ConnectApi/LinkAttachmentInput.cls8�
connectapi.linkcapabilityLinkCapability
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/LinkCapability.cls#ConnectApi.LinkCapability2Eapexlib://resources/StandardApexLibrary/ConnectApi/LinkCapability.cls8�
connectapi.linkcapabilityinputLinkCapabilityInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/LinkCapabilityInput.cls#ConnectApi.LinkCapabilityInput2Japexlib://resources/StandardApexLibrary/ConnectApi/LinkCapabilityInput.cls8�
connectapi.linkmetadataLinkMetadata
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadata.cls#ConnectApi.LinkMetadata2Capexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadata.cls8�
!connectapi.linkmetadatacollectionLinkMetadataCollection
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadataCollection.cls#ConnectApi.LinkMetadataCollection2Mapexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadataCollection.cls8�
connectapi.linkmetadatasourceLinkMetadataSource
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadataSource.cls#ConnectApi.LinkMetadataSource2Iapexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadataSource.cls8�
connectapi.linkmetadatatypeLinkMetadataType
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadataType.cls#ConnectApi.LinkMetadataType2Gapexlib://resources/StandardApexLibrary/ConnectApi/LinkMetadataType.cls8�
connectapi.linksegmentLinkSegment
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/LinkSegment.cls#ConnectApi.LinkSegment2Bapexlib://resources/StandardApexLibrary/ConnectApi/LinkSegment.cls8�
connectapi.linksegmentinputLinkSegmentInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/LinkSegmentInput.cls#ConnectApi.LinkSegmentInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/LinkSegmentInput.cls8�
2connectapi.locationavailabilityinputrepresentation'LocationAvailabilityInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/LocationAvailabilityInputRepresentation.cls#ConnectApi.LocationAvailabilityInputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/LocationAvailabilityInputRepresentation.cls8�
/connectapi.locationcapacityoutputrepresentation$LocationCapacityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/LocationCapacityOutputRepresentation.cls#ConnectApi.LocationCapacityOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/LocationCapacityOutputRepresentation.cls8�
&connectapi.locationinputrepresentationLocationInputRepresentation
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/LocationInputRepresentation.cls#ConnectApi.LocationInputRepresentation2Rapexlib://resources/StandardApexLibrary/ConnectApi/LocationInputRepresentation.cls8�
'connectapi.locationoutputrepresentationLocationOutputRepresentation
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/LocationOutputRepresentation.cls#ConnectApi.LocationOutputRepresentation2Sapexlib://resources/StandardApexLibrary/ConnectApi/LocationOutputRepresentation.cls8�
connectapi.longlistLongList
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/LongList.cls#ConnectApi.LongList2?apexlib://resources/StandardApexLibrary/ConnectApi/LongList.cls8�
connectapi.mcsfoldershareMCSFolderShare
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShare.cls#ConnectApi.MCSFolderShare2Eapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShare.cls8�
#connectapi.mcsfoldersharecollectionMCSFolderShareCollection
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareCollection.cls#ConnectApi.MCSFolderShareCollection2Oapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareCollection.cls8�
.connectapi.mcsfoldersharecollectionupdateinput#MCSFolderShareCollectionUpdateInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareCollectionUpdateInput.cls#ConnectApi.MCSFolderShareCollectionUpdateInput2Zapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareCollectionUpdateInput.cls8�
connectapi.mcsfoldershareinputMCSFolderShareInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareInput.cls#ConnectApi.MCSFolderShareInput2Japexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareInput.cls8�
#connectapi.mcsfoldersharestatusenumMCSFolderShareStatusEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareStatusEnum.cls#ConnectApi.MCSFolderShareStatusEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareStatusEnum.cls8�
connectapi.mcsfoldersharetargetMCSFolderShareTarget
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareTarget.cls#ConnectApi.MCSFolderShareTarget2Kapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareTarget.cls8�
)connectapi.mcsfoldersharetargetcollectionMCSFolderShareTargetCollection
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareTargetCollection.cls#ConnectApi.MCSFolderShareTargetCollection2Uapexlib://resources/StandardApexLibrary/ConnectApi/MCSFolderShareTargetCollection.cls8�
connectapi.maintenanceinfoMaintenanceInfo
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/MaintenanceInfo.cls#ConnectApi.MaintenanceInfo2Fapexlib://resources/StandardApexLibrary/ConnectApi/MaintenanceInfo.cls8�
connectapi.maintenancetypeenumMaintenanceTypeEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/MaintenanceTypeEnum.cls#ConnectApi.MaintenanceTypeEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/MaintenanceTypeEnum.cls8�
connectapi.managedcontentManagedContent
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContent.cls#ConnectApi.ManagedContent2Eapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContent.cls8�
%connectapi.managedcontentassociationsManagedContentAssociations
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentAssociations.cls#ConnectApi.ManagedContentAssociations2Qapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentAssociations.cls8�
"connectapi.managedcontentbodyinputManagedContentBodyInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentBodyInput.cls#ConnectApi.ManagedContentBodyInput2Napexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentBodyInput.cls8�
 connectapi.managedcontentchannelManagedContentChannel
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannel.cls#ConnectApi.ManagedContentChannel2Lapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannel.cls8�
*connectapi.managedcontentchannelcollectionManagedContentChannelCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelCollection.cls#ConnectApi.ManagedContentChannelCollection2Vapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelCollection.cls8�
4connectapi.managedcontentchannelcreaterepresentation)ManagedContentChannelCreateRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelCreateRepresentation.cls#ConnectApi.ManagedContentChannelCreateRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelCreateRepresentation.cls8�
&connectapi.managedcontentchanneldetailManagedContentChannelDetail
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelDetail.cls#ConnectApi.ManagedContentChannelDetail2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelDetail.cls8�
4connectapi.managedcontentchanneldomainrepresentation)ManagedContentChannelDomainRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelDomainRepresentation.cls#ConnectApi.ManagedContentChannelDomainRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelDomainRepresentation.cls8�
'connectapi.managedcontentchannelsummaryManagedContentChannelSummary
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelSummary.cls#ConnectApi.ManagedContentChannelSummary2Sapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelSummary.cls8�
-connectapi.managedcontentchanneltargetsummary"ManagedContentChannelTargetSummary
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelTargetSummary.cls#ConnectApi.ManagedContentChannelTargetSummary2Yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelTargetSummary.cls8�
(connectapi.managedcontentchanneltypeenumManagedContentChannelTypeEnum
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelTypeEnum.cls#ConnectApi.ManagedContentChannelTypeEnum2Tapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelTypeEnum.cls8�
4connectapi.managedcontentchannelupdaterepresentation)ManagedContentChannelUpdateRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelUpdateRepresentation.cls#ConnectApi.ManagedContentChannelUpdateRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelUpdateRepresentation.cls8�
!connectapi.managedcontentchannelsManagedContentChannels
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannels.cls#ConnectApi.ManagedContentChannels2Mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannels.cls8�
/connectapi.managedcontentchannelsrepresentation$ManagedContentChannelsRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelsRepresentation.cls#ConnectApi.ManagedContentChannelsRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentChannelsRepresentation.cls8�
$connectapi.managedcontentclonestatusManagedContentCloneStatus
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCloneStatus.cls#ConnectApi.ManagedContentCloneStatus2Papexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCloneStatus.cls8�
(connectapi.managedcontentclonestatusenumManagedContentCloneStatusEnum
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCloneStatusEnum.cls#ConnectApi.ManagedContentCloneStatusEnum2Tapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCloneStatusEnum.cls8�
'connectapi.managedcontentclonedvariantsManagedContentClonedVariants
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentClonedVariants.cls#ConnectApi.ManagedContentClonedVariants2Sapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentClonedVariants.cls8�
'connectapi.managedcontentcollectionitemManagedContentCollectionItem
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCollectionItem.cls#ConnectApi.ManagedContentCollectionItem2Sapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCollectionItem.cls8�
2connectapi.managedcontentcollectionitemtypesummary'ManagedContentCollectionItemTypeSummary
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCollectionItemTypeSummary.cls#ConnectApi.ManagedContentCollectionItemTypeSummary2^apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCollectionItemTypeSummary.cls8�
(connectapi.managedcontentcollectionitemsManagedContentCollectionItems
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCollectionItems.cls#ConnectApi.ManagedContentCollectionItems2Tapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentCollectionItems.cls8�
-connectapi.managedcontentdateandtimenodevalue"ManagedContentDateAndTimeNodeValue
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDateAndTimeNodeValue.cls#ConnectApi.ManagedContentDateAndTimeNodeValue2Yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDateAndTimeNodeValue.cls8�
&connectapi.managedcontentdatenodevalueManagedContentDateNodeValue
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDateNodeValue.cls#ConnectApi.ManagedContentDateNodeValue2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDateNodeValue.cls8�
6connectapi.managedcontentdeliverychannelrepresentation+ManagedContentDeliveryChannelRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryChannelRepresentation.cls#ConnectApi.ManagedContentDeliveryChannelRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryChannelRepresentation.cls8�
=connectapi.managedcontentdeliverychannelsummaryrepresentation2ManagedContentDeliveryChannelSummaryRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryChannelSummaryRepresentation.cls#ConnectApi.ManagedContentDeliveryChannelSummaryRepresentation2iapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryChannelSummaryRepresentation.cls8�
7connectapi.managedcontentdeliverychannelsrepresentation,ManagedContentDeliveryChannelsRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryChannelsRepresentation.cls#ConnectApi.ManagedContentDeliveryChannelsRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryChannelsRepresentation.cls8�
)connectapi.managedcontentdeliverydocumentManagedContentDeliveryDocument
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryDocument.cls#ConnectApi.ManagedContentDeliveryDocument2Uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryDocument.cls8�
3connectapi.managedcontentdeliverydocumentcollection(ManagedContentDeliveryDocumentCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryDocumentCollection.cls#ConnectApi.ManagedContentDeliveryDocumentCollection2_apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryDocumentCollection.cls8�
0connectapi.managedcontentdeliverydocumentsummary%ManagedContentDeliveryDocumentSummary
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryDocumentSummary.cls#ConnectApi.ManagedContentDeliveryDocumentSummary2\apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDeliveryDocumentSummary.cls8�
!connectapi.managedcontentdocumentManagedContentDocument
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocument.cls#ConnectApi.ManagedContentDocument2Mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocument.cls8�
&connectapi.managedcontentdocumentcloneManagedContentDocumentClone
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocumentClone.cls#ConnectApi.ManagedContentDocumentClone2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocumentClone.cls8�
+connectapi.managedcontentdocumentcloneinput ManagedContentDocumentCloneInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocumentCloneInput.cls#ConnectApi.ManagedContentDocumentCloneInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocumentCloneInput.cls8�
&connectapi.managedcontentdocumentinputManagedContentDocumentInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocumentInput.cls#ConnectApi.ManagedContentDocumentInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentDocumentInput.cls8�
'connectapi.managedcontentfailedvariantsManagedContentFailedVariants
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentFailedVariants.cls#ConnectApi.ManagedContentFailedVariants2Sapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentFailedVariants.cls8�
&connectapi.managedcontentfoldersummaryManagedContentFolderSummary
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentFolderSummary.cls#ConnectApi.ManagedContentFolderSummary2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentFolderSummary.cls8�
'connectapi.managedcontentmedianodevalueManagedContentMediaNodeValue
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentMediaNodeValue.cls#ConnectApi.ManagedContentMediaNodeValue2Sapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentMediaNodeValue.cls8�
-connectapi.managedcontentmediasourcenodevalue"ManagedContentMediaSourceNodeValue
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentMediaSourceNodeValue.cls#ConnectApi.ManagedContentMediaSourceNodeValue2Yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentMediaSourceNodeValue.cls8�
&connectapi.managedcontentmediatypeenumManagedContentMediaTypeEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentMediaTypeEnum.cls#ConnectApi.ManagedContentMediaTypeEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentMediaTypeEnum.cls8�
!connectapi.managedcontentnodetypeManagedContentNodeType
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentNodeType.cls#ConnectApi.ManagedContentNodeType2Mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentNodeType.cls8�
%connectapi.managedcontentnodetypeenumManagedContentNodeTypeEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentNodeTypeEnum.cls#ConnectApi.ManagedContentNodeTypeEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentNodeTypeEnum.cls8�
"connectapi.managedcontentnodevalueManagedContentNodeValue
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentNodeValue.cls#ConnectApi.ManagedContentNodeValue2Napexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentNodeValue.cls8�
!connectapi.managedcontentproviderManagedContentProvider
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProvider.cls#ConnectApi.ManagedContentProvider2Mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProvider.cls8�
+connectapi.managedcontentprovidercollection ManagedContentProviderCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderCollection.cls#ConnectApi.ManagedContentProviderCollection2Wapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderCollection.cls8�
)connectapi.managedcontentproviderinstanceManagedContentProviderInstance
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderInstance.cls#ConnectApi.ManagedContentProviderInstance2Uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderInstance.cls8�
.connectapi.managedcontentproviderinstanceinput#ManagedContentProviderInstanceInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderInstanceInput.cls#ConnectApi.ManagedContentProviderInstanceInput2Zapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderInstanceInput.cls8�
)connectapi.managedcontentprovidertypeenumManagedContentProviderTypeEnum
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderTypeEnum.cls#ConnectApi.ManagedContentProviderTypeEnum2Uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentProviderTypeEnum.cls8�
%connectapi.managedcontentpublishinputManagedContentPublishInput
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentPublishInput.cls#ConnectApi.ManagedContentPublishInput2Qapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentPublishInput.cls8�
&connectapi.managedcontentpublishoutputManagedContentPublishOutput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentPublishOutput.cls#ConnectApi.ManagedContentPublishOutput2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentPublishOutput.cls8�
"connectapi.managedcontentreferenceManagedContentReference
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentReference.cls#ConnectApi.ManagedContentReference2Napexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentReference.cls8�
)connectapi.managedcontentreferencesummaryManagedContentReferenceSummary
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentReferenceSummary.cls#ConnectApi.ManagedContentReferenceSummary2Uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentReferenceSummary.cls8�
connectapi.managedcontentspaceManagedContentSpace
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpace.cls#ConnectApi.ManagedContentSpace2Japexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpace.cls8�
&connectapi.managedcontentspacebasetypeManagedContentSpaceBaseType
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceBaseType.cls#ConnectApi.ManagedContentSpaceBaseType2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceBaseType.cls8�
8connectapi.managedcontentspacechannelinputrepresentation-ManagedContentSpaceChannelInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelInputRepresentation.cls#ConnectApi.ManagedContentSpaceChannelInputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelInputRepresentation.cls8�
2connectapi.managedcontentspacechanneloperationenum'ManagedContentSpaceChannelOperationEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelOperationEnum.cls#ConnectApi.ManagedContentSpaceChannelOperationEnum2^apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelOperationEnum.cls8�
3connectapi.managedcontentspacechannelrepresentation(ManagedContentSpaceChannelRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelRepresentation.cls#ConnectApi.ManagedContentSpaceChannelRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelRepresentation.cls8�
/connectapi.managedcontentspacechannelstatusenum$ManagedContentSpaceChannelStatusEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelStatusEnum.cls#ConnectApi.ManagedContentSpaceChannelStatusEnum2[apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelStatusEnum.cls8�
9connectapi.managedcontentspacechannelsinputrepresentation.ManagedContentSpaceChannelsInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelsInputRepresentation.cls#ConnectApi.ManagedContentSpaceChannelsInputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelsInputRepresentation.cls8�
4connectapi.managedcontentspacechannelsrepresentation)ManagedContentSpaceChannelsRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelsRepresentation.cls#ConnectApi.ManagedContentSpaceChannelsRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceChannelsRepresentation.cls8�
6connectapi.managedcontentspacecollectionrepresentation+ManagedContentSpaceCollectionRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceCollectionRepresentation.cls#ConnectApi.ManagedContentSpaceCollectionRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceCollectionRepresentation.cls8�
#connectapi.managedcontentspaceinputManagedContentSpaceInput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceInput.cls#ConnectApi.ManagedContentSpaceInput2Oapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceInput.cls8�
%connectapi.managedcontentspacesummaryManagedContentSpaceSummary
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceSummary.cls#ConnectApi.ManagedContentSpaceSummary2Qapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceSummary.cls8�
&connectapi.managedcontentspacetypeenumManagedContentSpaceTypeEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceTypeEnum.cls#ConnectApi.ManagedContentSpaceTypeEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceTypeEnum.cls8�
)connectapi.managedcontentspaceupdateinputManagedContentSpaceUpdateInput
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceUpdateInput.cls#ConnectApi.ManagedContentSpaceUpdateInput2Uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaceUpdateInput.cls8�
connectapi.managedcontentspacesManagedContentSpaces
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaces.cls#ConnectApi.ManagedContentSpaces2Kapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentSpaces.cls8�
&connectapi.managedcontenttextnodevalueManagedContentTextNodeValue
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentTextNodeValue.cls#ConnectApi.ManagedContentTextNodeValue2Rapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentTextNodeValue.cls8�
connectapi.managedcontenttypeManagedContentType
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentType.cls#ConnectApi.ManagedContentType2Iapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentType.cls8�
$connectapi.managedcontenttypesummaryManagedContentTypeSummary
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentTypeSummary.cls#ConnectApi.ManagedContentTypeSummary2Papexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentTypeSummary.cls8�
'connectapi.managedcontentunpublishinputManagedContentUnpublishInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentUnpublishInput.cls#ConnectApi.ManagedContentUnpublishInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentUnpublishInput.cls8�
(connectapi.managedcontentunpublishoutputManagedContentUnpublishOutput
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentUnpublishOutput.cls#ConnectApi.ManagedContentUnpublishOutput2Tapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentUnpublishOutput.cls8�
$connectapi.managedcontentusersummaryManagedContentUserSummary
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentUserSummary.cls#ConnectApi.ManagedContentUserSummary2Papexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentUserSummary.cls8�
 connectapi.managedcontentvariantManagedContentVariant
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariant.cls#ConnectApi.ManagedContentVariant2Lapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariant.cls8�
*connectapi.managedcontentvariantstatusenumManagedContentVariantStatusEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariantStatusEnum.cls#ConnectApi.ManagedContentVariantStatusEnum2Vapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariantStatusEnum.cls8�
,connectapi.managedcontentvariantstatusoutput!ManagedContentVariantStatusOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariantStatusOutput.cls#ConnectApi.ManagedContentVariantStatusOutput2Xapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariantStatusOutput.cls8�
+connectapi.managedcontentvariantupdateinput ManagedContentVariantUpdateInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariantUpdateInput.cls#ConnectApi.ManagedContentVariantUpdateInput2Wapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVariantUpdateInput.cls8�
 connectapi.managedcontentversionManagedContentVersion
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVersion.cls#ConnectApi.ManagedContentVersion2Lapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVersion.cls8�
*connectapi.managedcontentversioncollectionManagedContentVersionCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVersionCollection.cls#ConnectApi.ManagedContentVersionCollection2Vapexlib://resources/StandardApexLibrary/ConnectApi/ManagedContentVersionCollection.cls8�
connectapi.managedsocialaccountManagedSocialAccount
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ManagedSocialAccount.cls#ConnectApi.ManagedSocialAccount2Kapexlib://resources/StandardApexLibrary/ConnectApi/ManagedSocialAccount.cls8�
 connectapi.managedsocialaccountsManagedSocialAccounts
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedSocialAccounts.cls#ConnectApi.ManagedSocialAccounts2Lapexlib://resources/StandardApexLibrary/ConnectApi/ManagedSocialAccounts.cls8�
connectapi.managedtopicManagedTopic
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopic.cls#ConnectApi.ManagedTopic2Capexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopic.cls8�
!connectapi.managedtopiccollectionManagedTopicCollection
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicCollection.cls#ConnectApi.ManagedTopicCollection2Mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicCollection.cls8�
.connectapi.managedtopicpositioncollectioninput#ManagedTopicPositionCollectionInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicPositionCollectionInput.cls#ConnectApi.ManagedTopicPositionCollectionInput2Zapexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicPositionCollectionInput.cls8�
$connectapi.managedtopicpositioninputManagedTopicPositionInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicPositionInput.cls#ConnectApi.ManagedTopicPositionInput2Papexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicPositionInput.cls8�
 connectapi.managedtopictype_enumManagedTopicType_enum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicType_enum.cls#ConnectApi.ManagedTopicType_enum2Lapexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopicType_enum.cls8�
connectapi.managedtopicsManagedTopics
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopics.cls#ConnectApi.ManagedTopics2Dapexlib://resources/StandardApexLibrary/ConnectApi/ManagedTopics.cls8�
!connectapi.managedcontentdeliveryManagedContentDelivery
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/Managedcontentdelivery.cls#ConnectApi.ManagedContentDelivery2Mapexlib://resources/StandardApexLibrary/ConnectApi/Managedcontentdelivery.cls8�
connectapi.marketingintegrationMarketingIntegration
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/MarketingIntegration.cls#ConnectApi.MarketingIntegration2Kapexlib://resources/StandardApexLibrary/ConnectApi/MarketingIntegration.cls8�
0connectapi.marketingintegrationformfieldtypeenum%MarketingIntegrationFormFieldTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MarketingIntegrationFormFieldTypeEnum.cls#ConnectApi.MarketingIntegrationFormFieldTypeEnum2\apexlib://resources/StandardApexLibrary/ConnectApi/MarketingIntegrationFormFieldTypeEnum.cls8�
connectapi.markupbeginsegmentMarkupBeginSegment
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/MarkupBeginSegment.cls#ConnectApi.MarkupBeginSegment2Iapexlib://resources/StandardApexLibrary/ConnectApi/MarkupBeginSegment.cls8�
"connectapi.markupbeginsegmentinputMarkupBeginSegmentInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/MarkupBeginSegmentInput.cls#ConnectApi.MarkupBeginSegmentInput2Napexlib://resources/StandardApexLibrary/ConnectApi/MarkupBeginSegmentInput.cls8�
connectapi.markupendsegmentMarkupEndSegment
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/MarkupEndSegment.cls#ConnectApi.MarkupEndSegment2Gapexlib://resources/StandardApexLibrary/ConnectApi/MarkupEndSegment.cls8�
 connectapi.markupendsegmentinputMarkupEndSegmentInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/MarkupEndSegmentInput.cls#ConnectApi.MarkupEndSegmentInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/MarkupEndSegmentInput.cls8�
connectapi.markuptypeenumMarkupTypeEnum
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/MarkupTypeEnum.cls#ConnectApi.MarkupTypeEnum2Eapexlib://resources/StandardApexLibrary/ConnectApi/MarkupTypeEnum.cls8�
connectapi.matchinfo	MatchInfo
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/MatchInfo.cls#ConnectApi.MatchInfo2@apexlib://resources/StandardApexLibrary/ConnectApi/MatchInfo.cls8�
connectapi.mediareferenceMediaReference
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/MediaReference.cls#ConnectApi.MediaReference2Eapexlib://resources/StandardApexLibrary/ConnectApi/MediaReference.cls8�
#connectapi.mediareferencecapabilityMediaReferenceCapability
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/MediaReferenceCapability.cls#ConnectApi.MediaReferenceCapability2Oapexlib://resources/StandardApexLibrary/ConnectApi/MediaReferenceCapability.cls8�
connectapi.mentioncompletionMentionCompletion
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/MentionCompletion.cls#ConnectApi.MentionCompletion2Hapexlib://resources/StandardApexLibrary/ConnectApi/MentionCompletion.cls8�
 connectapi.mentioncompletionpageMentionCompletionPage
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/MentionCompletionPage.cls#ConnectApi.MentionCompletionPage2Lapexlib://resources/StandardApexLibrary/ConnectApi/MentionCompletionPage.cls8�
%connectapi.mentioncompletiontype_enumMentionCompletionType_enum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/MentionCompletionType_enum.cls#ConnectApi.MentionCompletionType_enum2Qapexlib://resources/StandardApexLibrary/ConnectApi/MentionCompletionType_enum.cls8�
connectapi.mentionsegmentMentionSegment
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/MentionSegment.cls#ConnectApi.MentionSegment2Eapexlib://resources/StandardApexLibrary/ConnectApi/MentionSegment.cls8�
connectapi.mentionsegmentinputMentionSegmentInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/MentionSegmentInput.cls#ConnectApi.MentionSegmentInput2Japexlib://resources/StandardApexLibrary/ConnectApi/MentionSegmentInput.cls8�
connectapi.mentionvalidationMentionValidation
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/MentionValidation.cls#ConnectApi.MentionValidation2Hapexlib://resources/StandardApexLibrary/ConnectApi/MentionValidation.cls8�
"connectapi.mentionvalidationstatusMentionValidationStatus
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/MentionValidationStatus.cls#ConnectApi.MentionValidationStatus2Napexlib://resources/StandardApexLibrary/ConnectApi/MentionValidationStatus.cls8�
connectapi.mentionvalidationsMentionValidations
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/MentionValidations.cls#ConnectApi.MentionValidations2Iapexlib://resources/StandardApexLibrary/ConnectApi/MentionValidations.cls8�
connectapi.mentionsMentions
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/Mentions.cls#ConnectApi.Mentions2?apexlib://resources/StandardApexLibrary/ConnectApi/Mentions.cls8�
connectapi.messagebodyMessageBody
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/MessageBody.cls#ConnectApi.MessageBody2Bapexlib://resources/StandardApexLibrary/ConnectApi/MessageBody.cls8�
connectapi.messagebodyinputMessageBodyInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/MessageBodyInput.cls#ConnectApi.MessageBodyInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/MessageBodyInput.cls8�
connectapi.messagesegmentMessageSegment
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/MessageSegment.cls#ConnectApi.MessageSegment2Eapexlib://resources/StandardApexLibrary/ConnectApi/MessageSegment.cls8�
connectapi.messagesegmentinputMessageSegmentInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/MessageSegmentInput.cls#ConnectApi.MessageSegmentInput2Japexlib://resources/StandardApexLibrary/ConnectApi/MessageSegmentInput.cls8�
connectapi.missionsMissions
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/Missions.cls#ConnectApi.Missions2?apexlib://resources/StandardApexLibrary/ConnectApi/Missions.cls8�
connectapi.moderationcapabilityModerationCapability
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ModerationCapability.cls#ConnectApi.ModerationCapability2Kapexlib://resources/StandardApexLibrary/ConnectApi/ModerationCapability.cls8�
#connectapi.moderationflagitemdetailModerationFlagItemDetail
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ModerationFlagItemDetail.cls#ConnectApi.ModerationFlagItemDetail2Oapexlib://resources/StandardApexLibrary/ConnectApi/ModerationFlagItemDetail.cls8�
connectapi.moderationflagsModerationFlags
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ModerationFlags.cls#ConnectApi.ModerationFlags2Fapexlib://resources/StandardApexLibrary/ConnectApi/ModerationFlags.cls8�
$connectapi.moderationflagscollectionModerationFlagsCollection
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ModerationFlagsCollection.cls#ConnectApi.ModerationFlagsCollection2Papexlib://resources/StandardApexLibrary/ConnectApi/ModerationFlagsCollection.cls8�
connectapi.morechangessegmentMoreChangesSegment
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/MoreChangesSegment.cls#ConnectApi.MoreChangesSegment2Iapexlib://resources/StandardApexLibrary/ConnectApi/MoreChangesSegment.cls8�
connectapi.motifMotif
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Motif.cls#ConnectApi.Motif2<apexlib://resources/StandardApexLibrary/ConnectApi/Motif.cls8�
connectapi.msgsegenum
MsgSegEnum
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/MsgSegEnum.cls#ConnectApi.MsgSegEnum2Aapexlib://resources/StandardApexLibrary/ConnectApi/MsgSegEnum.cls8�
,connectapi.multipleasyncoutputrepresentation!MultipleAsyncOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MultipleAsyncOutputRepresentation.cls#ConnectApi.MultipleAsyncOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/MultipleAsyncOutputRepresentation.cls8�
6connectapi.multipleensurefundsasyncinputrepresentation+MultipleEnsureFundsAsyncInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MultipleEnsureFundsAsyncInputRepresentation.cls#ConnectApi.MultipleEnsureFundsAsyncInputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/MultipleEnsureFundsAsyncInputRepresentation.cls8�
6connectapi.multiplefulfillmentorderinputrepresentation+MultipleFulfillmentOrderInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderInputRepresentation.cls#ConnectApi.MultipleFulfillmentOrderInputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderInputRepresentation.cls8�
>connectapi.multiplefulfillmentorderinvoicesinputrepresentation3MultipleFulfillmentOrderInvoicesInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderInvoicesInputRepresentation.cls#ConnectApi.MultipleFulfillmentOrderInvoicesInputRepresentation2japexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderInvoicesInputRepresentation.cls8�
?connectapi.multiplefulfillmentorderinvoicesoutputrepresentation4MultipleFulfillmentOrderInvoicesOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderInvoicesOutputRepresentation.cls#ConnectApi.MultipleFulfillmentOrderInvoicesOutputRepresentation2kapexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderInvoicesOutputRepresentation.cls8�
7connectapi.multiplefulfillmentorderoutputrepresentation,MultipleFulfillmentOrderOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderOutputRepresentation.cls#ConnectApi.MultipleFulfillmentOrderOutputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/MultipleFulfillmentOrderOutputRepresentation.cls8�
connectapi.mutecapabilityMuteCapability
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/MuteCapability.cls#ConnectApi.MuteCapability2Eapexlib://resources/StandardApexLibrary/ConnectApi/MuteCapability.cls8�
connectapi.mutecapabilityinputMuteCapabilityInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/MuteCapabilityInput.cls#ConnectApi.MuteCapabilityInput2Japexlib://resources/StandardApexLibrary/ConnectApi/MuteCapabilityInput.cls8�
connectapi.mutesummaryMuteSummary
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/MuteSummary.cls#ConnectApi.MuteSummary2Bapexlib://resources/StandardApexLibrary/ConnectApi/MuteSummary.cls8�
connectapi.nbaactionparameterNBAActionParameter
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/NBAActionParameter.cls#ConnectApi.NBAActionParameter2Iapexlib://resources/StandardApexLibrary/ConnectApi/NBAActionParameter.cls8�
connectapi.nbaactiontypeenumNBAActionTypeEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/NBAActionTypeEnum.cls#ConnectApi.NBAActionTypeEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/NBAActionTypeEnum.cls8�
connectapi.nbaflowactionNBAFlowAction
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/NBAFlowAction.cls#ConnectApi.NBAFlowAction2Dapexlib://resources/StandardApexLibrary/ConnectApi/NBAFlowAction.cls8�
connectapi.nbaflowtypeenumNBAFlowTypeEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/NBAFlowTypeEnum.cls#ConnectApi.NBAFlowTypeEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/NBAFlowTypeEnum.cls8�
"connectapi.nbanativerecommendationNBANativeRecommendation
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/NBANativeRecommendation.cls#ConnectApi.NBANativeRecommendation2Napexlib://resources/StandardApexLibrary/ConnectApi/NBANativeRecommendation.cls8�
connectapi.nbareactiontypeenumNBAReactionTypeEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/NBAReactionTypeEnum.cls#ConnectApi.NBAReactionTypeEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/NBAReactionTypeEnum.cls8�
connectapi.nbarecommendationNBARecommendation
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/NBARecommendation.cls#ConnectApi.NBARecommendation2Hapexlib://resources/StandardApexLibrary/ConnectApi/NBARecommendation.cls8�
connectapi.nbarecommendationsNBARecommendations
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/NBARecommendations.cls#ConnectApi.NBARecommendations2Iapexlib://resources/StandardApexLibrary/ConnectApi/NBARecommendations.cls8�
connectapi.nbastrategyinputNBAStrategyInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/NBAStrategyInput.cls#ConnectApi.NBAStrategyInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/NBAStrategyInput.cls8�
connectapi.nbatargettypeenumNBATargetTypeEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/NBATargetTypeEnum.cls#ConnectApi.NBATargetTypeEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/NBATargetTypeEnum.cls8�
connectapi.namedcredentialNamedCredential
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredential.cls#ConnectApi.NamedCredential2Fapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredential.cls8�
(connectapi.namedcredentialcalloutoptionsNamedCredentialCalloutOptions
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialCalloutOptions.cls#ConnectApi.NamedCredentialCalloutOptions2Tapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialCalloutOptions.cls8�
-connectapi.namedcredentialcalloutoptionsinput"NamedCredentialCalloutOptionsInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialCalloutOptionsInput.cls#ConnectApi.NamedCredentialCalloutOptionsInput2Yapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialCalloutOptionsInput.cls8�
connectapi.namedcredentialinputNamedCredentialInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialInput.cls#ConnectApi.NamedCredentialInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialInput.cls8�
connectapi.namedcredentiallistNamedCredentialList
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialList.cls#ConnectApi.NamedCredentialList2Japexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialList.cls8�
#connectapi.namedcredentialparameterNamedCredentialParameter
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialParameter.cls#ConnectApi.NamedCredentialParameter2Oapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialParameter.cls8�
(connectapi.namedcredentialparameterinputNamedCredentialParameterInput
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialParameterInput.cls#ConnectApi.NamedCredentialParameterInput2Tapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialParameterInput.cls8�
+connectapi.namedcredentialparametertypeenum NamedCredentialParameterTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialParameterTypeEnum.cls#ConnectApi.NamedCredentialParameterTypeEnum2Wapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialParameterTypeEnum.cls8�
"connectapi.namedcredentialtypeenumNamedCredentialTypeEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialTypeEnum.cls#ConnectApi.NamedCredentialTypeEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentialTypeEnum.cls8�
connectapi.namedcredentialsNamedCredentials
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentials.cls#ConnectApi.NamedCredentials2Gapexlib://resources/StandardApexLibrary/ConnectApi/NamedCredentials.cls8�
connectapi.navigationmenuNavigationMenu
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenu.cls#ConnectApi.NavigationMenu2Eapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenu.cls8�
connectapi.navigationmenuitemNavigationMenuItem
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItem.cls#ConnectApi.NavigationMenuItem2Iapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItem.cls8�
+connectapi.navigationmenuitemactiontypeenum NavigationMenuItemActionTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemActionTypeEnum.cls#ConnectApi.NavigationMenuItemActionTypeEnum2Wapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemActionTypeEnum.cls8�
'connectapi.navigationmenuitemcollectionNavigationMenuItemCollection
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemCollection.cls#ConnectApi.NavigationMenuItemCollection2Sapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemCollection.cls8�
+connectapi.navigationmenuitemopentargetenum NavigationMenuItemOpenTargetEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemOpenTargetEnum.cls#ConnectApi.NavigationMenuItemOpenTargetEnum2Wapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemOpenTargetEnum.cls8�
%connectapi.navigationmenuitemtypeenumNavigationMenuItemTypeEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemTypeEnum.cls#ConnectApi.NavigationMenuItemTypeEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuItemTypeEnum.cls8�
&connectapi.navigationmenupagereferenceNavigationMenuPageReference
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuPageReference.cls#ConnectApi.NavigationMenuPageReference2Rapexlib://resources/StandardApexLibrary/ConnectApi/NavigationMenuPageReference.cls8�
connectapi.networkconnectionNetworkConnection
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/NetworkConnection.cls#ConnectApi.NetworkConnection2Hapexlib://resources/StandardApexLibrary/ConnectApi/NetworkConnection.cls8�
!connectapi.networkconnectioninputNetworkConnectionInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/NetworkConnectionInput.cls#ConnectApi.NetworkConnectionInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/NetworkConnectionInput.cls8�
!connectapi.newfileattachmentinputNewFileAttachmentInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/NewFileAttachmentInput.cls#ConnectApi.NewFileAttachmentInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/NewFileAttachmentInput.cls8�
"connectapi.newuseraudiencecriteriaNewUserAudienceCriteria
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/NewUserAudienceCriteria.cls#ConnectApi.NewUserAudienceCriteria2Napexlib://resources/StandardApexLibrary/ConnectApi/NewUserAudienceCriteria.cls8�
'connectapi.newuseraudiencecriteriainputNewUserAudienceCriteriaInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/NewUserAudienceCriteriaInput.cls#ConnectApi.NewUserAudienceCriteriaInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/NewUserAudienceCriteriaInput.cls8�
connectapi.nextbestactionNextBestAction
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/NextBestAction.cls#ConnectApi.NextBestAction2Eapexlib://resources/StandardApexLibrary/ConnectApi/NextBestAction.cls8�
"connectapi.nonentityrecommendationNonEntityRecommendation
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/NonEntityRecommendation.cls#ConnectApi.NonEntityRecommendation2Napexlib://resources/StandardApexLibrary/ConnectApi/NonEntityRecommendation.cls8�
connectapi.notfoundexceptionNotFoundException
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/NotFoundException.cls#ConnectApi.NotFoundException2Hapexlib://resources/StandardApexLibrary/ConnectApi/NotFoundException.cls8�
!connectapi.oauthcredentialauthurlOAuthCredentialAuthUrl
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/OAuthCredentialAuthUrl.cls#ConnectApi.OAuthCredentialAuthUrl2Mapexlib://resources/StandardApexLibrary/ConnectApi/OAuthCredentialAuthUrl.cls8�
&connectapi.oauthcredentialauthurlinputOAuthCredentialAuthUrlInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/OAuthCredentialAuthUrlInput.cls#ConnectApi.OAuthCredentialAuthUrlInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/OAuthCredentialAuthUrlInput.cls8�
&connectapi.ocibaseoutputrepresentationOCIBaseOutputRepresentation
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/OCIBaseOutputRepresentation.cls#ConnectApi.OCIBaseOutputRepresentation2Rapexlib://resources/StandardApexLibrary/ConnectApi/OCIBaseOutputRepresentation.cls8�
8connectapi.ocicreatereservationerroroutputrepresentation-OCICreateReservationErrorOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationErrorOutputRepresentation.cls#ConnectApi.OCICreateReservationErrorOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationErrorOutputRepresentation.cls8�
2connectapi.ocicreatereservationinputrepresentation'OCICreateReservationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationInputRepresentation.cls#ConnectApi.OCICreateReservationInputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationInputRepresentation.cls8�
3connectapi.ocicreatereservationoutputrepresentation(OCICreateReservationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationOutputRepresentation.cls#ConnectApi.OCICreateReservationOutputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationOutputRepresentation.cls8�
8connectapi.ocicreatereservationsingleinputrepresentation-OCICreateReservationSingleInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationSingleInputRepresentation.cls#ConnectApi.OCICreateReservationSingleInputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationSingleInputRepresentation.cls8�
9connectapi.ocicreatereservationsingleoutputrepresentation.OCICreateReservationSingleOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationSingleOutputRepresentation.cls#ConnectApi.OCICreateReservationSingleOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/OCICreateReservationSingleOutputRepresentation.cls8�
9connectapi.ocifulfillreservationerroroutputrepresentation.OCIFulfillReservationErrorOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationErrorOutputRepresentation.cls#ConnectApi.OCIFulfillReservationErrorOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationErrorOutputRepresentation.cls8�
3connectapi.ocifulfillreservationinputrepresentation(OCIFulfillReservationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationInputRepresentation.cls#ConnectApi.OCIFulfillReservationInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationInputRepresentation.cls8�
4connectapi.ocifulfillreservationoutputrepresentation)OCIFulfillReservationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationOutputRepresentation.cls#ConnectApi.OCIFulfillReservationOutputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationOutputRepresentation.cls8�
9connectapi.ocifulfillreservationsingleinputrepresentation.OCIFulfillReservationSingleInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationSingleInputRepresentation.cls#ConnectApi.OCIFulfillReservationSingleInputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationSingleInputRepresentation.cls8�
:connectapi.ocifulfillreservationsingleoutputrepresentation/OCIFulfillReservationSingleOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationSingleOutputRepresentation.cls#ConnectApi.OCIFulfillReservationSingleOutputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/OCIFulfillReservationSingleOutputRepresentation.cls8�
1connectapi.ocifutureinventoryoutputrepresentation&OCIFutureInventoryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIFutureInventoryOutputRepresentation.cls#ConnectApi.OCIFutureInventoryOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/OCIFutureInventoryOutputRepresentation.cls8�
9connectapi.ocigetinventoryavailabilityinputrepresentation.OCIGetInventoryAvailabilityInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIGetInventoryAvailabilityInputRepresentation.cls#ConnectApi.OCIGetInventoryAvailabilityInputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/OCIGetInventoryAvailabilityInputRepresentation.cls8�
:connectapi.ocigetinventoryavailabilityoutputrepresentation/OCIGetInventoryAvailabilityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIGetInventoryAvailabilityOutputRepresentation.cls#ConnectApi.OCIGetInventoryAvailabilityOutputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/OCIGetInventoryAvailabilityOutputRepresentation.cls8�
1connectapi.ociinventoryrecordoutputrepresentation&OCIInventoryRecordOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIInventoryRecordOutputRepresentation.cls#ConnectApi.OCIInventoryRecordOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/OCIInventoryRecordOutputRepresentation.cls8�
6connectapi.ocilocationavailabilityoutputrepresentation+OCILocationAvailabilityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCILocationAvailabilityOutputRepresentation.cls#ConnectApi.OCILocationAvailabilityOutputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/OCILocationAvailabilityOutputRepresentation.cls8�
;connectapi.ocilocationgroupavailabilityoutputrepresentation0OCILocationGroupAvailabilityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCILocationGroupAvailabilityOutputRepresentation.cls#ConnectApi.OCILocationGroupAvailabilityOutputRepresentation2gapexlib://resources/StandardApexLibrary/ConnectApi/OCILocationGroupAvailabilityOutputRepresentation.cls8�
:connectapi.ocipublishlocationstructureoutputrepresentation/OCIPublishLocationStructureOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIPublishLocationStructureOutputRepresentation.cls#ConnectApi.OCIPublishLocationStructureOutputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/OCIPublishLocationStructureOutputRepresentation.cls8�
@connectapi.ocipublishlocationstructurestatusoutputrepresentation5OCIPublishLocationStructureStatusOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIPublishLocationStructureStatusOutputRepresentation.cls#ConnectApi.OCIPublishLocationStructureStatusOutputRepresentation2lapexlib://resources/StandardApexLibrary/ConnectApi/OCIPublishLocationStructureStatusOutputRepresentation.cls8�
9connectapi.ocireleasereservationerroroutputrepresentation.OCIReleaseReservationErrorOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationErrorOutputRepresentation.cls#ConnectApi.OCIReleaseReservationErrorOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationErrorOutputRepresentation.cls8�
3connectapi.ocireleasereservationinputrepresentation(OCIReleaseReservationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationInputRepresentation.cls#ConnectApi.OCIReleaseReservationInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationInputRepresentation.cls8�
4connectapi.ocireleasereservationoutputrepresentation)OCIReleaseReservationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationOutputRepresentation.cls#ConnectApi.OCIReleaseReservationOutputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationOutputRepresentation.cls8�
9connectapi.ocireleasereservationsingleinputrepresentation.OCIReleaseReservationSingleInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationSingleInputRepresentation.cls#ConnectApi.OCIReleaseReservationSingleInputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationSingleInputRepresentation.cls8�
:connectapi.ocireleasereservationsingleoutputrepresentation/OCIReleaseReservationSingleOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationSingleOutputRepresentation.cls#ConnectApi.OCIReleaseReservationSingleOutputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/OCIReleaseReservationSingleOutputRepresentation.cls8�
:connectapi.ocitransferreservationerroroutputrepresentation/OCITransferReservationErrorOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationErrorOutputRepresentation.cls#ConnectApi.OCITransferReservationErrorOutputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationErrorOutputRepresentation.cls8�
4connectapi.ocitransferreservationinputrepresentation)OCITransferReservationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationInputRepresentation.cls#ConnectApi.OCITransferReservationInputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationInputRepresentation.cls8�
5connectapi.ocitransferreservationoutputrepresentation*OCITransferReservationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationOutputRepresentation.cls#ConnectApi.OCITransferReservationOutputRepresentation2aapexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationOutputRepresentation.cls8�
:connectapi.ocitransferreservationsingleinputrepresentation/OCITransferReservationSingleInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationSingleInputRepresentation.cls#ConnectApi.OCITransferReservationSingleInputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationSingleInputRepresentation.cls8�
;connectapi.ocitransferreservationsingleoutputrepresentation0OCITransferReservationSingleOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationSingleOutputRepresentation.cls#ConnectApi.OCITransferReservationSingleOutputRepresentation2gapexlib://resources/StandardApexLibrary/ConnectApi/OCITransferReservationSingleOutputRepresentation.cls8�
8connectapi.ociupdatereservationerroroutputrepresentation-OCIUpdateReservationErrorOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationErrorOutputRepresentation.cls#ConnectApi.OCIUpdateReservationErrorOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationErrorOutputRepresentation.cls8�
2connectapi.ociupdatereservationinputrepresentation'OCIUpdateReservationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationInputRepresentation.cls#ConnectApi.OCIUpdateReservationInputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationInputRepresentation.cls8�
3connectapi.ociupdatereservationoutputrepresentation(OCIUpdateReservationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationOutputRepresentation.cls#ConnectApi.OCIUpdateReservationOutputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationOutputRepresentation.cls8�
8connectapi.ociupdatereservationsingleinputrepresentation-OCIUpdateReservationSingleInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationSingleInputRepresentation.cls#ConnectApi.OCIUpdateReservationSingleInputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationSingleInputRepresentation.cls8�
9connectapi.ociupdatereservationsingleoutputrepresentation.OCIUpdateReservationSingleOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationSingleOutputRepresentation.cls#ConnectApi.OCIUpdateReservationSingleOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/OCIUpdateReservationSingleOutputRepresentation.cls8�
=connectapi.ociuploadinventoryavailabilityoutputrepresentation2OCIUploadInventoryAvailabilityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIUploadInventoryAvailabilityOutputRepresentation.cls#ConnectApi.OCIUploadInventoryAvailabilityOutputRepresentation2iapexlib://resources/StandardApexLibrary/ConnectApi/OCIUploadInventoryAvailabilityOutputRepresentation.cls8�
Cconnectapi.ociuploadinventoryavailabilitystatusoutputrepresentation8OCIUploadInventoryAvailabilityStatusOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OCIUploadInventoryAvailabilityStatusOutputRepresentation.cls#ConnectApi.OCIUploadInventoryAvailabilityStatusOutputRepresentation2oapexlib://resources/StandardApexLibrary/ConnectApi/OCIUploadInventoryAvailabilityStatusOutputRepresentation.cls8�
connectapi.oauthproviderinfoOauthProviderInfo
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/OauthProviderInfo.cls#ConnectApi.OauthProviderInfo2Hapexlib://resources/StandardApexLibrary/ConnectApi/OauthProviderInfo.cls8�
connectapi.objectmetadataObjectMetadata
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ObjectMetadata.cls#ConnectApi.ObjectMetadata2Eapexlib://resources/StandardApexLibrary/ConnectApi/ObjectMetadata.cls8�
connectapi.objectqueryinfoObjectQueryInfo
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ObjectQueryInfo.cls#ConnectApi.ObjectQueryInfo2Fapexlib://resources/StandardApexLibrary/ConnectApi/ObjectQueryInfo.cls8�
&connectapi.omnichannelinventoryserviceOmnichannelInventoryService
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/OmnichannelInventoryService.cls#ConnectApi.OmnichannelInventoryService2Rapexlib://resources/StandardApexLibrary/ConnectApi/OmnichannelInventoryService.cls8�
connectapi.omsanalyticsOMSAnalytics
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/Omsanalytics.cls#ConnectApi.OMSAnalytics2Capexlib://resources/StandardApexLibrary/ConnectApi/Omsanalytics.cls8�
connectapi.operationtypeenumOperationTypeEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/OperationTypeEnum.cls#ConnectApi.OperationTypeEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/OperationTypeEnum.cls8�
2connectapi.opportunitystagepicklistvalueattributes'OpportunityStagePicklistValueAttributes
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OpportunityStagePicklistValueAttributes.cls#ConnectApi.OpportunityStagePicklistValueAttributes2^apexlib://resources/StandardApexLibrary/ConnectApi/OpportunityStagePicklistValueAttributes.cls8�
)connectapi.orchestationworkitemstatusenumOrchestationWorkItemStatusEnum
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/OrchestationWorkItemStatusEnum.cls#ConnectApi.OrchestationWorkItemStatusEnum2Uapexlib://resources/StandardApexLibrary/ConnectApi/OrchestationWorkItemStatusEnum.cls8�
connectapi.orchestrationOrchestration
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/Orchestration.cls#ConnectApi.Orchestration2Dapexlib://resources/StandardApexLibrary/ConnectApi/Orchestration.cls8�
 connectapi.orchestrationinstanceOrchestrationInstance
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationInstance.cls#ConnectApi.OrchestrationInstance2Lapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationInstance.cls8�
*connectapi.orchestrationinstancecollectionOrchestrationInstanceCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationInstanceCollection.cls#ConnectApi.OrchestrationInstanceCollection2Vapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationInstanceCollection.cls8�
*connectapi.orchestrationinstancestatusenumOrchestrationInstanceStatusEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationInstanceStatusEnum.cls#ConnectApi.OrchestrationInstanceStatusEnum2Vapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationInstanceStatusEnum.cls8�
%connectapi.orchestrationstageinstanceOrchestrationStageInstance
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationStageInstance.cls#ConnectApi.OrchestrationStageInstance2Qapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationStageInstance.cls8�
$connectapi.orchestrationstepinstanceOrchestrationStepInstance
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationStepInstance.cls#ConnectApi.OrchestrationStepInstance2Papexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationStepInstance.cls8�
$connectapi.orchestrationsteptypeenumOrchestrationStepTypeEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationStepTypeEnum.cls#ConnectApi.OrchestrationStepTypeEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationStepTypeEnum.cls8�
 connectapi.orchestrationworkitemOrchestrationWorkItem
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationWorkItem.cls#ConnectApi.OrchestrationWorkItem2Lapexlib://resources/StandardApexLibrary/ConnectApi/OrchestrationWorkItem.cls8�
$connectapi.orderdeliverygroupsummaryOrderDeliveryGroupSummary
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummary.cls#ConnectApi.OrderDeliveryGroupSummary2Papexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummary.cls8�
.connectapi.orderdeliverygroupsummarycollection#OrderDeliveryGroupSummaryCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummaryCollection.cls#ConnectApi.OrderDeliveryGroupSummaryCollection2Zapexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummaryCollection.cls8�
0connectapi.orderdeliverygroupsummarylookupoutput%OrderDeliveryGroupSummaryLookupOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummaryLookupOutput.cls#ConnectApi.OrderDeliveryGroupSummaryLookupOutput2\apexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummaryLookupOutput.cls8�
,connectapi.orderdeliverygroupsummarysortenum!OrderDeliveryGroupSummarySortEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummarySortEnum.cls#ConnectApi.OrderDeliveryGroupSummarySortEnum2Xapexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryGroupSummarySortEnum.cls8�
*connectapi.orderdeliverymethodlookupoutputOrderDeliveryMethodLookupOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryMethodLookupOutput.cls#ConnectApi.OrderDeliveryMethodLookupOutput2Vapexlib://resources/StandardApexLibrary/ConnectApi/OrderDeliveryMethodLookupOutput.cls8�
connectapi.orderdirectionenumOrderDirectionEnum
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/OrderDirectionEnum.cls#ConnectApi.OrderDirectionEnum2Iapexlib://resources/StandardApexLibrary/ConnectApi/OrderDirectionEnum.cls8�
connectapi.orderitemsummaryOrderItemSummary
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummary.cls#ConnectApi.OrderItemSummary2Gapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummary.cls8�
/connectapi.orderitemsummaryadjustmentaggregates$OrderItemSummaryAdjustmentAggregates
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentAggregates.cls#ConnectApi.OrderItemSummaryAdjustmentAggregates2[apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentAggregates.cls8�
/connectapi.orderitemsummaryadjustmentcollection$OrderItemSummaryAdjustmentCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentCollection.cls#ConnectApi.OrderItemSummaryAdjustmentCollection2[apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentCollection.cls8�
4connectapi.orderitemsummaryadjustmentcollectioninput)OrderItemSummaryAdjustmentCollectionInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentCollectionInput.cls#ConnectApi.OrderItemSummaryAdjustmentCollectionInput2`apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentCollectionInput.cls8�
*connectapi.orderitemsummaryadjustmentinputOrderItemSummaryAdjustmentInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentInput.cls#ConnectApi.OrderItemSummaryAdjustmentInput2Vapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentInput.cls8�
)connectapi.orderitemsummaryadjustmentlistOrderItemSummaryAdjustmentList
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentList.cls#ConnectApi.OrderItemSummaryAdjustmentList2Uapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryAdjustmentList.cls8�
%connectapi.orderitemsummarycollectionOrderItemSummaryCollection
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryCollection.cls#ConnectApi.OrderItemSummaryCollection2Qapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryCollection.cls8�
.connectapi.orderitemsummaryinputrepresentation#OrderItemSummaryInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryInputRepresentation.cls#ConnectApi.OrderItemSummaryInputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryInputRepresentation.cls8�
'connectapi.orderitemsummarylookupoutputOrderItemSummaryLookupOutput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryLookupOutput.cls#ConnectApi.OrderItemSummaryLookupOutput2Sapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryLookupOutput.cls8�
/connectapi.orderitemsummaryoutputrepresentation$OrderItemSummaryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryOutputRepresentation.cls#ConnectApi.OrderItemSummaryOutputRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryOutputRepresentation.cls8�
"connectapi.orderitemsummaryproductOrderItemSummaryProduct
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryProduct.cls#ConnectApi.OrderItemSummaryProduct2Napexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummaryProduct.cls8�
#connectapi.orderitemsummarysortenumOrderItemSummarySortEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummarySortEnum.cls#ConnectApi.OrderItemSummarySortEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/OrderItemSummarySortEnum.cls8�
connectapi.ordernullsenumOrderNullsEnum
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/OrderNullsEnum.cls#ConnectApi.OrderNullsEnum2Eapexlib://resources/StandardApexLibrary/ConnectApi/OrderNullsEnum.cls8�
connectapi.orderpaymentsummaryOrderPaymentSummary
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/OrderPaymentSummary.cls#ConnectApi.OrderPaymentSummary2Japexlib://resources/StandardApexLibrary/ConnectApi/OrderPaymentSummary.cls8�
.connectapi.orderquantitiesoutputrepresentation#OrderQuantitiesOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderQuantitiesOutputRepresentation.cls#ConnectApi.OrderQuantitiesOutputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/OrderQuantitiesOutputRepresentation.cls8�
connectapi.ordershipmentOrderShipment
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/OrderShipment.cls#ConnectApi.OrderShipment2Dapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipment.cls8�
"connectapi.ordershipmentcollectionOrderShipmentCollection
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentCollection.cls#ConnectApi.OrderShipmentCollection2Napexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentCollection.cls8�
connectapi.ordershipmentitemOrderShipmentItem
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentItem.cls#ConnectApi.OrderShipmentItem2Hapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentItem.cls8�
&connectapi.ordershipmentitemcollectionOrderShipmentItemCollection
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentItemCollection.cls#ConnectApi.OrderShipmentItemCollection2Rapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentItemCollection.cls8�
$connectapi.ordershipmentitemsortenumOrderShipmentItemSortEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentItemSortEnum.cls#ConnectApi.OrderShipmentItemSortEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentItemSortEnum.cls8�
 connectapi.ordershipmentsortenumOrderShipmentSortEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentSortEnum.cls#ConnectApi.OrderShipmentSortEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/OrderShipmentSortEnum.cls8�
connectapi.ordersummaryOrderSummary
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummary.cls#ConnectApi.OrderSummary2Capexlib://resources/StandardApexLibrary/ConnectApi/OrderSummary.cls8�
!connectapi.ordersummaryadjustmentOrderSummaryAdjustment
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustment.cls#ConnectApi.OrderSummaryAdjustment2Mapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustment.cls8�
+connectapi.ordersummaryadjustmentaggregates OrderSummaryAdjustmentAggregates
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregates.cls#ConnectApi.OrderSummaryAdjustmentAggregates2Wapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregates.cls8�
5connectapi.ordersummaryadjustmentaggregatesasyncinput*OrderSummaryAdjustmentAggregatesAsyncInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregatesAsyncInput.cls#ConnectApi.OrderSummaryAdjustmentAggregatesAsyncInput2aapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregatesAsyncInput.cls8�
6connectapi.ordersummaryadjustmentaggregatesasyncoutput+OrderSummaryAdjustmentAggregatesAsyncOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregatesAsyncOutput.cls#ConnectApi.OrderSummaryAdjustmentAggregatesAsyncOutput2bapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregatesAsyncOutput.cls8�
5connectapi.ordersummaryadjustmentaggregatesstatusenum*OrderSummaryAdjustmentAggregatesStatusEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregatesStatusEnum.cls#ConnectApi.OrderSummaryAdjustmentAggregatesStatusEnum2aapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentAggregatesStatusEnum.cls8�
+connectapi.ordersummaryadjustmentcollection OrderSummaryAdjustmentCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentCollection.cls#ConnectApi.OrderSummaryAdjustmentCollection2Wapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentCollection.cls8�
/connectapi.ordersummaryadjustmenttargettypeenum$OrderSummaryAdjustmentTargetTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentTargetTypeEnum.cls#ConnectApi.OrderSummaryAdjustmentTargetTypeEnum2[apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryAdjustmentTargetTypeEnum.cls8�
/connectapi.ordersummarycollectionrepresentation$OrderSummaryCollectionRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryCollectionRepresentation.cls#ConnectApi.OrderSummaryCollectionRepresentation2[apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryCollectionRepresentation.cls8�
connectapi.ordersummarycreationOrderSummaryCreation
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryCreation.cls#ConnectApi.OrderSummaryCreation2Kapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryCreation.cls8�
*connectapi.ordersummaryinputrepresentationOrderSummaryInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryInputRepresentation.cls#ConnectApi.OrderSummaryInputRepresentation2Vapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryInputRepresentation.cls8�
"connectapi.ordersummarylookupinputOrderSummaryLookupInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryLookupInput.cls#ConnectApi.OrderSummaryLookupInput2Napexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryLookupInput.cls8�
#connectapi.ordersummarylookupoutputOrderSummaryLookupOutput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryLookupOutput.cls#ConnectApi.OrderSummaryLookupOutput2Oapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryLookupOutput.cls8�
+connectapi.ordersummaryoutputrepresentation OrderSummaryOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryOutputRepresentation.cls#ConnectApi.OrderSummaryOutputRepresentation2Wapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryOutputRepresentation.cls8�
'connectapi.ordersummaryproductattributeOrderSummaryProductAttribute
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryProductAttribute.cls#ConnectApi.OrderSummaryProductAttribute2Sapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryProductAttribute.cls8�
*connectapi.ordersummaryproductlookupoutputOrderSummaryProductLookupOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryProductLookupOutput.cls#ConnectApi.OrderSummaryProductLookupOutput2Vapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryProductLookupOutput.cls8�
%connectapi.ordersummaryrepresentationOrderSummaryRepresentation
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryRepresentation.cls#ConnectApi.OrderSummaryRepresentation2Qapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryRepresentation.cls8�
connectapi.ordersummarysortenumOrderSummarySortEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummarySortEnum.cls#ConnectApi.OrderSummarySortEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummarySortEnum.cls8�
(connectapi.ordersummaryverificationinputOrderSummaryVerificationInput
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryVerificationInput.cls#ConnectApi.OrderSummaryVerificationInput2Tapexlib://resources/StandardApexLibrary/ConnectApi/OrderSummaryVerificationInput.cls8�
#connectapi.ordertocartfailedproductOrderToCartFailedProduct
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/OrderToCartFailedProduct.cls#ConnectApi.OrderToCartFailedProduct2Oapexlib://resources/StandardApexLibrary/ConnectApi/OrderToCartFailedProduct.cls8�
connectapi.ordertocartinputOrderToCartInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/OrderToCartInput.cls#ConnectApi.OrderToCartInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/OrderToCartInput.cls8�
connectapi.ordertocartresultOrderToCartResult
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/OrderToCartResult.cls#ConnectApi.OrderToCartResult2Hapexlib://resources/StandardApexLibrary/ConnectApi/OrderToCartResult.cls8�
connectapi.organizationOrganization
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/Organization.cls#ConnectApi.Organization2Capexlib://resources/StandardApexLibrary/ConnectApi/Organization.cls8�
connectapi.organizationsettingsOrganizationSettings
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/OrganizationSettings.cls#ConnectApi.OrganizationSettings2Kapexlib://resources/StandardApexLibrary/ConnectApi/OrganizationSettings.cls8�
connectapi.origincapabilityOriginCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/OriginCapability.cls#ConnectApi.OriginCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/OriginCapability.cls8�
connectapi.outofofficeOutOfOffice
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/OutOfOffice.cls#ConnectApi.OutOfOffice2Bapexlib://resources/StandardApexLibrary/ConnectApi/OutOfOffice.cls8�
connectapi.pageinfoPageInfo
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/PageInfo.cls#ConnectApi.PageInfo2?apexlib://resources/StandardApexLibrary/ConnectApi/PageInfo.cls8�
$connectapi.pardotbusinessunitcontextPardotBusinessUnitContext
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/PardotBusinessUnitContext.cls#ConnectApi.PardotBusinessUnitContext2Papexlib://resources/StandardApexLibrary/ConnectApi/PardotBusinessUnitContext.cls8�
(connectapi.pardotbusinessunitcontextitemPardotBusinessUnitContextItem
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/PardotBusinessUnitContextItem.cls#ConnectApi.PardotBusinessUnitContextItem2Tapexlib://resources/StandardApexLibrary/ConnectApi/PardotBusinessUnitContextItem.cls8�
*connectapi.pardotbusinessunitcontextoutputPardotBusinessUnitContextOutput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PardotBusinessUnitContextOutput.cls#ConnectApi.PardotBusinessUnitContextOutput2Vapexlib://resources/StandardApexLibrary/ConnectApi/PardotBusinessUnitContextOutput.cls8�
(connectapi.paymentauthadjustmentresponsePaymentAuthAdjustmentResponse
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/PaymentAuthAdjustmentResponse.cls#ConnectApi.PaymentAuthAdjustmentResponse2Tapexlib://resources/StandardApexLibrary/ConnectApi/PaymentAuthAdjustmentResponse.cls8�
'connectapi.paymentauthorizationresponsePaymentAuthorizationResponse
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/PaymentAuthorizationResponse.cls#ConnectApi.PaymentAuthorizationResponse2Sapexlib://resources/StandardApexLibrary/ConnectApi/PaymentAuthorizationResponse.cls8�
,connectapi.paymentcreditoutputrepresentation!PaymentCreditOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditOutputRepresentation.cls#ConnectApi.PaymentCreditOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditOutputRepresentation.cls8�
3connectapi.paymentcreditsequenceinputrepresentation(PaymentCreditSequenceInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditSequenceInputRepresentation.cls#ConnectApi.PaymentCreditSequenceInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditSequenceInputRepresentation.cls8�
7connectapi.paymentcreditsequenceiteminputrepresentation,PaymentCreditSequenceItemInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditSequenceItemInputRepresentation.cls#ConnectApi.PaymentCreditSequenceItemInputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditSequenceItemInputRepresentation.cls8�
8connectapi.paymentcreditsequenceitemoutputrepresentation-PaymentCreditSequenceItemOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditSequenceItemOutputRepresentation.cls#ConnectApi.PaymentCreditSequenceItemOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/PaymentCreditSequenceItemOutputRepresentation.cls8�
connectapi.paymentgrouprequestPaymentGroupRequest
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PaymentGroupRequest.cls#ConnectApi.PaymentGroupRequest2Japexlib://resources/StandardApexLibrary/ConnectApi/PaymentGroupRequest.cls8�
connectapi.paymentgroupresponsePaymentGroupResponse
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/PaymentGroupResponse.cls#ConnectApi.PaymentGroupResponse2Kapexlib://resources/StandardApexLibrary/ConnectApi/PaymentGroupResponse.cls8�
)connectapi.paymentinfoinputrepresentationPaymentInfoInputRepresentation
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/PaymentInfoInputRepresentation.cls#ConnectApi.PaymentInfoInputRepresentation2Uapexlib://resources/StandardApexLibrary/ConnectApi/PaymentInfoInputRepresentation.cls8�
5connectapi.paymentinitiationsourceinputrepresentation*PaymentInitiationSourceInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentInitiationSourceInputRepresentation.cls#ConnectApi.PaymentInitiationSourceInputRepresentation2aapexlib://resources/StandardApexLibrary/ConnectApi/PaymentInitiationSourceInputRepresentation.cls8�
connectapi.paymentmethoddetailsPaymentMethodDetails
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodDetails.cls#ConnectApi.PaymentMethodDetails2Kapexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodDetails.cls8�
 connectapi.paymentmethodresponsePaymentMethodResponse
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodResponse.cls#ConnectApi.PaymentMethodResponse2Lapexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodResponse.cls8�
3connectapi.paymentmethodtokenizationgatewayresponse(PaymentMethodTokenizationGatewayResponse
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodTokenizationGatewayResponse.cls#ConnectApi.PaymentMethodTokenizationGatewayResponse2_apexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodTokenizationGatewayResponse.cls8�
+connectapi.paymentmethodtokenizationrequest PaymentMethodTokenizationRequest
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodTokenizationRequest.cls#ConnectApi.PaymentMethodTokenizationRequest2Wapexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodTokenizationRequest.cls8�
,connectapi.paymentmethodtokenizationresponse!PaymentMethodTokenizationResponse
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodTokenizationResponse.cls#ConnectApi.PaymentMethodTokenizationResponse2Xapexlib://resources/StandardApexLibrary/ConnectApi/PaymentMethodTokenizationResponse.cls8�
connectapi.paymentresponsePaymentResponse
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/PaymentResponse.cls#ConnectApi.PaymentResponse2Fapexlib://resources/StandardApexLibrary/ConnectApi/PaymentResponse.cls8�
connectapi.paymentsPayments
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/Payments.cls#ConnectApi.Payments2?apexlib://resources/StandardApexLibrary/ConnectApi/Payments.cls8�
connectapi.percentrecordfieldPercentRecordField
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/PercentRecordField.cls#ConnectApi.PercentRecordField2Iapexlib://resources/StandardApexLibrary/ConnectApi/PercentRecordField.cls8�
connectapi.periodtypeenumPeriodTypeEnum
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/PeriodTypeEnum.cls#ConnectApi.PeriodTypeEnum2Eapexlib://resources/StandardApexLibrary/ConnectApi/PeriodTypeEnum.cls8�
connectapi.personalizationPersonalization
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/Personalization.cls#ConnectApi.Personalization2Fapexlib://resources/StandardApexLibrary/ConnectApi/Personalization.cls8�
connectapi.phonenumberPhoneNumber
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/PhoneNumber.cls#ConnectApi.PhoneNumber2Bapexlib://resources/StandardApexLibrary/ConnectApi/PhoneNumber.cls8�
connectapi.photoPhoto
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Photo.cls#ConnectApi.Photo2<apexlib://resources/StandardApexLibrary/ConnectApi/Photo.cls8�
connectapi.photoinput
PhotoInput
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/PhotoInput.cls#ConnectApi.PhotoInput2Aapexlib://resources/StandardApexLibrary/ConnectApi/PhotoInput.cls8�
connectapi.pickticket
PickTicket
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/PickTicket.cls#ConnectApi.PickTicket2Aapexlib://resources/StandardApexLibrary/ConnectApi/PickTicket.cls8�
*connectapi.picklistattributesvaluetypeenumPicklistAttributesValueTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PicklistAttributesValueTypeEnum.cls#ConnectApi.PicklistAttributesValueTypeEnum2Vapexlib://resources/StandardApexLibrary/ConnectApi/PicklistAttributesValueTypeEnum.cls8�
connectapi.picklistrecordfieldPicklistRecordField
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PicklistRecordField.cls#ConnectApi.PicklistRecordField2Japexlib://resources/StandardApexLibrary/ConnectApi/PicklistRecordField.cls8�
connectapi.picklistvaluePicklistValue
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/PicklistValue.cls#ConnectApi.PicklistValue2Dapexlib://resources/StandardApexLibrary/ConnectApi/PicklistValue.cls8�
connectapi.picklistvaluesPicklistValues
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/PicklistValues.cls#ConnectApi.PicklistValues2Eapexlib://resources/StandardApexLibrary/ConnectApi/PicklistValues.cls8�
#connectapi.picklistvaluescollectionPicklistValuesCollection
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/PicklistValuesCollection.cls#ConnectApi.PicklistValuesCollection2Oapexlib://resources/StandardApexLibrary/ConnectApi/PicklistValuesCollection.cls8�
connectapi.pincapabilityPinCapability
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/PinCapability.cls#ConnectApi.PinCapability2Dapexlib://resources/StandardApexLibrary/ConnectApi/PinCapability.cls8�
connectapi.pincapabilityinputPinCapabilityInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/PinCapabilityInput.cls#ConnectApi.PinCapabilityInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/PinCapabilityInput.cls8�
connectapi.pinnedfeedelementsPinnedFeedElements
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/PinnedFeedElements.cls#ConnectApi.PinnedFeedElements2Iapexlib://resources/StandardApexLibrary/ConnectApi/PinnedFeedElements.cls8�
connectapi.platformactionPlatformAction
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/PlatformAction.cls#ConnectApi.PlatformAction2Eapexlib://resources/StandardApexLibrary/ConnectApi/PlatformAction.cls8�
connectapi.platformactiongroupPlatformActionGroup
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionGroup.cls#ConnectApi.PlatformActionGroup2Japexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionGroup.cls8�
&connectapi.platformactiongroupcategoryPlatformActionGroupCategory
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionGroupCategory.cls#ConnectApi.PlatformActionGroupCategory2Rapexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionGroupCategory.cls8�
#connectapi.platformactionstatusenumPlatformActionStatusEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionStatusEnum.cls#ConnectApi.PlatformActionStatusEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionStatusEnum.cls8�
!connectapi.platformactiontypeenumPlatformActionTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionTypeEnum.cls#ConnectApi.PlatformActionTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/PlatformActionTypeEnum.cls8�
connectapi.pollattachmentinputPollAttachmentInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PollAttachmentInput.cls#ConnectApi.PollAttachmentInput2Japexlib://resources/StandardApexLibrary/ConnectApi/PollAttachmentInput.cls8�
connectapi.pollcapabilityPollCapability
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/PollCapability.cls#ConnectApi.PollCapability2Eapexlib://resources/StandardApexLibrary/ConnectApi/PollCapability.cls8�
connectapi.pollcapabilityinputPollCapabilityInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PollCapabilityInput.cls#ConnectApi.PollCapabilityInput2Japexlib://resources/StandardApexLibrary/ConnectApi/PollCapabilityInput.cls8�
*connectapi.postauthapipaymentmethodrequestPostAuthApiPaymentMethodRequest
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PostAuthApiPaymentMethodRequest.cls#ConnectApi.PostAuthApiPaymentMethodRequest2Vapexlib://resources/StandardApexLibrary/ConnectApi/PostAuthApiPaymentMethodRequest.cls8�
"connectapi.postauthgatewayresponsePostAuthGatewayResponse
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/PostAuthGatewayResponse.cls#ConnectApi.PostAuthGatewayResponse2Napexlib://resources/StandardApexLibrary/ConnectApi/PostAuthGatewayResponse.cls8�
connectapi.postauthrequestPostAuthRequest
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/PostAuthRequest.cls#ConnectApi.PostAuthRequest2Fapexlib://resources/StandardApexLibrary/ConnectApi/PostAuthRequest.cls8�
$connectapi.postauthorizationresponsePostAuthorizationResponse
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/PostAuthorizationResponse.cls#ConnectApi.PostAuthorizationResponse2Papexlib://resources/StandardApexLibrary/ConnectApi/PostAuthorizationResponse.cls8�
$connectapi.predeterminedfilenameenumPreDeterminedFileNameEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/PreDeterminedFileNameEnum.cls#ConnectApi.PreDeterminedFileNameEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/PreDeterminedFileNameEnum.cls8�
connectapi.preservecartPreserveCart
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/PreserveCart.cls#ConnectApi.PreserveCart2Capexlib://resources/StandardApexLibrary/ConnectApi/PreserveCart.cls8�
,connectapi.previewcanceloutputrepresentation!PreviewCancelOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PreviewCancelOutputRepresentation.cls#ConnectApi.PreviewCancelOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/PreviewCancelOutputRepresentation.cls8�
8connectapi.previewcarttoexchangeorderinputrepresentation-PreviewCartToExchangeOrderInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PreviewCartToExchangeOrderInputRepresentation.cls#ConnectApi.PreviewCartToExchangeOrderInputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/PreviewCartToExchangeOrderInputRepresentation.cls8�
9connectapi.previewcarttoexchangeorderoutputrepresentation.PreviewCartToExchangeOrderOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PreviewCartToExchangeOrderOutputRepresentation.cls#ConnectApi.PreviewCartToExchangeOrderOutputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/PreviewCartToExchangeOrderOutputRepresentation.cls8�
,connectapi.previewreturnoutputrepresentation!PreviewReturnOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PreviewReturnOutputRepresentation.cls#ConnectApi.PreviewReturnOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/PreviewReturnOutputRepresentation.cls8�
"connectapi.priceadjustmentschedulePriceAdjustmentSchedule
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/PriceAdjustmentSchedule.cls#ConnectApi.PriceAdjustmentSchedule2Napexlib://resources/StandardApexLibrary/ConnectApi/PriceAdjustmentSchedule.cls8�
connectapi.priceadjustmenttierPriceAdjustmentTier
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PriceAdjustmentTier.cls#ConnectApi.PriceAdjustmentTier2Japexlib://resources/StandardApexLibrary/ConnectApi/PriceAdjustmentTier.cls8�
"connectapi.priceadjustmenttiertypePriceAdjustmentTierType
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/PriceAdjustmentTierType.cls#ConnectApi.PriceAdjustmentTierType2Napexlib://resources/StandardApexLibrary/ConnectApi/PriceAdjustmentTierType.cls8�
connectapi.pricinginputPricingInput
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/PricingInput.cls#ConnectApi.PricingInput2Capexlib://resources/StandardApexLibrary/ConnectApi/PricingInput.cls8�
connectapi.pricinglineiteminputPricingLineItemInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/PricingLineItemInput.cls#ConnectApi.PricingLineItemInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/PricingLineItemInput.cls8�
connectapi.pricingresultPricingResult
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/PricingResult.cls#ConnectApi.PricingResult2Dapexlib://resources/StandardApexLibrary/ConnectApi/PricingResult.cls8�
 connectapi.pricingresultlineitemPricingResultLineItem
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/PricingResultLineItem.cls#ConnectApi.PricingResultLineItem2Lapexlib://resources/StandardApexLibrary/ConnectApi/PricingResultLineItem.cls8�
connectapi.pricingtermunitenumPricingTermUnitEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PricingTermUnitEnum.cls#ConnectApi.PricingTermUnitEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/PricingTermUnitEnum.cls8�
connectapi.productattributeinfoProductAttributeInfo
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeInfo.cls#ConnectApi.ProductAttributeInfo2Kapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeInfo.cls8�
(connectapi.productattributeselectioninfoProductAttributeSelectionInfo
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSelectionInfo.cls#ConnectApi.ProductAttributeSelectionInfo2Tapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSelectionInfo.cls8�
connectapi.productattributesetProductAttributeSet
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSet.cls#ConnectApi.ProductAttributeSet2Japexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSet.cls8�
"connectapi.productattributesetinfoProductAttributeSetInfo
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSetInfo.cls#ConnectApi.ProductAttributeSetInfo2Napexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSetInfo.cls8�
%connectapi.productattributesetsummaryProductAttributeSetSummary
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSetSummary.cls#ConnectApi.ProductAttributeSetSummary2Qapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSetSummary.cls8�
"connectapi.productattributesummaryProductAttributeSummary
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSummary.cls#ConnectApi.ProductAttributeSummary2Napexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeSummary.cls8�
6connectapi.productattributevaluemetadatarepresentation+ProductAttributeValueMetadataRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeValueMetadataRepresentation.cls#ConnectApi.ProductAttributeValueMetadataRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeValueMetadataRepresentation.cls8�
'connectapi.productattributeviewtypeenumProductAttributeViewTypeEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeViewTypeEnum.cls#ConnectApi.ProductAttributeViewTypeEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributeViewTypeEnum.cls8�
*connectapi.productattributestoproductentryProductAttributesToProductEntry
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributesToProductEntry.cls#ConnectApi.ProductAttributesToProductEntry2Vapexlib://resources/StandardApexLibrary/ConnectApi/ProductAttributesToProductEntry.cls8�
#connectapi.productbundlechildoutputProductBundleChildOutput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ProductBundleChildOutput.cls#ConnectApi.ProductBundleChildOutput2Oapexlib://resources/StandardApexLibrary/ConnectApi/ProductBundleChildOutput.cls8�
connectapi.productcartitemProductCartItem
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ProductCartItem.cls#ConnectApi.ProductCartItem2Fapexlib://resources/StandardApexLibrary/ConnectApi/ProductCartItem.cls8�
$connectapi.productcartitemcollectionProductCartItemCollection
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ProductCartItemCollection.cls#ConnectApi.ProductCartItemCollection2Papexlib://resources/StandardApexLibrary/ConnectApi/ProductCartItemCollection.cls8�
connectapi.productcategorydataProductCategoryData
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryData.cls#ConnectApi.ProductCategoryData2Japexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryData.cls8�
 connectapi.productcategorydetailProductCategoryDetail
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryDetail.cls#ConnectApi.ProductCategoryDetail2Lapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryDetail.cls8�
*connectapi.productcategorydetailcollectionProductCategoryDetailCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryDetailCollection.cls#ConnectApi.ProductCategoryDetailCollection2Vapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryDetailCollection.cls8�
connectapi.productcategorymediaProductCategoryMedia
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryMedia.cls#ConnectApi.ProductCategoryMedia2Kapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryMedia.cls8�
$connectapi.productcategorymediagroupProductCategoryMediaGroup
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryMediaGroup.cls#ConnectApi.ProductCategoryMediaGroup2Papexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryMediaGroup.cls8�
connectapi.productcategorypathProductCategoryPath
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryPath.cls#ConnectApi.ProductCategoryPath2Japexlib://resources/StandardApexLibrary/ConnectApi/ProductCategoryPath.cls8�
connectapi.productchildProductChild
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ProductChild.cls#ConnectApi.ProductChild2Capexlib://resources/StandardApexLibrary/ConnectApi/ProductChild.cls8�
!connectapi.productchildcollectionProductChildCollection
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ProductChildCollection.cls#ConnectApi.ProductChildCollection2Mapexlib://resources/StandardApexLibrary/ConnectApi/ProductChildCollection.cls8�
connectapi.productclassenumProductClassEnum
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/ProductClassEnum.cls#ConnectApi.ProductClassEnum2Gapexlib://resources/StandardApexLibrary/ConnectApi/ProductClassEnum.cls8�
7connectapi.productdeliverestimationoutputrepresentation,ProductDeliverEstimationOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductDeliverEstimationOutputRepresentation.cls#ConnectApi.ProductDeliverEstimationOutputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/ProductDeliverEstimationOutputRepresentation.cls8�
connectapi.productdetailProductDetail
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/ProductDetail.cls#ConnectApi.ProductDetail2Dapexlib://resources/StandardApexLibrary/ConnectApi/ProductDetail.cls8�
-connectapi.productdetailsoutputrepresentation"ProductDetailsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductDetailsOutputRepresentation.cls#ConnectApi.ProductDetailsOutputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/ProductDetailsOutputRepresentation.cls8�
connectapi.productentitlementProductEntitlement
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ProductEntitlement.cls#ConnectApi.ProductEntitlement2Iapexlib://resources/StandardApexLibrary/ConnectApi/ProductEntitlement.cls8�
,connectapi.productexpandoutputrepresentation!ProductExpandOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductExpandOutputRepresentation.cls#ConnectApi.ProductExpandOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/ProductExpandOutputRepresentation.cls8�
0connectapi.productimagegroupoutputrepresentation%ProductImageGroupOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductImageGroupOutputRepresentation.cls#ConnectApi.ProductImageGroupOutputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/ProductImageGroupOutputRepresentation.cls8�
+connectapi.productimageoutputrepresentation ProductImageOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductImageOutputRepresentation.cls#ConnectApi.ProductImageOutputRepresentation2Wapexlib://resources/StandardApexLibrary/ConnectApi/ProductImageOutputRepresentation.cls8�
connectapi.productmediaProductMedia
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ProductMedia.cls#ConnectApi.ProductMedia2Capexlib://resources/StandardApexLibrary/ConnectApi/ProductMedia.cls8�
connectapi.productmediagroupProductMediaGroup
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/ProductMediaGroup.cls#ConnectApi.ProductMediaGroup2Hapexlib://resources/StandardApexLibrary/ConnectApi/ProductMediaGroup.cls8�
connectapi.productmediatypeenumProductMediaTypeEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ProductMediaTypeEnum.cls#ConnectApi.ProductMediaTypeEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/ProductMediaTypeEnum.cls8�
$connectapi.productmediausagetypeenumProductMediaUsageTypeEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ProductMediaUsageTypeEnum.cls#ConnectApi.ProductMediaUsageTypeEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/ProductMediaUsageTypeEnum.cls8�
&connectapi.productoutputrepresentationProductOutputRepresentation
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ProductOutputRepresentation.cls#ConnectApi.ProductOutputRepresentation2Rapexlib://resources/StandardApexLibrary/ConnectApi/ProductOutputRepresentation.cls8�
connectapi.productoverviewProductOverview
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ProductOverview.cls#ConnectApi.ProductOverview2Fapexlib://resources/StandardApexLibrary/ConnectApi/ProductOverview.cls8�
$connectapi.productoverviewcollectionProductOverviewCollection
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/ProductOverviewCollection.cls#ConnectApi.ProductOverviewCollection2Papexlib://resources/StandardApexLibrary/ConnectApi/ProductOverviewCollection.cls8�
connectapi.productpriceProductPrice
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ProductPrice.cls#ConnectApi.ProductPrice2Capexlib://resources/StandardApexLibrary/ConnectApi/ProductPrice.cls8�
connectapi.productpriceentryProductPriceEntry
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/ProductPriceEntry.cls#ConnectApi.ProductPriceEntry2Hapexlib://resources/StandardApexLibrary/ConnectApi/ProductPriceEntry.cls8�
4connectapi.productreturnratelistoutputrepresentation)ProductReturnRateListOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductReturnRateListOutputRepresentation.cls#ConnectApi.ProductReturnRateListOutputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ProductReturnRateListOutputRepresentation.cls8�
0connectapi.productreturnrateoutputrepresentation%ProductReturnRateOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductReturnRateOutputRepresentation.cls#ConnectApi.ProductReturnRateOutputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/ProductReturnRateOutputRepresentation.cls8�
1connectapi.productsearchfacetoutputrepresentation&ProductSearchFacetOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchFacetOutputRepresentation.cls#ConnectApi.ProductSearchFacetOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchFacetOutputRepresentation.cls8�
6connectapi.productsearchfacetvalueoutputrepresentation+ProductSearchFacetValueOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchFacetValueOutputRepresentation.cls#ConnectApi.ProductSearchFacetValueOutputRepresentation2bapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchFacetValueOutputRepresentation.cls8�
%connectapi.productsearchgroupinginputProductSearchGroupingInput
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchGroupingInput.cls#ConnectApi.ProductSearchGroupingInput2Qapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchGroupingInput.cls8�
1connectapi.productsearchimageoutputrepresentation&ProductSearchImageOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchImageOutputRepresentation.cls#ConnectApi.ProductSearchImageOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchImageOutputRepresentation.cls8�
connectapi.productsearchinputProductSearchInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchInput.cls#ConnectApi.ProductSearchInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchInput.cls8�
,connectapi.productsearchoutputrepresentation!ProductSearchOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchOutputRepresentation.cls#ConnectApi.ProductSearchOutputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchOutputRepresentation.cls8�
3connectapi.productsearchproductoutputrepresentation(ProductSearchProductOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchProductOutputRepresentation.cls#ConnectApi.ProductSearchProductOutputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchProductOutputRepresentation.cls8�
connectapi.productsearchresultsProductSearchResults
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchResults.cls#ConnectApi.ProductSearchResults2Kapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchResults.cls8�
*connectapi.productsearchsuggestionsresultsProductSearchSuggestionsResults
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchSuggestionsResults.cls#ConnectApi.ProductSearchSuggestionsResults2Vapexlib://resources/StandardApexLibrary/ConnectApi/ProductSearchSuggestionsResults.cls8�
connectapi.productsellingmodelProductSellingModel
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ProductSellingModel.cls#ConnectApi.ProductSellingModel2Japexlib://resources/StandardApexLibrary/ConnectApi/ProductSellingModel.cls8�
connectapi.productsummaryProductSummary
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ProductSummary.cls#ConnectApi.ProductSummary2Eapexlib://resources/StandardApexLibrary/ConnectApi/ProductSummary.cls8�
connectapi.productsummarypageProductSummaryPage
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/ProductSummaryPage.cls#ConnectApi.ProductSummaryPage2Iapexlib://resources/StandardApexLibrary/ConnectApi/ProductSummaryPage.cls8�
-connectapi.productvariantoutputrepresentation"ProductVariantOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductVariantOutputRepresentation.cls#ConnectApi.ProductVariantOutputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/ProductVariantOutputRepresentation.cls8�
8connectapi.productvariationattributeoutputrepresentation-ProductVariationAttributeOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationAttributeOutputRepresentation.cls#ConnectApi.ProductVariationAttributeOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationAttributeOutputRepresentation.cls8�
=connectapi.productvariationattributevalueoutputrepresentation2ProductVariationAttributeValueOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationAttributeValueOutputRepresentation.cls#ConnectApi.ProductVariationAttributeValueOutputRepresentation2iapexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationAttributeValueOutputRepresentation.cls8�
connectapi.productvariationinfoProductVariationInfo
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationInfo.cls#ConnectApi.ProductVariationInfo2Kapexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationInfo.cls8�
.connectapi.productvariationinputrepresentation#ProductVariationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationInputRepresentation.cls#ConnectApi.ProductVariationInputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/ProductVariationInputRepresentation.cls8�
+connectapi.productslistoutputrepresentation ProductsListOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ProductsListOutputRepresentation.cls#ConnectApi.ProductsListOutputRepresentation2Wapexlib://resources/StandardApexLibrary/ConnectApi/ProductsListOutputRepresentation.cls8�
'connectapi.promotionapproachingdiscountPromotionApproachingDiscount
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/PromotionApproachingDiscount.cls#ConnectApi.PromotionApproachingDiscount2Sapexlib://resources/StandardApexLibrary/ConnectApi/PromotionApproachingDiscount.cls8�
 connectapi.promotionbonusproductPromotionBonusProduct
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/PromotionBonusProduct.cls#ConnectApi.PromotionBonusProduct2Lapexlib://resources/StandardApexLibrary/ConnectApi/PromotionBonusProduct.cls8�
connectapi.promotioncartPromotionCart
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCart.cls#ConnectApi.PromotionCart2Dapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCart.cls8�
'connectapi.promotioncartadjustmentgroupPromotionCartAdjustmentGroup
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartAdjustmentGroup.cls#ConnectApi.PromotionCartAdjustmentGroup2Sapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartAdjustmentGroup.cls8�
,connectapi.promotioncartadjustmentgroupinput!PromotionCartAdjustmentGroupInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartAdjustmentGroupInput.cls#ConnectApi.PromotionCartAdjustmentGroupInput2Xapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartAdjustmentGroupInput.cls8�
%connectapi.promotioncartdeliverygroupPromotionCartDeliveryGroup
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryGroup.cls#ConnectApi.PromotionCartDeliveryGroup2Qapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryGroup.cls8�
*connectapi.promotioncartdeliverygroupinputPromotionCartDeliveryGroupInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryGroupInput.cls#ConnectApi.PromotionCartDeliveryGroupInput2Vapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryGroupInput.cls8�
+connectapi.promotioncartdeliverygroupmethod PromotionCartDeliveryGroupMethod
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryGroupMethod.cls#ConnectApi.PromotionCartDeliveryGroupMethod2Wapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryGroupMethod.cls8�
0connectapi.promotioncartdeliverymethodadjustment%PromotionCartDeliveryMethodAdjustment
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryMethodAdjustment.cls#ConnectApi.PromotionCartDeliveryMethodAdjustment2\apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartDeliveryMethodAdjustment.cls8�
connectapi.promotioncartinputPromotionCartInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartInput.cls#ConnectApi.PromotionCartInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartInput.cls8�
connectapi.promotioncartitemPromotionCartItem
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItem.cls#ConnectApi.PromotionCartItem2Hapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItem.cls8�
!connectapi.promotioncartiteminputPromotionCartItemInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItemInput.cls#ConnectApi.PromotionCartItemInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItemInput.cls8�
connectapi.promotioncartitemkeyPromotionCartItemKey
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItemKey.cls#ConnectApi.PromotionCartItemKey2Kapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItemKey.cls8�
+connectapi.promotioncartitempriceadjustment PromotionCartItemPriceAdjustment
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItemPriceAdjustment.cls#ConnectApi.PromotionCartItemPriceAdjustment2Wapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCartItemPriceAdjustment.cls8�
connectapi.promotioncouponPromotionCoupon
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCoupon.cls#ConnectApi.PromotionCoupon2Fapexlib://resources/StandardApexLibrary/ConnectApi/PromotionCoupon.cls8�
!connectapi.promotionevaluateinputPromotionEvaluateInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/PromotionEvaluateInput.cls#ConnectApi.PromotionEvaluateInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/PromotionEvaluateInput.cls8�
connectapi.promotionevaluationPromotionEvaluation
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PromotionEvaluation.cls#ConnectApi.PromotionEvaluation2Japexlib://resources/StandardApexLibrary/ConnectApi/PromotionEvaluation.cls8�
'connectapi.promotionparentproductsinputPromotionParentProductsInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/PromotionParentProductsInput.cls#ConnectApi.PromotionParentProductsInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/PromotionParentProductsInput.cls8�
*connectapi.promotionproductcategoriesinputPromotionProductCategoriesInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/PromotionProductCategoriesInput.cls#ConnectApi.PromotionProductCategoriesInput2Vapexlib://resources/StandardApexLibrary/ConnectApi/PromotionProductCategoriesInput.cls8�
connectapi.publishscheduleenumPublishScheduleEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/PublishScheduleEnum.cls#ConnectApi.PublishScheduleEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/PublishScheduleEnum.cls8�
connectapi.publishstatusenumPublishStatusEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/PublishStatusEnum.cls#ConnectApi.PublishStatusEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/PublishStatusEnum.cls8�
connectapi.purchasequantityrulePurchaseQuantityRule
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/PurchaseQuantityRule.cls#ConnectApi.PurchaseQuantityRule2Kapexlib://resources/StandardApexLibrary/ConnectApi/PurchaseQuantityRule.cls8�
-connectapi.quantitywithskuinputrepresentation"QuantityWithSkuInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/QuantityWithSkuInputRepresentation.cls#ConnectApi.QuantityWithSkuInputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/QuantityWithSkuInputRepresentation.cls8�
connectapi.queryinfo	QueryInfo
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/QueryInfo.cls#ConnectApi.QueryInfo2@apexlib://resources/StandardApexLibrary/ConnectApi/QueryInfo.cls8�
connectapi.querypath	QueryPath
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/QueryPath.cls#ConnectApi.QueryPath2@apexlib://resources/StandardApexLibrary/ConnectApi/QueryPath.cls8�
connectapi.querypathconfigQueryPathConfig
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/QueryPathConfig.cls#ConnectApi.QueryPathConfig2Fapexlib://resources/StandardApexLibrary/ConnectApi/QueryPathConfig.cls8�
connectapi.querypathconfiglistQueryPathConfigList
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/QueryPathConfigList.cls#ConnectApi.QueryPathConfigList2Japexlib://resources/StandardApexLibrary/ConnectApi/QueryPathConfigList.cls8�
connectapi.querypathinputQueryPathInput
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/QueryPathInput.cls#ConnectApi.QueryPathInput2Eapexlib://resources/StandardApexLibrary/ConnectApi/QueryPathInput.cls8�
connectapi.querypathinputconfigQueryPathInputConfig
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/QueryPathInputConfig.cls#ConnectApi.QueryPathInputConfig2Kapexlib://resources/StandardApexLibrary/ConnectApi/QueryPathInputConfig.cls8�
connectapi.querysqlinputQuerySqlInput
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlInput.cls#ConnectApi.QuerySqlInput2Dapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlInput.cls8�
connectapi.querysqlmetadataitemQuerySqlMetadataItem
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlMetadataItem.cls#ConnectApi.QuerySqlMetadataItem2Kapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlMetadataItem.cls8�
connectapi.querysqloutputQuerySqlOutput
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlOutput.cls#ConnectApi.QuerySqlOutput2Eapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlOutput.cls8�
connectapi.querysqlpageoutputQuerySqlPageOutput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlPageOutput.cls#ConnectApi.QuerySqlPageOutput2Iapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlPageOutput.cls8�
 connectapi.querysqlparameteritemQuerySqlParameterItem
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlParameterItem.cls#ConnectApi.QuerySqlParameterItem2Lapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlParameterItem.cls8�
connectapi.querysqlrowQuerySqlRow
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlRow.cls#ConnectApi.QuerySqlRow2Bapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlRow.cls8�
connectapi.querysqlstatusQuerySqlStatus
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlStatus.cls#ConnectApi.QuerySqlStatus2Eapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlStatus.cls8�
connectapi.querysqlstatusenumQuerySqlStatusEnum
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlStatusEnum.cls#ConnectApi.QuerySqlStatusEnum2Iapexlib://resources/StandardApexLibrary/ConnectApi/QuerySqlStatusEnum.cls8�
connectapi.questionandanswersQuestionAndAnswers
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswers.cls#ConnectApi.QuestionAndAnswers2Iapexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswers.cls8�
'connectapi.questionandanswerscapabilityQuestionAndAnswersCapability
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswersCapability.cls#ConnectApi.QuestionAndAnswersCapability2Sapexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswersCapability.cls8�
,connectapi.questionandanswerscapabilityinput!QuestionAndAnswersCapabilityInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswersCapabilityInput.cls#ConnectApi.QuestionAndAnswersCapabilityInput2Xapexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswersCapabilityInput.cls8�
(connectapi.questionandanswerssuggestionsQuestionAndAnswersSuggestions
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswersSuggestions.cls#ConnectApi.QuestionAndAnswersSuggestions2Tapexlib://resources/StandardApexLibrary/ConnectApi/QuestionAndAnswersSuggestions.cls8�
2connectapi.rangefacetdisplaymetadatarepresentation'RangeFacetDisplayMetadataRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RangeFacetDisplayMetadataRepresentation.cls#ConnectApi.RangeFacetDisplayMetadataRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/RangeFacetDisplayMetadataRepresentation.cls8�
connectapi.rangerefinementinputRangeRefinementInput
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/RangeRefinementInput.cls#ConnectApi.RangeRefinementInput2Kapexlib://resources/StandardApexLibrary/ConnectApi/RangeRefinementInput.cls8�
connectapi.rangesearchfacetRangeSearchFacet
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/RangeSearchFacet.cls#ConnectApi.RangeSearchFacet2Gapexlib://resources/StandardApexLibrary/ConnectApi/RangeSearchFacet.cls8�
1connectapi.rankaveragedistanceinputrepresentation&RankAverageDistanceInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RankAverageDistanceInputRepresentation.cls#ConnectApi.RankAverageDistanceInputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/RankAverageDistanceInputRepresentation.cls8�
2connectapi.rankaveragedistanceoutputrepresentation'RankAverageDistanceOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RankAverageDistanceOutputRepresentation.cls#ConnectApi.RankAverageDistanceOutputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/RankAverageDistanceOutputRepresentation.cls8�
connectapi.ratelimitexceptionRateLimitException
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/RateLimitException.cls#ConnectApi.RateLimitException2Iapexlib://resources/StandardApexLibrary/ConnectApi/RateLimitException.cls8�
connectapi.readbyReadBy
ConnectApi *Oapexlib://resources/StandardApexLibrary/ConnectApi/ReadBy.cls#ConnectApi.ReadBy2=apexlib://resources/StandardApexLibrary/ConnectApi/ReadBy.cls8�
connectapi.readbycapabilityReadByCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/ReadByCapability.cls#ConnectApi.ReadByCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/ReadByCapability.cls8�
 connectapi.readbycapabilityinputReadByCapabilityInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/ReadByCapabilityInput.cls#ConnectApi.ReadByCapabilityInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/ReadByCapabilityInput.cls8�
connectapi.readbypage
ReadByPage
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/ReadByPage.cls#ConnectApi.ReadByPage2Aapexlib://resources/StandardApexLibrary/ConnectApi/ReadByPage.cls8�
connectapi.recrepresentationRecRepresentation
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/RecRepresentation.cls#ConnectApi.RecRepresentation2Hapexlib://resources/StandardApexLibrary/ConnectApi/RecRepresentation.cls8�
connectapi.recencycriteriaRecencyCriteria
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/RecencyCriteria.cls#ConnectApi.RecencyCriteria2Fapexlib://resources/StandardApexLibrary/ConnectApi/RecencyCriteria.cls8�
*connectapi.recipientengagementcontextinputRecipientEngagementContextInput
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RecipientEngagementContextInput.cls#ConnectApi.RecipientEngagementContextInput2Vapexlib://resources/StandardApexLibrary/ConnectApi/RecipientEngagementContextInput.cls8�
connectapi.recommendationRecommendation
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/Recommendation.cls#ConnectApi.Recommendation2Eapexlib://resources/StandardApexLibrary/ConnectApi/Recommendation.cls8�
'connectapi.recommendationactiontypeenumRecommendationActionTypeEnum
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationActionTypeEnum.cls#ConnectApi.RecommendationActionTypeEnum2Sapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationActionTypeEnum.cls8�
,connectapi.recommendationaudcriteriatypeenum!RecommendationAudCriteriaTypeEnum
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudCriteriaTypeEnum.cls#ConnectApi.RecommendationAudCriteriaTypeEnum2Xapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudCriteriaTypeEnum.cls8�
!connectapi.recommendationaudienceRecommendationAudience
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudience.cls#ConnectApi.RecommendationAudience2Mapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudience.cls8�
&connectapi.recommendationaudienceinputRecommendationAudienceInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudienceInput.cls#ConnectApi.RecommendationAudienceInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudienceInput.cls8�
4connectapi.recommendationaudiencememberoperationtype)RecommendationAudienceMemberOperationType
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudienceMemberOperationType.cls#ConnectApi.RecommendationAudienceMemberOperationType2`apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudienceMemberOperationType.cls8�
%connectapi.recommendationaudiencepageRecommendationAudiencePage
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudiencePage.cls#ConnectApi.RecommendationAudiencePage2Qapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationAudiencePage.cls8�
$connectapi.recommendationchannelenumRecommendationChannelEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationChannelEnum.cls#ConnectApi.RecommendationChannelEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/RecommendationChannelEnum.cls8�
#connectapi.recommendationcollectionRecommendationCollection
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationCollection.cls#ConnectApi.RecommendationCollection2Oapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationCollection.cls8�
#connectapi.recommendationdefinitionRecommendationDefinition
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationDefinition.cls#ConnectApi.RecommendationDefinition2Oapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationDefinition.cls8�
(connectapi.recommendationdefinitioninputRecommendationDefinitionInput
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationDefinitionInput.cls#ConnectApi.RecommendationDefinitionInput2Tapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationDefinitionInput.cls8�
'connectapi.recommendationdefinitionpageRecommendationDefinitionPage
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationDefinitionPage.cls#ConnectApi.RecommendationDefinitionPage2Sapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationDefinitionPage.cls8�
$connectapi.recommendationexplanationRecommendationExplanation
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationExplanation.cls#ConnectApi.RecommendationExplanation2Papexlib://resources/StandardApexLibrary/ConnectApi/RecommendationExplanation.cls8�
(connectapi.recommendationexplanationenumRecommendationExplanationEnum
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationExplanationEnum.cls#ConnectApi.RecommendationExplanationEnum2Tapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationExplanationEnum.cls8�
!connectapi.recommendationreactionRecommendationReaction
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationReaction.cls#ConnectApi.RecommendationReaction2Mapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationReaction.cls8�
&connectapi.recommendationreactioninputRecommendationReactionInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationReactionInput.cls#ConnectApi.RecommendationReactionInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationReactionInput.cls8�
"connectapi.recommendationreactionsRecommendationReactions
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationReactions.cls#ConnectApi.RecommendationReactions2Napexlib://resources/StandardApexLibrary/ConnectApi/RecommendationReactions.cls8�
!connectapi.recommendationtypeenumRecommendationTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationTypeEnum.cls#ConnectApi.RecommendationTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationTypeEnum.cls8�
connectapi.recommendationsRecommendations
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/Recommendations.cls#ConnectApi.Recommendations2Fapexlib://resources/StandardApexLibrary/ConnectApi/Recommendations.cls8�
$connectapi.recommendationscapabilityRecommendationsCapability
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationsCapability.cls#ConnectApi.RecommendationsCapability2Papexlib://resources/StandardApexLibrary/ConnectApi/RecommendationsCapability.cls8�
.connectapi.recommendationsoutputrepresentation#RecommendationsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RecommendationsOutputRepresentation.cls#ConnectApi.RecommendationsOutputRepresentation2Zapexlib://resources/StandardApexLibrary/ConnectApi/RecommendationsOutputRepresentation.cls8�
connectapi.recommendedobjectRecommendedObject
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/RecommendedObject.cls#ConnectApi.RecommendedObject2Hapexlib://resources/StandardApexLibrary/ConnectApi/RecommendedObject.cls8�
$connectapi.recommendedobjecttypeenumRecommendedObjectTypeEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/RecommendedObjectTypeEnum.cls#ConnectApi.RecommendedObjectTypeEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/RecommendedObjectTypeEnum.cls8�
connectapi.recordcapabilityRecordCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/RecordCapability.cls#ConnectApi.RecordCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/RecordCapability.cls8�
 connectapi.recordcapabilityinputRecordCapabilityInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/RecordCapabilityInput.cls#ConnectApi.RecordCapabilityInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/RecordCapabilityInput.cls8�
 connectapi.recordcolumnorderenumRecordColumnOrderEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/RecordColumnOrderEnum.cls#ConnectApi.RecordColumnOrderEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/RecordColumnOrderEnum.cls8�
connectapi.recordfieldRecordField
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/RecordField.cls#ConnectApi.RecordField2Bapexlib://resources/StandardApexLibrary/ConnectApi/RecordField.cls8�
connectapi.recordfieldtypeenumRecordFieldTypeEnum
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/RecordFieldTypeEnum.cls#ConnectApi.RecordFieldTypeEnum2Japexlib://resources/StandardApexLibrary/ConnectApi/RecordFieldTypeEnum.cls8�
connectapi.recordfieldvalueRecordFieldValue
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/RecordFieldValue.cls#ConnectApi.RecordFieldValue2Gapexlib://resources/StandardApexLibrary/ConnectApi/RecordFieldValue.cls8�
%connectapi.recordfiltercriteriafamilyRecordFilterCriteriaFamily
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/RecordFilterCriteriaFamily.cls#ConnectApi.RecordFilterCriteriaFamily2Qapexlib://resources/StandardApexLibrary/ConnectApi/RecordFilterCriteriaFamily.cls8�
connectapi.recordsnapshotRecordSnapshot
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/RecordSnapshot.cls#ConnectApi.RecordSnapshot2Eapexlib://resources/StandardApexLibrary/ConnectApi/RecordSnapshot.cls8�
#connectapi.recordsnapshotattachmentRecordSnapshotAttachment
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/RecordSnapshotAttachment.cls#ConnectApi.RecordSnapshotAttachment2Oapexlib://resources/StandardApexLibrary/ConnectApi/RecordSnapshotAttachment.cls8�
#connectapi.recordsnapshotcapabilityRecordSnapshotCapability
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/RecordSnapshotCapability.cls#ConnectApi.RecordSnapshotCapability2Oapexlib://resources/StandardApexLibrary/ConnectApi/RecordSnapshotCapability.cls8�
connectapi.recordsummaryRecordSummary
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/RecordSummary.cls#ConnectApi.RecordSummary2Dapexlib://resources/StandardApexLibrary/ConnectApi/RecordSummary.cls8�
connectapi.recordsummarylistRecordSummaryList
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/RecordSummaryList.cls#ConnectApi.RecordSummaryList2Hapexlib://resources/StandardApexLibrary/ConnectApi/RecordSummaryList.cls8�
connectapi.recordview
RecordView
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/RecordView.cls#ConnectApi.RecordView2Aapexlib://resources/StandardApexLibrary/ConnectApi/RecordView.cls8�
connectapi.recordviewsectionRecordViewSection
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/RecordViewSection.cls#ConnectApi.RecordViewSection2Hapexlib://resources/StandardApexLibrary/ConnectApi/RecordViewSection.cls8�
connectapi.recordsRecords
ConnectApi *Qapexlib://resources/StandardApexLibrary/ConnectApi/Records.cls#ConnectApi.Records2>apexlib://resources/StandardApexLibrary/ConnectApi/Records.cls8�
"connectapi.recordsetfiltercriteriaRecordsetFilterCriteria
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/RecordsetFilterCriteria.cls#ConnectApi.RecordsetFilterCriteria2Napexlib://resources/StandardApexLibrary/ConnectApi/RecordsetFilterCriteria.cls8�
,connectapi.recordsetfiltercriteriacollection!RecordsetFilterCriteriaCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RecordsetFilterCriteriaCollection.cls#ConnectApi.RecordsetFilterCriteriaCollection2Xapexlib://resources/StandardApexLibrary/ConnectApi/RecordsetFilterCriteriaCollection.cls8�
'connectapi.recordsetfiltercriteriainputRecordsetFilterCriteriaInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/RecordsetFilterCriteriaInput.cls#ConnectApi.RecordsetFilterCriteriaInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/RecordsetFilterCriteriaInput.cls8�
connectapi.recorduiRecordUi
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/Recordui.cls#ConnectApi.RecordUi2?apexlib://resources/StandardApexLibrary/ConnectApi/Recordui.cls8�
connectapi.reference	Reference
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/Reference.cls#ConnectApi.Reference2@apexlib://resources/StandardApexLibrary/ConnectApi/Reference.cls8�
connectapi.referencerecordfieldReferenceRecordField
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/ReferenceRecordField.cls#ConnectApi.ReferenceRecordField2Kapexlib://resources/StandardApexLibrary/ConnectApi/ReferenceRecordField.cls8�
'connectapi.referencewithdaterecordfieldReferenceWithDateRecordField
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ReferenceWithDateRecordField.cls#ConnectApi.ReferenceWithDateRecordField2Sapexlib://resources/StandardApexLibrary/ConnectApi/ReferenceWithDateRecordField.cls8�
"connectapi.referencedrefundrequestReferencedRefundRequest
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ReferencedRefundRequest.cls#ConnectApi.ReferencedRefundRequest2Napexlib://resources/StandardApexLibrary/ConnectApi/ReferencedRefundRequest.cls8�
#connectapi.referencedrefundresponseReferencedRefundResponse
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ReferencedRefundResponse.cls#ConnectApi.ReferencedRefundResponse2Oapexlib://resources/StandardApexLibrary/ConnectApi/ReferencedRefundResponse.cls8�
connectapi.refinementinputRefinementInput
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/RefinementInput.cls#ConnectApi.RefinementInput2Fapexlib://resources/StandardApexLibrary/ConnectApi/RefinementInput.cls8�
 connectapi.refundgatewayresponseRefundGatewayResponse
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/RefundGatewayResponse.cls#ConnectApi.RefundGatewayResponse2Lapexlib://resources/StandardApexLibrary/ConnectApi/RefundGatewayResponse.cls8�
4connectapi.refundinstructionshintinputrepresentation)RefundInstructionsHintInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RefundInstructionsHintInputRepresentation.cls#ConnectApi.RefundInstructionsHintInputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/RefundInstructionsHintInputRepresentation.cls8�
5connectapi.refundinstructionshintoutputrepresentation*RefundInstructionsHintOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RefundInstructionsHintOutputRepresentation.cls#ConnectApi.RefundInstructionsHintOutputRepresentation2aapexlib://resources/StandardApexLibrary/ConnectApi/RefundInstructionsHintOutputRepresentation.cls8�
connectapi.refundrequestRefundRequest
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/RefundRequest.cls#ConnectApi.RefundRequest2Dapexlib://resources/StandardApexLibrary/ConnectApi/RefundRequest.cls8�
connectapi.refundresponseRefundResponse
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/RefundResponse.cls#ConnectApi.RefundResponse2Eapexlib://resources/StandardApexLibrary/ConnectApi/RefundResponse.cls8�
0connectapi.refundsequenceiteminputrepresentation%RefundSequenceItemInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RefundSequenceItemInputRepresentation.cls#ConnectApi.RefundSequenceItemInputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/RefundSequenceItemInputRepresentation.cls8�
1connectapi.refundsequenceitemoutputrepresentation&RefundSequenceItemOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RefundSequenceItemOutputRepresentation.cls#ConnectApi.RefundSequenceItemOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/RefundSequenceItemOutputRepresentation.cls8�
connectapi.registerguestbuyerRegisterGuestBuyer
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/RegisterGuestBuyer.cls#ConnectApi.RegisterGuestBuyer2Iapexlib://resources/StandardApexLibrary/ConnectApi/RegisterGuestBuyer.cls8�
1connectapi.registerguestbuyeroutputrepresentation&RegisterGuestBuyerOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RegisterGuestBuyerOutputRepresentation.cls#ConnectApi.RegisterGuestBuyerOutputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/RegisterGuestBuyerOutputRepresentation.cls8�
connectapi.relatedfeedpostRelatedFeedPost
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/RelatedFeedPost.cls#ConnectApi.RelatedFeedPost2Fapexlib://resources/StandardApexLibrary/ConnectApi/RelatedFeedPost.cls8�
"connectapi.relatedfeedposttypeenumRelatedFeedPostTypeEnum
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/RelatedFeedPostTypeEnum.cls#ConnectApi.RelatedFeedPostTypeEnum2Napexlib://resources/StandardApexLibrary/ConnectApi/RelatedFeedPostTypeEnum.cls8�
connectapi.relatedfeedpostsRelatedFeedPosts
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/RelatedFeedPosts.cls#ConnectApi.RelatedFeedPosts2Gapexlib://resources/StandardApexLibrary/ConnectApi/RelatedFeedPosts.cls8�
connectapi.relatedquestionRelatedQuestion
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/RelatedQuestion.cls#ConnectApi.RelatedQuestion2Fapexlib://resources/StandardApexLibrary/ConnectApi/RelatedQuestion.cls8�
&connectapi.relationshipcardinalityenumRelationshipCardinalityEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/RelationshipCardinalityEnum.cls#ConnectApi.RelationshipCardinalityEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/RelationshipCardinalityEnum.cls8�
3connectapi.releaseheldfocapacityinputrepresentation(ReleaseHeldFOCapacityInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityInputRepresentation.cls#ConnectApi.ReleaseHeldFOCapacityInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityInputRepresentation.cls8�
4connectapi.releaseheldfocapacityoutputrepresentation)ReleaseHeldFOCapacityOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityOutputRepresentation.cls#ConnectApi.ReleaseHeldFOCapacityOutputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityOutputRepresentation.cls8�
:connectapi.releaseheldfocapacityrequestinputrepresentation/ReleaseHeldFOCapacityRequestInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityRequestInputRepresentation.cls#ConnectApi.ReleaseHeldFOCapacityRequestInputRepresentation2fapexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityRequestInputRepresentation.cls8�
<connectapi.releaseheldfocapacityresponseoutputrepresentation1ReleaseHeldFOCapacityResponseOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityResponseOutputRepresentation.cls#ConnectApi.ReleaseHeldFOCapacityResponseOutputRepresentation2hapexlib://resources/StandardApexLibrary/ConnectApi/ReleaseHeldFOCapacityResponseOutputRepresentation.cls8�
connectapi.replyintentReplyIntent
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/ReplyIntent.cls#ConnectApi.ReplyIntent2Bapexlib://resources/StandardApexLibrary/ConnectApi/ReplyIntent.cls8�
connectapi.replyintentsReplyIntents
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/ReplyIntents.cls#ConnectApi.ReplyIntents2Capexlib://resources/StandardApexLibrary/ConnectApi/ReplyIntents.cls8�
connectapi.repositoryfiledetailRepositoryFileDetail
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFileDetail.cls#ConnectApi.RepositoryFileDetail2Kapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFileDetail.cls8�
 connectapi.repositoryfilesummaryRepositoryFileSummary
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFileSummary.cls#ConnectApi.RepositoryFileSummary2Lapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFileSummary.cls8�
!connectapi.repositoryfolderdetailRepositoryFolderDetail
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderDetail.cls#ConnectApi.RepositoryFolderDetail2Mapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderDetail.cls8�
connectapi.repositoryfolderitemRepositoryFolderItem
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderItem.cls#ConnectApi.RepositoryFolderItem2Kapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderItem.cls8�
*connectapi.repositoryfolderitemscollectionRepositoryFolderItemsCollection
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderItemsCollection.cls#ConnectApi.RepositoryFolderItemsCollection2Vapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderItemsCollection.cls8�
"connectapi.repositoryfoldersummaryRepositoryFolderSummary
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderSummary.cls#ConnectApi.RepositoryFolderSummary2Napexlib://resources/StandardApexLibrary/ConnectApi/RepositoryFolderSummary.cls8�
!connectapi.repositorygroupsummaryRepositoryGroupSummary
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryGroupSummary.cls#ConnectApi.RepositoryGroupSummary2Mapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryGroupSummary.cls8�
 connectapi.repositoryusersummaryRepositoryUserSummary
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryUserSummary.cls#ConnectApi.RepositoryUserSummary2Lapexlib://resources/StandardApexLibrary/ConnectApi/RepositoryUserSummary.cls8�
connectapi.repricing	Repricing
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/Repricing.cls#ConnectApi.Repricing2@apexlib://resources/StandardApexLibrary/ConnectApi/Repricing.cls8�
connectapi.reputation
Reputation
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/Reputation.cls#ConnectApi.Reputation2Aapexlib://resources/StandardApexLibrary/ConnectApi/Reputation.cls8�
connectapi.reputationlevelReputationLevel
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/ReputationLevel.cls#ConnectApi.ReputationLevel2Fapexlib://resources/StandardApexLibrary/ConnectApi/ReputationLevel.cls8�
connectapi.requestheaderRequestHeader
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/RequestHeader.cls#ConnectApi.RequestHeader2Dapexlib://resources/StandardApexLibrary/ConnectApi/RequestHeader.cls8�
connectapi.requestheaderinputRequestHeaderInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/RequestHeaderInput.cls#ConnectApi.RequestHeaderInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/RequestHeaderInput.cls8�
connectapi.requestmethodenumRequestMethodEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/RequestMethodEnum.cls#ConnectApi.RequestMethodEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/RequestMethodEnum.cls8�
connectapi.resourcelinksegmentResourceLinkSegment
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ResourceLinkSegment.cls#ConnectApi.ResourceLinkSegment2Japexlib://resources/StandardApexLibrary/ConnectApi/ResourceLinkSegment.cls8�
)connectapi.returnitemsinputrepresentationReturnItemsInputRepresentation
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ReturnItemsInputRepresentation.cls#ConnectApi.ReturnItemsInputRepresentation2Uapexlib://resources/StandardApexLibrary/ConnectApi/ReturnItemsInputRepresentation.cls8�
*connectapi.returnitemsoutputrepresentationReturnItemsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnItemsOutputRepresentation.cls#ConnectApi.ReturnItemsOutputRepresentation2Vapexlib://resources/StandardApexLibrary/ConnectApi/ReturnItemsOutputRepresentation.cls8�
connectapi.returnorderReturnOrder
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrder.cls#ConnectApi.ReturnOrder2Bapexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrder.cls8�
)connectapi.returnorderinputrepresentationReturnOrderInputRepresentation
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderInputRepresentation.cls#ConnectApi.ReturnOrderInputRepresentation2Uapexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderInputRepresentation.cls8�
;connectapi.returnorderitemdeliverychargeinputrepresentation0ReturnOrderItemDeliveryChargeInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemDeliveryChargeInputRepresentation.cls#ConnectApi.ReturnOrderItemDeliveryChargeInputRepresentation2gapexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemDeliveryChargeInputRepresentation.cls8�
0connectapi.returnorderitemfeeinputrepresentation%ReturnOrderItemFeeInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemFeeInputRepresentation.cls#ConnectApi.ReturnOrderItemFeeInputRepresentation2\apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemFeeInputRepresentation.cls8�
-connectapi.returnorderiteminputrepresentation"ReturnOrderItemInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemInputRepresentation.cls#ConnectApi.ReturnOrderItemInputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemInputRepresentation.cls8�
7connectapi.returnorderitemsplitlineoutputrepresentation,ReturnOrderItemSplitLineOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemSplitLineOutputRepresentation.cls#ConnectApi.ReturnOrderItemSplitLineOutputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderItemSplitLineOutputRepresentation.cls8�
4connectapi.returnorderlineitemfeeinputrepresentation)ReturnOrderLineItemFeeInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderLineItemFeeInputRepresentation.cls#ConnectApi.ReturnOrderLineItemFeeInputRepresentation2`apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderLineItemFeeInputRepresentation.cls8�
1connectapi.returnorderlineiteminputrepresentation&ReturnOrderLineItemInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderLineItemInputRepresentation.cls#ConnectApi.ReturnOrderLineItemInputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderLineItemInputRepresentation.cls8�
*connectapi.returnorderoutputrepresentationReturnOrderOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderOutputRepresentation.cls#ConnectApi.ReturnOrderOutputRepresentation2Vapexlib://resources/StandardApexLibrary/ConnectApi/ReturnOrderOutputRepresentation.cls8�
connectapi.routingRouting
ConnectApi *Qapexlib://resources/StandardApexLibrary/ConnectApi/Routing.cls#ConnectApi.Routing2>apexlib://resources/StandardApexLibrary/ConnectApi/Routing.cls8�
connectapi.spmstatusenumSPMStatusEnum
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/SPMStatusEnum.cls#ConnectApi.SPMStatusEnum2Dapexlib://resources/StandardApexLibrary/ConnectApi/SPMStatusEnum.cls8�
&connectapi.saleapipaymentmethodrequestSaleApiPaymentMethodRequest
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/SaleApiPaymentMethodRequest.cls#ConnectApi.SaleApiPaymentMethodRequest2Rapexlib://resources/StandardApexLibrary/ConnectApi/SaleApiPaymentMethodRequest.cls8�
connectapi.salegatewayresponseSaleGatewayResponse
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/SaleGatewayResponse.cls#ConnectApi.SaleGatewayResponse2Japexlib://resources/StandardApexLibrary/ConnectApi/SaleGatewayResponse.cls8�
connectapi.salerequestSaleRequest
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/SaleRequest.cls#ConnectApi.SaleRequest2Bapexlib://resources/StandardApexLibrary/ConnectApi/SaleRequest.cls8�
connectapi.saleresponseSaleResponse
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/SaleResponse.cls#ConnectApi.SaleResponse2Capexlib://resources/StandardApexLibrary/ConnectApi/SaleResponse.cls8�
connectapi.salesforceinboxSalesforceInbox
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/SalesforceInbox.cls#ConnectApi.SalesforceInbox2Fapexlib://resources/StandardApexLibrary/ConnectApi/SalesforceInbox.cls8�
"connectapi.scheduledrecommendationScheduledRecommendation
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ScheduledRecommendation.cls#ConnectApi.ScheduledRecommendation2Napexlib://resources/StandardApexLibrary/ConnectApi/ScheduledRecommendation.cls8�
'connectapi.scheduledrecommendationinputScheduledRecommendationInput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/ScheduledRecommendationInput.cls#ConnectApi.ScheduledRecommendationInput2Sapexlib://resources/StandardApexLibrary/ConnectApi/ScheduledRecommendationInput.cls8�
&connectapi.scheduledrecommendationpageScheduledRecommendationPage
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/ScheduledRecommendationPage.cls#ConnectApi.ScheduledRecommendationPage2Rapexlib://resources/StandardApexLibrary/ConnectApi/ScheduledRecommendationPage.cls8�
connectapi.scopeScope
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Scope.cls#ConnectApi.Scope2<apexlib://resources/StandardApexLibrary/ConnectApi/Scope.cls8�
connectapi.scopedsearchresultsScopedSearchResults
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/ScopedSearchResults.cls#ConnectApi.ScopedSearchResults2Japexlib://resources/StandardApexLibrary/ConnectApi/ScopedSearchResults.cls8�
connectapi.searchSearch
ConnectApi *Oapexlib://resources/StandardApexLibrary/ConnectApi/Search.cls#ConnectApi.Search2=apexlib://resources/StandardApexLibrary/ConnectApi/Search.cls8�
connectapi.searchanswerSearchAnswer
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/SearchAnswer.cls#ConnectApi.SearchAnswer2Capexlib://resources/StandardApexLibrary/ConnectApi/SearchAnswer.cls8�
connectapi.searchappliedorderbySearchAppliedOrderBy
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/SearchAppliedOrderBy.cls#ConnectApi.SearchAppliedOrderBy2Kapexlib://resources/StandardApexLibrary/ConnectApi/SearchAppliedOrderBy.cls8�
connectapi.searchcategorySearchCategory
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/SearchCategory.cls#ConnectApi.SearchCategory2Eapexlib://resources/StandardApexLibrary/ConnectApi/SearchCategory.cls8�
connectapi.searchdatacategorySearchDataCategory
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/SearchDataCategory.cls#ConnectApi.SearchDataCategory2Iapexlib://resources/StandardApexLibrary/ConnectApi/SearchDataCategory.cls8�
connectapi.searchfacetSearchFacet
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/SearchFacet.cls#ConnectApi.SearchFacet2Bapexlib://resources/StandardApexLibrary/ConnectApi/SearchFacet.cls8�
connectapi.searchfilterSearchFilter
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/SearchFilter.cls#ConnectApi.SearchFilter2Capexlib://resources/StandardApexLibrary/ConnectApi/SearchFilter.cls8�
connectapi.searchobjectSearchObject
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/SearchObject.cls#ConnectApi.SearchObject2Capexlib://resources/StandardApexLibrary/ConnectApi/SearchObject.cls8�
connectapi.searchorderbySearchOrderBy
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/SearchOrderBy.cls#ConnectApi.SearchOrderBy2Dapexlib://resources/StandardApexLibrary/ConnectApi/SearchOrderBy.cls8�
connectapi.searchrequestSearchRequest
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/SearchRequest.cls#ConnectApi.SearchRequest2Dapexlib://resources/StandardApexLibrary/ConnectApi/SearchRequest.cls8�
connectapi.searchresultSearchResult
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/SearchResult.cls#ConnectApi.SearchResult2Capexlib://resources/StandardApexLibrary/ConnectApi/SearchResult.cls8�
connectapi.searchresultgroupSearchResultGroup
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/SearchResultGroup.cls#ConnectApi.SearchResultGroup2Hapexlib://resources/StandardApexLibrary/ConnectApi/SearchResultGroup.cls8�
connectapi.searchresultgroupsSearchResultGroups
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/SearchResultGroups.cls#ConnectApi.SearchResultGroups2Iapexlib://resources/StandardApexLibrary/ConnectApi/SearchResultGroups.cls8�
connectapi.searchstatusSearchStatus
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/SearchStatus.cls#ConnectApi.SearchStatus2Capexlib://resources/StandardApexLibrary/ConnectApi/SearchStatus.cls8�
connectapi.searchsuggestionSearchSuggestion
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/SearchSuggestion.cls#ConnectApi.SearchSuggestion2Gapexlib://resources/StandardApexLibrary/ConnectApi/SearchSuggestion.cls8�
connectapi.segmenttypeenumSegmentTypeEnum
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/SegmentTypeEnum.cls#ConnectApi.SegmentTypeEnum2Fapexlib://resources/StandardApexLibrary/ConnectApi/SegmentTypeEnum.cls8�
connectapi.sellerdetailsrequestSellerDetailsRequest
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/SellerDetailsRequest.cls#ConnectApi.SellerDetailsRequest2Kapexlib://resources/StandardApexLibrary/ConnectApi/SellerDetailsRequest.cls8�
connectapi.sellingmodeltypeenumSellingModelTypeEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/SellingModelTypeEnum.cls#ConnectApi.SellingModelTypeEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/SellingModelTypeEnum.cls8�
9connectapi.sequenceorderpaymentsummaryinputrepresentation.SequenceOrderPaymentSummaryInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/SequenceOrderPaymentSummaryInputRepresentation.cls#ConnectApi.SequenceOrderPaymentSummaryInputRepresentation2eapexlib://resources/StandardApexLibrary/ConnectApi/SequenceOrderPaymentSummaryInputRepresentation.cls8�
"connectapi.serviceappointmentinputServiceAppointmentInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentInput.cls#ConnectApi.ServiceAppointmentInput2Napexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentInput.cls8�
%connectapi.serviceappointmentmodeenumServiceAppointmentModeEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentModeEnum.cls#ConnectApi.ServiceAppointmentModeEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentModeEnum.cls8�
#connectapi.serviceappointmentoutputServiceAppointmentOutput
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentOutput.cls#ConnectApi.ServiceAppointmentOutput2Oapexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentOutput.cls8�
#connectapi.serviceappointmentresultServiceAppointmentResult
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentResult.cls#ConnectApi.ServiceAppointmentResult2Oapexlib://resources/StandardApexLibrary/ConnectApi/ServiceAppointmentResult.cls8�
?connectapi.sharedorderpaymentsummarysequenceinputrepresentation4SharedOrderPaymentSummarySequenceInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/SharedOrderPaymentSummarySequenceInputRepresentation.cls#ConnectApi.SharedOrderPaymentSummarySequenceInputRepresentation2kapexlib://resources/StandardApexLibrary/ConnectApi/SharedOrderPaymentSummarySequenceInputRepresentation.cls8�
connectapi.shiftsfrompatternShiftsFromPattern
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/ShiftsFromPattern.cls#ConnectApi.ShiftsFromPattern2Hapexlib://resources/StandardApexLibrary/ConnectApi/ShiftsFromPattern.cls8�
!connectapi.shiftsfrompatternerrorShiftsFromPatternError
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ShiftsFromPatternError.cls#ConnectApi.ShiftsFromPatternError2Mapexlib://resources/StandardApexLibrary/ConnectApi/ShiftsFromPatternError.cls8�
!connectapi.shiftsfrompatterninputShiftsFromPatternInput
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/ShiftsFromPatternInput.cls#ConnectApi.ShiftsFromPatternInput2Mapexlib://resources/StandardApexLibrary/ConnectApi/ShiftsFromPatternInput.cls8�
-connectapi.shippingcarrierinputrepresentation"ShippingCarrierInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ShippingCarrierInputRepresentation.cls#ConnectApi.ShippingCarrierInputRepresentation2Yapexlib://resources/StandardApexLibrary/ConnectApi/ShippingCarrierInputRepresentation.cls8�
3connectapi.shippingcarriermethodinputrepresentation(ShippingCarrierMethodInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/ShippingCarrierMethodInputRepresentation.cls#ConnectApi.ShippingCarrierMethodInputRepresentation2_apexlib://resources/StandardApexLibrary/ConnectApi/ShippingCarrierMethodInputRepresentation.cls8�
connectapi.sitesearchitemSiteSearchItem
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/SiteSearchItem.cls#ConnectApi.SiteSearchItem2Eapexlib://resources/StandardApexLibrary/ConnectApi/SiteSearchItem.cls8�
connectapi.sitesearchresultSiteSearchResult
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/SiteSearchResult.cls#ConnectApi.SiteSearchResult2Gapexlib://resources/StandardApexLibrary/ConnectApi/SiteSearchResult.cls8�
connectapi.sitesSites
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Sites.cls#ConnectApi.Sites2<apexlib://resources/StandardApexLibrary/ConnectApi/Sites.cls8�
connectapi.sitespagetypeenumSitesPageTypeEnum
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/SitesPageTypeEnum.cls#ConnectApi.SitesPageTypeEnum2Hapexlib://resources/StandardApexLibrary/ConnectApi/SitesPageTypeEnum.cls8�
connectapi.smartdatadiscoverySmartDataDiscovery
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/Smartdatadiscovery.cls#ConnectApi.SmartDataDiscovery2Iapexlib://resources/StandardApexLibrary/ConnectApi/Smartdatadiscovery.cls8�
connectapi.socialaccountSocialAccount
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/SocialAccount.cls#ConnectApi.SocialAccount2Dapexlib://resources/StandardApexLibrary/ConnectApi/SocialAccount.cls8�
$connectapi.socialaccountrelationshipSocialAccountRelationship
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/SocialAccountRelationship.cls#ConnectApi.SocialAccountRelationship2Papexlib://resources/StandardApexLibrary/ConnectApi/SocialAccountRelationship.cls8�
connectapi.socialengagementSocialEngagement
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/SocialEngagement.cls#ConnectApi.SocialEngagement2Gapexlib://resources/StandardApexLibrary/ConnectApi/SocialEngagement.cls8�
$connectapi.socialnetworkproviderenumSocialNetworkProviderEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/SocialNetworkProviderEnum.cls#ConnectApi.SocialNetworkProviderEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/SocialNetworkProviderEnum.cls8�
connectapi.socialpostcapabilitySocialPostCapability
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostCapability.cls#ConnectApi.SocialPostCapability2Kapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostCapability.cls8�
connectapi.socialpostintentsSocialPostIntents
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostIntents.cls#ConnectApi.SocialPostIntents2Hapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostIntents.cls8�
&connectapi.socialpostmassapprovalinputSocialPostMassApprovalInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostMassApprovalInput.cls#ConnectApi.SocialPostMassApprovalInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostMassApprovalInput.cls8�
'connectapi.socialpostmassapprovaloutputSocialPostMassApprovalOutput
ConnectApi *{apexlib://resources/StandardApexLibrary/ConnectApi/SocialPostMassApprovalOutput.cls#ConnectApi.SocialPostMassApprovalOutput2Sapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostMassApprovalOutput.cls8�
$connectapi.socialpostmessagetypeenumSocialPostMessageTypeEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostMessageTypeEnum.cls#ConnectApi.SocialPostMessageTypeEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/SocialPostMessageTypeEnum.cls8�
connectapi.socialpoststatusSocialPostStatus
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/SocialPostStatus.cls#ConnectApi.SocialPostStatus2Gapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostStatus.cls8�
#connectapi.socialpoststatustypeenumSocialPostStatusTypeEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostStatusTypeEnum.cls#ConnectApi.SocialPostStatusTypeEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/SocialPostStatusTypeEnum.cls8�
%connectapi.socialstatusrepresentationSocialStatusRepresentation
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/SocialStatusRepresentation.cls#ConnectApi.SocialStatusRepresentation2Qapexlib://resources/StandardApexLibrary/ConnectApi/SocialStatusRepresentation.cls8�
connectapi.sortorderenumSortOrderEnum
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/SortOrderEnum.cls#ConnectApi.SortOrderEnum2Dapexlib://resources/StandardApexLibrary/ConnectApi/SortOrderEnum.cls8�
connectapi.sortruleSortRule
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/SortRule.cls#ConnectApi.SortRule2?apexlib://resources/StandardApexLibrary/ConnectApi/SortRule.cls8�
connectapi.sortrulescollectionSortRulesCollection
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/SortRulesCollection.cls#ConnectApi.SortRulesCollection2Japexlib://resources/StandardApexLibrary/ConnectApi/SortRulesCollection.cls8�
connectapi.spellcorrectioninfoSpellCorrectionInfo
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/SpellCorrectionInfo.cls#ConnectApi.SpellCorrectionInfo2Japexlib://resources/StandardApexLibrary/ConnectApi/SpellCorrectionInfo.cls8�
connectapi.stampStamp
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Stamp.cls#ConnectApi.Stamp2<apexlib://resources/StandardApexLibrary/ConnectApi/Stamp.cls8�
%connectapi.standardentryclasscodeenumStandardEntryClassCodeEnum
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/StandardEntryClassCodeEnum.cls#ConnectApi.StandardEntryClassCodeEnum2Qapexlib://resources/StandardApexLibrary/ConnectApi/StandardEntryClassCodeEnum.cls8�
connectapi.staticdata
StaticData
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/StaticData.cls#ConnectApi.StaticData2Aapexlib://resources/StandardApexLibrary/ConnectApi/StaticData.cls8�
connectapi.staticdataconfigStaticDataConfig
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/StaticDataConfig.cls#ConnectApi.StaticDataConfig2Gapexlib://resources/StandardApexLibrary/ConnectApi/StaticDataConfig.cls8�
connectapi.staticdatainputStaticDataInput
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/StaticDataInput.cls#ConnectApi.StaticDataInput2Fapexlib://resources/StandardApexLibrary/ConnectApi/StaticDataInput.cls8�
connectapi.statuscapabilityStatusCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/StatusCapability.cls#ConnectApi.StatusCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/StatusCapability.cls8�
 connectapi.statuscapabilityinputStatusCapabilityInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/StatusCapabilityInput.cls#ConnectApi.StatusCapabilityInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/StatusCapabilityInput.cls8�
connectapi.strategytraceStrategyTrace
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/StrategyTrace.cls#ConnectApi.StrategyTrace2Dapexlib://resources/StandardApexLibrary/ConnectApi/StrategyTrace.cls8�
connectapi.strategytracenodeStrategyTraceNode
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/StrategyTraceNode.cls#ConnectApi.StrategyTraceNode2Hapexlib://resources/StandardApexLibrary/ConnectApi/StrategyTraceNode.cls8�
"connectapi.streamsubscriptioninputStreamSubscriptionInput
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/StreamSubscriptionInput.cls#ConnectApi.StreamSubscriptionInput2Napexlib://resources/StandardApexLibrary/ConnectApi/StreamSubscriptionInput.cls8�
connectapi.stringlist
StringList
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/StringList.cls#ConnectApi.StringList2Aapexlib://resources/StandardApexLibrary/ConnectApi/StringList.cls8�
+connectapi.submitcanceloutputrepresentation SubmitCancelOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/SubmitCancelOutputRepresentation.cls#ConnectApi.SubmitCancelOutputRepresentation2Wapexlib://resources/StandardApexLibrary/ConnectApi/SubmitCancelOutputRepresentation.cls8�
7connectapi.submitcarttoexchangeorderinputrepresentation,SubmitCartToExchangeOrderInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/SubmitCartToExchangeOrderInputRepresentation.cls#ConnectApi.SubmitCartToExchangeOrderInputRepresentation2capexlib://resources/StandardApexLibrary/ConnectApi/SubmitCartToExchangeOrderInputRepresentation.cls8�
8connectapi.submitcarttoexchangeorderoutputrepresentation-SubmitCartToExchangeOrderOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/SubmitCartToExchangeOrderOutputRepresentation.cls#ConnectApi.SubmitCartToExchangeOrderOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/SubmitCartToExchangeOrderOutputRepresentation.cls8�
+connectapi.submitreturnoutputrepresentation SubmitReturnOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/SubmitReturnOutputRepresentation.cls#ConnectApi.SubmitReturnOutputRepresentation2Wapexlib://resources/StandardApexLibrary/ConnectApi/SubmitReturnOutputRepresentation.cls8�
connectapi.subscriptionSubscription
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/Subscription.cls#ConnectApi.Subscription2Capexlib://resources/StandardApexLibrary/ConnectApi/Subscription.cls8�
connectapi.subscriptiontermruleSubscriptionTermRule
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/SubscriptionTermRule.cls#ConnectApi.SubscriptionTermRule2Kapexlib://resources/StandardApexLibrary/ConnectApi/SubscriptionTermRule.cls8�
connectapi.supportedemojisSupportedEmojis
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/SupportedEmojis.cls#ConnectApi.SupportedEmojis2Fapexlib://resources/StandardApexLibrary/ConnectApi/SupportedEmojis.cls8�
 connectapi.surveyemailstatusenumSurveyEmailStatusEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/SurveyEmailStatusEnum.cls#ConnectApi.SurveyEmailStatusEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/SurveyEmailStatusEnum.cls8�
%connectapi.surveyinvitationemailinputSurveyInvitationEmailInput
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/SurveyInvitationEmailInput.cls#ConnectApi.SurveyInvitationEmailInput2Qapexlib://resources/StandardApexLibrary/ConnectApi/SurveyInvitationEmailInput.cls8�
&connectapi.surveyinvitationemailoutputSurveyInvitationEmailOutput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/SurveyInvitationEmailOutput.cls#ConnectApi.SurveyInvitationEmailOutput2Rapexlib://resources/StandardApexLibrary/ConnectApi/SurveyInvitationEmailOutput.cls8�
connectapi.surveysSurveys
ConnectApi *Qapexlib://resources/StandardApexLibrary/ConnectApi/Surveys.cls#ConnectApi.Surveys2>apexlib://resources/StandardApexLibrary/ConnectApi/Surveys.cls8�
 connectapi.swatchdisplaytypeenumSwatchDisplayTypeEnum
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/SwatchDisplayTypeEnum.cls#ConnectApi.SwatchDisplayTypeEnum2Lapexlib://resources/StandardApexLibrary/ConnectApi/SwatchDisplayTypeEnum.cls8�
connectapi.targetTarget
ConnectApi *Oapexlib://resources/StandardApexLibrary/ConnectApi/Target.cls#ConnectApi.Target2=apexlib://resources/StandardApexLibrary/ConnectApi/Target.cls8�
connectapi.targetcollectionTargetCollection
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/TargetCollection.cls#ConnectApi.TargetCollection2Gapexlib://resources/StandardApexLibrary/ConnectApi/TargetCollection.cls8�
 connectapi.targetcollectioninputTargetCollectionInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/TargetCollectionInput.cls#ConnectApi.TargetCollectionInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/TargetCollectionInput.cls8�
&connectapi.targetcollectionupdateinputTargetCollectionUpdateInput
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/TargetCollectionUpdateInput.cls#ConnectApi.TargetCollectionUpdateInput2Rapexlib://resources/StandardApexLibrary/ConnectApi/TargetCollectionUpdateInput.cls8�
connectapi.targetinputTargetInput
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/TargetInput.cls#ConnectApi.TargetInput2Bapexlib://resources/StandardApexLibrary/ConnectApi/TargetInput.cls8�
,connectapi.targetlocationinputrepresentation!TargetLocationInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/TargetLocationInputRepresentation.cls#ConnectApi.TargetLocationInputRepresentation2Xapexlib://resources/StandardApexLibrary/ConnectApi/TargetLocationInputRepresentation.cls8�
connectapi.targetupdateinputTargetUpdateInput
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/TargetUpdateInput.cls#ConnectApi.TargetUpdateInput2Hapexlib://resources/StandardApexLibrary/ConnectApi/TargetUpdateInput.cls8�
connectapi.taxaddressrequestTaxAddressRequest
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressRequest.cls#ConnectApi.TaxAddressRequest2Hapexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressRequest.cls8�
connectapi.taxaddressresponseTaxAddressResponse
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressResponse.cls#ConnectApi.TaxAddressResponse2Iapexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressResponse.cls8�
connectapi.taxaddressesrequestTaxAddressesRequest
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressesRequest.cls#ConnectApi.TaxAddressesRequest2Japexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressesRequest.cls8�
connectapi.taxaddressesresponseTaxAddressesResponse
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressesResponse.cls#ConnectApi.TaxAddressesResponse2Kapexlib://resources/StandardApexLibrary/ConnectApi/TaxAddressesResponse.cls8�
#connectapi.taxamountdetailsresponseTaxAmountDetailsResponse
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/TaxAmountDetailsResponse.cls#ConnectApi.TaxAmountDetailsResponse2Oapexlib://resources/StandardApexLibrary/ConnectApi/TaxAmountDetailsResponse.cls8�
$connectapi.taxcustomerdetailsrequestTaxCustomerDetailsRequest
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/TaxCustomerDetailsRequest.cls#ConnectApi.TaxCustomerDetailsRequest2Papexlib://resources/StandardApexLibrary/ConnectApi/TaxCustomerDetailsRequest.cls8�
connectapi.taxdetailsresponseTaxDetailsResponse
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/TaxDetailsResponse.cls#ConnectApi.TaxDetailsResponse2Iapexlib://resources/StandardApexLibrary/ConnectApi/TaxDetailsResponse.cls8�
connectapi.taxenginelogresponseTaxEngineLogResponse
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/TaxEngineLogResponse.cls#ConnectApi.TaxEngineLogResponse2Kapexlib://resources/StandardApexLibrary/ConnectApi/TaxEngineLogResponse.cls8�
 connectapi.taximpositionresponseTaxImpositionResponse
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/TaxImpositionResponse.cls#ConnectApi.TaxImpositionResponse2Lapexlib://resources/StandardApexLibrary/ConnectApi/TaxImpositionResponse.cls8�
"connectapi.taxjurisdictionresponseTaxJurisdictionResponse
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/TaxJurisdictionResponse.cls#ConnectApi.TaxJurisdictionResponse2Napexlib://resources/StandardApexLibrary/ConnectApi/TaxJurisdictionResponse.cls8�
connectapi.taxlineitemrequestTaxLineItemRequest
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/TaxLineItemRequest.cls#ConnectApi.TaxLineItemRequest2Iapexlib://resources/StandardApexLibrary/ConnectApi/TaxLineItemRequest.cls8�
connectapi.taxplatformTaxPlatform
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/TaxPlatform.cls#ConnectApi.TaxPlatform2Bapexlib://resources/StandardApexLibrary/ConnectApi/TaxPlatform.cls8�
 connectapi.taxtransactionrequestTaxTransactionRequest
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionRequest.cls#ConnectApi.TaxTransactionRequest2Lapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionRequest.cls8�
!connectapi.taxtransactionresponseTaxTransactionResponse
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionResponse.cls#ConnectApi.TaxTransactionResponse2Mapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionResponse.cls8�
#connectapi.taxtransactionstatusenumTaxTransactionStatusEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionStatusEnum.cls#ConnectApi.TaxTransactionStatusEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionStatusEnum.cls8�
!connectapi.taxtransactiontypeenumTaxTransactionTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionTypeEnum.cls#ConnectApi.TaxTransactionTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/TaxTransactionTypeEnum.cls8�
=connectapi.textclassificationsbulkresultsoutputrepresentation2TextClassificationsBulkResultsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsBulkResultsOutputRepresentation.cls#ConnectApi.TextClassificationsBulkResultsOutputRepresentation2iapexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsBulkResultsOutputRepresentation.cls8�
1connectapi.textclassificationsinputrepresentation&TextClassificationsInputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsInputRepresentation.cls#ConnectApi.TextClassificationsInputRepresentation2]apexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsInputRepresentation.cls8�
2connectapi.textclassificationsoutputrepresentation'TextClassificationsOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsOutputRepresentation.cls#ConnectApi.TextClassificationsOutputRepresentation2^apexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsOutputRepresentation.cls8�
8connectapi.textclassificationsresultoutputrepresentation-TextClassificationsResultOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsResultOutputRepresentation.cls#ConnectApi.TextClassificationsResultOutputRepresentation2dapexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsResultOutputRepresentation.cls8�
>connectapi.textclassificationsresultwithidoutputrepresentation3TextClassificationsResultWithIdOutputRepresentation
ConnectApi *�apexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsResultWithIdOutputRepresentation.cls#ConnectApi.TextClassificationsResultWithIdOutputRepresentation2japexlib://resources/StandardApexLibrary/ConnectApi/TextClassificationsResultWithIdOutputRepresentation.cls8�
connectapi.textsegmentTextSegment
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/TextSegment.cls#ConnectApi.TextSegment2Bapexlib://resources/StandardApexLibrary/ConnectApi/TextSegment.cls8�
connectapi.textsegmentinputTextSegmentInput
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/TextSegmentInput.cls#ConnectApi.TextSegmentInput2Gapexlib://resources/StandardApexLibrary/ConnectApi/TextSegmentInput.cls8�
connectapi.themeinfo	ThemeInfo
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/ThemeInfo.cls#ConnectApi.ThemeInfo2@apexlib://resources/StandardApexLibrary/ConnectApi/ThemeInfo.cls8�
connectapi.timezoneTimeZone
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/TimeZone.cls#ConnectApi.TimeZone2?apexlib://resources/StandardApexLibrary/ConnectApi/TimeZone.cls8�
connectapi.topicTopic
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Topic.cls#ConnectApi.Topic2<apexlib://resources/StandardApexLibrary/ConnectApi/Topic.cls8�
connectapi.topicendorsementTopicEndorsement
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/TopicEndorsement.cls#ConnectApi.TopicEndorsement2Gapexlib://resources/StandardApexLibrary/ConnectApi/TopicEndorsement.cls8�
%connectapi.topicendorsementcollectionTopicEndorsementCollection
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/TopicEndorsementCollection.cls#ConnectApi.TopicEndorsementCollection2Qapexlib://resources/StandardApexLibrary/ConnectApi/TopicEndorsementCollection.cls8�
"connectapi.topicendorsementsummaryTopicEndorsementSummary
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/TopicEndorsementSummary.cls#ConnectApi.TopicEndorsementSummary2Napexlib://resources/StandardApexLibrary/ConnectApi/TopicEndorsementSummary.cls8�
connectapi.topicimagesTopicImages
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/TopicImages.cls#ConnectApi.TopicImages2Bapexlib://resources/StandardApexLibrary/ConnectApi/TopicImages.cls8�
connectapi.topicinput
TopicInput
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/TopicInput.cls#ConnectApi.TopicInput2Aapexlib://resources/StandardApexLibrary/ConnectApi/TopicInput.cls8�
connectapi.topicnamesinputTopicNamesInput
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/TopicNamesInput.cls#ConnectApi.TopicNamesInput2Fapexlib://resources/StandardApexLibrary/ConnectApi/TopicNamesInput.cls8�
connectapi.topicpage	TopicPage
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/TopicPage.cls#ConnectApi.TopicPage2@apexlib://resources/StandardApexLibrary/ConnectApi/TopicPage.cls8�
connectapi.topicsortenumTopicSortEnum
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/TopicSortEnum.cls#ConnectApi.TopicSortEnum2Dapexlib://resources/StandardApexLibrary/ConnectApi/TopicSortEnum.cls8�
connectapi.topicsuggestionTopicSuggestion
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/TopicSuggestion.cls#ConnectApi.TopicSuggestion2Fapexlib://resources/StandardApexLibrary/ConnectApi/TopicSuggestion.cls8�
connectapi.topicsuggestionpageTopicSuggestionPage
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/TopicSuggestionPage.cls#ConnectApi.TopicSuggestionPage2Japexlib://resources/StandardApexLibrary/ConnectApi/TopicSuggestionPage.cls8�
connectapi.topicsummaryTopicSummary
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/TopicSummary.cls#ConnectApi.TopicSummary2Capexlib://resources/StandardApexLibrary/ConnectApi/TopicSummary.cls8�
connectapi.topicsTopics
ConnectApi *Oapexlib://resources/StandardApexLibrary/ConnectApi/Topics.cls#ConnectApi.Topics2=apexlib://resources/StandardApexLibrary/ConnectApi/Topics.cls8�
connectapi.topicscapabilityTopicsCapability
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/TopicsCapability.cls#ConnectApi.TopicsCapability2Gapexlib://resources/StandardApexLibrary/ConnectApi/TopicsCapability.cls8�
 connectapi.topicscapabilityinputTopicsCapabilityInput
ConnectApi *mapexlib://resources/StandardApexLibrary/ConnectApi/TopicsCapabilityInput.cls#ConnectApi.TopicsCapabilityInput2Lapexlib://resources/StandardApexLibrary/ConnectApi/TopicsCapabilityInput.cls8�
"connectapi.trackedchangeattachmentTrackedChangeAttachment
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangeAttachment.cls#ConnectApi.TrackedChangeAttachment2Napexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangeAttachment.cls8�
(connectapi.trackedchangebundlecapabilityTrackedChangeBundleCapability
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangeBundleCapability.cls#ConnectApi.TrackedChangeBundleCapability2Tapexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangeBundleCapability.cls8�
connectapi.trackedchangeitemTrackedChangeItem
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangeItem.cls#ConnectApi.TrackedChangeItem2Hapexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangeItem.cls8�
#connectapi.trackedchangescapabilityTrackedChangesCapability
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangesCapability.cls#ConnectApi.TrackedChangesCapability2Oapexlib://resources/StandardApexLibrary/ConnectApi/TrackedChangesCapability.cls8�
connectapi.typeandfilterTypeAndFilter
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/TypeAndFilter.cls#ConnectApi.TypeAndFilter2Dapexlib://resources/StandardApexLibrary/ConnectApi/TypeAndFilter.cls8�
connectapi.typeandfilterinputTypeAndFilterInput
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/TypeAndFilterInput.cls#ConnectApi.TypeAndFilterInput2Iapexlib://resources/StandardApexLibrary/ConnectApi/TypeAndFilterInput.cls8�
connectapi.typeenumTypeEnum
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/TypeEnum.cls#ConnectApi.TypeEnum2?apexlib://resources/StandardApexLibrary/ConnectApi/TypeEnum.cls8�
connectapi.unauthenticateduserUnauthenticatedUser
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/UnauthenticatedUser.cls#ConnectApi.UnauthenticatedUser2Japexlib://resources/StandardApexLibrary/ConnectApi/UnauthenticatedUser.cls8�
"connectapi.unreadconversationcountUnreadConversationCount
ConnectApi *qapexlib://resources/StandardApexLibrary/ConnectApi/UnreadConversationCount.cls#ConnectApi.UnreadConversationCount2Napexlib://resources/StandardApexLibrary/ConnectApi/UnreadConversationCount.cls8�
connectapi.updownvotecapabilityUpDownVoteCapability
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/UpDownVoteCapability.cls#ConnectApi.UpDownVoteCapability2Kapexlib://resources/StandardApexLibrary/ConnectApi/UpDownVoteCapability.cls8�
$connectapi.updownvotecapabilityinputUpDownVoteCapabilityInput
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/UpDownVoteCapabilityInput.cls#ConnectApi.UpDownVoteCapabilityInput2Papexlib://resources/StandardApexLibrary/ConnectApi/UpDownVoteCapabilityInput.cls8�
connectapi.updownvoteenumUpDownVoteEnum
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/UpDownVoteEnum.cls#ConnectApi.UpDownVoteEnum2Eapexlib://resources/StandardApexLibrary/ConnectApi/UpDownVoteEnum.cls8�
connectapi.upvotesummaryUpVoteSummary
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/UpVoteSummary.cls#ConnectApi.UpVoteSummary2Dapexlib://resources/StandardApexLibrary/ConnectApi/UpVoteSummary.cls8�
(connectapi.updateserviceappointmentinputUpdateServiceAppointmentInput
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/UpdateServiceAppointmentInput.cls#ConnectApi.UpdateServiceAppointmentInput2Tapexlib://resources/StandardApexLibrary/ConnectApi/UpdateServiceAppointmentInput.cls8�
connectapi.userUser
ConnectApi *Kapexlib://resources/StandardApexLibrary/ConnectApi/User.cls#ConnectApi.User2;apexlib://resources/StandardApexLibrary/ConnectApi/User.cls8�
connectapi.useractivitiesjobUserActivitiesJob
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/UserActivitiesJob.cls#ConnectApi.UserActivitiesJob2Hapexlib://resources/StandardApexLibrary/ConnectApi/UserActivitiesJob.cls8�
!connectapi.useractivitycollectionUserActivityCollection
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/UserActivityCollection.cls#ConnectApi.UserActivityCollection2Mapexlib://resources/StandardApexLibrary/ConnectApi/UserActivityCollection.cls8�
connectapi.useractivitysummaryUserActivitySummary
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/UserActivitySummary.cls#ConnectApi.UserActivitySummary2Japexlib://resources/StandardApexLibrary/ConnectApi/UserActivitySummary.cls8�
connectapi.useractivitytypeenumUserActivityTypeEnum
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/UserActivityTypeEnum.cls#ConnectApi.UserActivityTypeEnum2Kapexlib://resources/StandardApexLibrary/ConnectApi/UserActivityTypeEnum.cls8�
connectapi.usercapabilitiesUserCapabilities
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/UserCapabilities.cls#ConnectApi.UserCapabilities2Gapexlib://resources/StandardApexLibrary/ConnectApi/UserCapabilities.cls8�
connectapi.userchattersettingsUserChatterSettings
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/UserChatterSettings.cls#ConnectApi.UserChatterSettings2Japexlib://resources/StandardApexLibrary/ConnectApi/UserChatterSettings.cls8�
connectapi.userdetail
UserDetail
ConnectApi *Wapexlib://resources/StandardApexLibrary/ConnectApi/UserDetail.cls#ConnectApi.UserDetail2Aapexlib://resources/StandardApexLibrary/ConnectApi/UserDetail.cls8�
(connectapi.userfeedentityactivitysummaryUserFeedEntityActivitySummary
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/UserFeedEntityActivitySummary.cls#ConnectApi.UserFeedEntityActivitySummary2Tapexlib://resources/StandardApexLibrary/ConnectApi/UserFeedEntityActivitySummary.cls8�
connectapi.usergroupdetailpageUserGroupDetailPage
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/UserGroupDetailPage.cls#ConnectApi.UserGroupDetailPage2Japexlib://resources/StandardApexLibrary/ConnectApi/UserGroupDetailPage.cls8�
connectapi.usergrouppageUserGroupPage
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/UserGroupPage.cls#ConnectApi.UserGroupPage2Dapexlib://resources/StandardApexLibrary/ConnectApi/UserGroupPage.cls8�
connectapi.userinput	UserInput
ConnectApi *Uapexlib://resources/StandardApexLibrary/ConnectApi/UserInput.cls#ConnectApi.UserInput2@apexlib://resources/StandardApexLibrary/ConnectApi/UserInput.cls8�
connectapi.usermissionUserMission
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/UserMission.cls#ConnectApi.UserMission2Bapexlib://resources/StandardApexLibrary/ConnectApi/UserMission.cls8�
#connectapi.usermissionactivitiesjobUserMissionActivitiesJob
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivitiesJob.cls#ConnectApi.UserMissionActivitiesJob2Oapexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivitiesJob.cls8�
connectapi.usermissionactivityUserMissionActivity
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivity.cls#ConnectApi.UserMissionActivity2Japexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivity.cls8�
(connectapi.usermissionactivitycollectionUserMissionActivityCollection
ConnectApi *}apexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivityCollection.cls#ConnectApi.UserMissionActivityCollection2Tapexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivityCollection.cls8�
$connectapi.usermissionactivitystatusUserMissionActivityStatus
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivityStatus.cls#ConnectApi.UserMissionActivityStatus2Papexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivityStatus.cls8�
&connectapi.usermissionactivitytypeenumUserMissionActivityTypeEnum
ConnectApi *yapexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivityTypeEnum.cls#ConnectApi.UserMissionActivityTypeEnum2Rapexlib://resources/StandardApexLibrary/ConnectApi/UserMissionActivityTypeEnum.cls8�
connectapi.useroauthinfoUserOauthInfo
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/UserOauthInfo.cls#ConnectApi.UserOauthInfo2Dapexlib://resources/StandardApexLibrary/ConnectApi/UserOauthInfo.cls8�
connectapi.userpageUserPage
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/UserPage.cls#ConnectApi.UserPage2?apexlib://resources/StandardApexLibrary/ConnectApi/UserPage.cls8�
connectapi.userprofileUserProfile
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/UserProfile.cls#ConnectApi.UserProfile2Bapexlib://resources/StandardApexLibrary/ConnectApi/UserProfile.cls8�
connectapi.userprofiletabUserProfileTab
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/UserProfileTab.cls#ConnectApi.UserProfileTab2Eapexlib://resources/StandardApexLibrary/ConnectApi/UserProfileTab.cls8�
!connectapi.userprofiletabtypeenumUserProfileTabTypeEnum
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/UserProfileTabTypeEnum.cls#ConnectApi.UserProfileTabTypeEnum2Mapexlib://resources/StandardApexLibrary/ConnectApi/UserProfileTabTypeEnum.cls8�
connectapi.userprofilesUserProfiles
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/UserProfiles.cls#ConnectApi.UserProfiles2Capexlib://resources/StandardApexLibrary/ConnectApi/UserProfiles.cls8�
connectapi.userreferencepageUserReferencePage
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/UserReferencePage.cls#ConnectApi.UserReferencePage2Hapexlib://resources/StandardApexLibrary/ConnectApi/UserReferencePage.cls8�
connectapi.usersettingsUserSettings
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/UserSettings.cls#ConnectApi.UserSettings2Capexlib://resources/StandardApexLibrary/ConnectApi/UserSettings.cls8�
connectapi.usersummaryUserSummary
ConnectApi *Yapexlib://resources/StandardApexLibrary/ConnectApi/UserSummary.cls#ConnectApi.UserSummary2Bapexlib://resources/StandardApexLibrary/ConnectApi/UserSummary.cls8�
connectapi.usertypeenumUserTypeEnum
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/UserTypeEnum.cls#ConnectApi.UserTypeEnum2Capexlib://resources/StandardApexLibrary/ConnectApi/UserTypeEnum.cls8�
connectapi.verifiedcapabilityVerifiedCapability
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/VerifiedCapability.cls#ConnectApi.VerifiedCapability2Iapexlib://resources/StandardApexLibrary/ConnectApi/VerifiedCapability.cls8�
connectapi.voteVote
ConnectApi *Kapexlib://resources/StandardApexLibrary/ConnectApi/Vote.cls#ConnectApi.Vote2;apexlib://resources/StandardApexLibrary/ConnectApi/Vote.cls8�
connectapi.votepageVotePage
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/VotePage.cls#ConnectApi.VotePage2?apexlib://resources/StandardApexLibrary/ConnectApi/VotePage.cls8�
connectapi.webstoremetaconfigWebStoreMetaConfig
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/WebStoreMetaConfig.cls#ConnectApi.WebStoreMetaConfig2Iapexlib://resources/StandardApexLibrary/ConnectApi/WebStoreMetaConfig.cls8�
%connectapi.webstoremetaconfigurationsWebStoreMetaConfigurations
ConnectApi *wapexlib://resources/StandardApexLibrary/ConnectApi/WebStoreMetaConfigurations.cls#ConnectApi.WebStoreMetaConfigurations2Qapexlib://resources/StandardApexLibrary/ConnectApi/WebStoreMetaConfigurations.cls8�
connectapi.wishlistWishlist
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/Wishlist.cls#ConnectApi.Wishlist2?apexlib://resources/StandardApexLibrary/ConnectApi/Wishlist.cls8�
connectapi.wishlistinputWishlistInput
ConnectApi *]apexlib://resources/StandardApexLibrary/ConnectApi/WishlistInput.cls#ConnectApi.WishlistInput2Dapexlib://resources/StandardApexLibrary/ConnectApi/WishlistInput.cls8�
connectapi.wishlistitemWishlistItem
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/WishlistItem.cls#ConnectApi.WishlistItem2Capexlib://resources/StandardApexLibrary/ConnectApi/WishlistItem.cls8�
!connectapi.wishlistitemcollectionWishlistItemCollection
ConnectApi *oapexlib://resources/StandardApexLibrary/ConnectApi/WishlistItemCollection.cls#ConnectApi.WishlistItemCollection2Mapexlib://resources/StandardApexLibrary/ConnectApi/WishlistItemCollection.cls8�
connectapi.wishlistiteminputWishlistItemInput
ConnectApi *eapexlib://resources/StandardApexLibrary/ConnectApi/WishlistItemInput.cls#ConnectApi.WishlistItemInput2Hapexlib://resources/StandardApexLibrary/ConnectApi/WishlistItemInput.cls8�
$connectapi.wishlistitemsortorderenumWishlistItemSortOrderEnum
ConnectApi *uapexlib://resources/StandardApexLibrary/ConnectApi/WishlistItemSortOrderEnum.cls#ConnectApi.WishlistItemSortOrderEnum2Papexlib://resources/StandardApexLibrary/ConnectApi/WishlistItemSortOrderEnum.cls8�
connectapi.wishlistsummaryWishlistSummary
ConnectApi *aapexlib://resources/StandardApexLibrary/ConnectApi/WishlistSummary.cls#ConnectApi.WishlistSummary2Fapexlib://resources/StandardApexLibrary/ConnectApi/WishlistSummary.cls8�
connectapi.wishlisttocartresultWishlistToCartResult
ConnectApi *kapexlib://resources/StandardApexLibrary/ConnectApi/WishlistToCartResult.cls#ConnectApi.WishlistToCartResult2Kapexlib://resources/StandardApexLibrary/ConnectApi/WishlistToCartResult.cls8�
connectapi.wishlistupdateinputWishlistUpdateInput
ConnectApi *iapexlib://resources/StandardApexLibrary/ConnectApi/WishlistUpdateInput.cls#ConnectApi.WishlistUpdateInput2Japexlib://resources/StandardApexLibrary/ConnectApi/WishlistUpdateInput.cls8�
connectapi.wishlistssummaryWishlistsSummary
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/WishlistsSummary.cls#ConnectApi.WishlistsSummary2Gapexlib://resources/StandardApexLibrary/ConnectApi/WishlistsSummary.cls8�
)connectapi.worksteppicklistvalueattributeWorkStepPicklistValueAttribute
ConnectApi *apexlib://resources/StandardApexLibrary/ConnectApi/WorkStepPicklistValueAttribute.cls#ConnectApi.WorkStepPicklistValueAttribute2Uapexlib://resources/StandardApexLibrary/ConnectApi/WorkStepPicklistValueAttribute.cls8�
connectapi.workflowstatusenumWorkflowStatusEnum
ConnectApi *gapexlib://resources/StandardApexLibrary/ConnectApi/WorkflowStatusEnum.cls#ConnectApi.WorkflowStatusEnum2Iapexlib://resources/StandardApexLibrary/ConnectApi/WorkflowStatusEnum.cls8�
connectapi.wrappedmapobjectWrappedMapObject
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/WrappedMapObject.cls#ConnectApi.WrappedMapObject2Gapexlib://resources/StandardApexLibrary/ConnectApi/WrappedMapObject.cls8�
connectapi.wrappedvalueWrappedValue
ConnectApi *[apexlib://resources/StandardApexLibrary/ConnectApi/WrappedValue.cls#ConnectApi.WrappedValue2Capexlib://resources/StandardApexLibrary/ConnectApi/WrappedValue.cls8�
connectapi.zoneZone
ConnectApi *Kapexlib://resources/StandardApexLibrary/ConnectApi/Zone.cls#ConnectApi.Zone2;apexlib://resources/StandardApexLibrary/ConnectApi/Zone.cls8�
connectapi.zonepageZonePage
ConnectApi *Sapexlib://resources/StandardApexLibrary/ConnectApi/ZonePage.cls#ConnectApi.ZonePage2?apexlib://resources/StandardApexLibrary/ConnectApi/ZonePage.cls8�
connectapi.zonesearchpageZoneSearchPage
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ZoneSearchPage.cls#ConnectApi.ZoneSearchPage2Eapexlib://resources/StandardApexLibrary/ConnectApi/ZoneSearchPage.cls8�
connectapi.zonesearchresultZoneSearchResult
ConnectApi *capexlib://resources/StandardApexLibrary/ConnectApi/ZoneSearchResult.cls#ConnectApi.ZoneSearchResult2Gapexlib://resources/StandardApexLibrary/ConnectApi/ZoneSearchResult.cls8�
#connectapi.zonesearchresulttypeenumZoneSearchResultTypeEnum
ConnectApi *sapexlib://resources/StandardApexLibrary/ConnectApi/ZoneSearchResultTypeEnum.cls#ConnectApi.ZoneSearchResultTypeEnum2Oapexlib://resources/StandardApexLibrary/ConnectApi/ZoneSearchResultTypeEnum.cls8�
connectapi.zoneshowinenumZoneShowInEnum
ConnectApi *_apexlib://resources/StandardApexLibrary/ConnectApi/ZoneShowInEnum.cls#ConnectApi.ZoneShowInEnum2Eapexlib://resources/StandardApexLibrary/ConnectApi/ZoneShowInEnum.cls8�
connectapi.zonesZones
ConnectApi *Mapexlib://resources/StandardApexLibrary/ConnectApi/Zones.cls#ConnectApi.Zones2<apexlib://resources/StandardApexLibrary/ConnectApi/Zones.cls8�
datasource.asyncdeletecallbackAsyncDeleteCallback
DataSource *iapexlib://resources/StandardApexLibrary/DataSource/AsyncDeleteCallback.cls#DataSource.AsyncDeleteCallback2Japexlib://resources/StandardApexLibrary/DataSource/AsyncDeleteCallback.cls8�
datasource.asyncsavecallbackAsyncSaveCallback
DataSource *eapexlib://resources/StandardApexLibrary/DataSource/AsyncSaveCallback.cls#DataSource.AsyncSaveCallback2Hapexlib://resources/StandardApexLibrary/DataSource/AsyncSaveCallback.cls8�
#datasource.authenticationcapabilityAuthenticationCapability
DataSource *sapexlib://resources/StandardApexLibrary/DataSource/AuthenticationCapability.cls#DataSource.AuthenticationCapability2Oapexlib://resources/StandardApexLibrary/DataSource/AuthenticationCapability.cls8�
!datasource.authenticationprotocolAuthenticationProtocol
DataSource *oapexlib://resources/StandardApexLibrary/DataSource/AuthenticationProtocol.cls#DataSource.AuthenticationProtocol2Mapexlib://resources/StandardApexLibrary/DataSource/AuthenticationProtocol.cls8�
datasource.capability
Capability
DataSource *Wapexlib://resources/StandardApexLibrary/DataSource/Capability.cls#DataSource.Capability2Aapexlib://resources/StandardApexLibrary/DataSource/Capability.cls8�
datasource.columnColumn
DataSource *Oapexlib://resources/StandardApexLibrary/DataSource/Column.cls#DataSource.Column2=apexlib://resources/StandardApexLibrary/DataSource/Column.cls8�
datasource.columnselectionColumnSelection
DataSource *aapexlib://resources/StandardApexLibrary/DataSource/ColumnSelection.cls#DataSource.ColumnSelection2Fapexlib://resources/StandardApexLibrary/DataSource/ColumnSelection.cls8�
datasource.connection
Connection
DataSource *Wapexlib://resources/StandardApexLibrary/DataSource/Connection.cls#DataSource.Connection2Aapexlib://resources/StandardApexLibrary/DataSource/Connection.cls8�
datasource.connectionparamsConnectionParams
DataSource *capexlib://resources/StandardApexLibrary/DataSource/ConnectionParams.cls#DataSource.ConnectionParams2Gapexlib://resources/StandardApexLibrary/DataSource/ConnectionParams.cls8�
datasource.datasourceexceptionDataSourceException
DataSource *iapexlib://resources/StandardApexLibrary/DataSource/DataSourceException.cls#DataSource.DataSourceException2Japexlib://resources/StandardApexLibrary/DataSource/DataSourceException.cls8�
datasource.datasourceutilDataSourceUtil
DataSource *_apexlib://resources/StandardApexLibrary/DataSource/DataSourceUtil.cls#DataSource.DataSourceUtil2Eapexlib://resources/StandardApexLibrary/DataSource/DataSourceUtil.cls8�
datasource.datatypeDataType
DataSource *Sapexlib://resources/StandardApexLibrary/DataSource/DataType.cls#DataSource.DataType2?apexlib://resources/StandardApexLibrary/DataSource/DataType.cls8�
datasource.deletecontextDeleteContext
DataSource *]apexlib://resources/StandardApexLibrary/DataSource/DeleteContext.cls#DataSource.DeleteContext2Dapexlib://resources/StandardApexLibrary/DataSource/DeleteContext.cls8�
datasource.deleteresultDeleteResult
DataSource *[apexlib://resources/StandardApexLibrary/DataSource/DeleteResult.cls#DataSource.DeleteResult2Capexlib://resources/StandardApexLibrary/DataSource/DeleteResult.cls8�
datasource.filterFilter
DataSource *Oapexlib://resources/StandardApexLibrary/DataSource/Filter.cls#DataSource.Filter2=apexlib://resources/StandardApexLibrary/DataSource/Filter.cls8�
datasource.filtertype
FilterType
DataSource *Wapexlib://resources/StandardApexLibrary/DataSource/FilterType.cls#DataSource.FilterType2Aapexlib://resources/StandardApexLibrary/DataSource/FilterType.cls8�
datasource.identitytypeIdentityType
DataSource *[apexlib://resources/StandardApexLibrary/DataSource/IdentityType.cls#DataSource.IdentityType2Capexlib://resources/StandardApexLibrary/DataSource/IdentityType.cls8�
%datasource.oauthtokenexpiredexceptionOAuthTokenExpiredException
DataSource *wapexlib://resources/StandardApexLibrary/DataSource/OAuthTokenExpiredException.cls#DataSource.OAuthTokenExpiredException2Qapexlib://resources/StandardApexLibrary/DataSource/OAuthTokenExpiredException.cls8�
datasource.orderOrder
DataSource *Mapexlib://resources/StandardApexLibrary/DataSource/Order.cls#DataSource.Order2<apexlib://resources/StandardApexLibrary/DataSource/Order.cls8�
datasource.orderdirectionOrderDirection
DataSource *_apexlib://resources/StandardApexLibrary/DataSource/OrderDirection.cls#DataSource.OrderDirection2Eapexlib://resources/StandardApexLibrary/DataSource/OrderDirection.cls8�
datasource.providerProvider
DataSource *Sapexlib://resources/StandardApexLibrary/DataSource/Provider.cls#DataSource.Provider2?apexlib://resources/StandardApexLibrary/DataSource/Provider.cls8�
datasource.queryaggregationQueryAggregation
DataSource *capexlib://resources/StandardApexLibrary/DataSource/QueryAggregation.cls#DataSource.QueryAggregation2Gapexlib://resources/StandardApexLibrary/DataSource/QueryAggregation.cls8�
datasource.querycontextQueryContext
DataSource *[apexlib://resources/StandardApexLibrary/DataSource/QueryContext.cls#DataSource.QueryContext2Capexlib://resources/StandardApexLibrary/DataSource/QueryContext.cls8�
datasource.queryutils
QueryUtils
DataSource *Wapexlib://resources/StandardApexLibrary/DataSource/QueryUtils.cls#DataSource.QueryUtils2Aapexlib://resources/StandardApexLibrary/DataSource/QueryUtils.cls8�
datasource.readcontextReadContext
DataSource *Yapexlib://resources/StandardApexLibrary/DataSource/ReadContext.cls#DataSource.ReadContext2Bapexlib://resources/StandardApexLibrary/DataSource/ReadContext.cls8�
datasource.searchcontextSearchContext
DataSource *]apexlib://resources/StandardApexLibrary/DataSource/SearchContext.cls#DataSource.SearchContext2Dapexlib://resources/StandardApexLibrary/DataSource/SearchContext.cls8�
datasource.searchutilsSearchUtils
DataSource *Yapexlib://resources/StandardApexLibrary/DataSource/SearchUtils.cls#DataSource.SearchUtils2Bapexlib://resources/StandardApexLibrary/DataSource/SearchUtils.cls8�
datasource.tableTable
DataSource *Mapexlib://resources/StandardApexLibrary/DataSource/Table.cls#DataSource.Table2<apexlib://resources/StandardApexLibrary/DataSource/Table.cls8�
datasource.tableresultTableResult
DataSource *Yapexlib://resources/StandardApexLibrary/DataSource/TableResult.cls#DataSource.TableResult2Bapexlib://resources/StandardApexLibrary/DataSource/TableResult.cls8�
datasource.tableselectionTableSelection
DataSource *_apexlib://resources/StandardApexLibrary/DataSource/TableSelection.cls#DataSource.TableSelection2Eapexlib://resources/StandardApexLibrary/DataSource/TableSelection.cls8�
datasource.upsertcontextUpsertContext
DataSource *]apexlib://resources/StandardApexLibrary/DataSource/UpsertContext.cls#DataSource.UpsertContext2Dapexlib://resources/StandardApexLibrary/DataSource/UpsertContext.cls8�
datasource.upsertresultUpsertResult
DataSource *[apexlib://resources/StandardApexLibrary/DataSource/UpsertResult.cls#DataSource.UpsertResult2Capexlib://resources/StandardApexLibrary/DataSource/UpsertResult.cls8�
dataweave.resultResult	DataWeave *Mapexlib://resources/StandardApexLibrary/DataWeave/Result.cls#DataWeave.Result2<apexlib://resources/StandardApexLibrary/DataWeave/Result.cls8�
dataweave.scriptScript	DataWeave *Mapexlib://resources/StandardApexLibrary/DataWeave/Script.cls#DataWeave.Script2<apexlib://resources/StandardApexLibrary/DataWeave/Script.cls8�
database.assignmentruleheaderAssignmentRuleHeaderDatabase *gapexlib://resources/StandardApexLibrary/Database/AssignmentRuleHeader.cls#Database.AssignmentRuleHeader2Iapexlib://resources/StandardApexLibrary/Database/AssignmentRuleHeader.cls8�
database.batchable	BatchableDatabase *Qapexlib://resources/StandardApexLibrary/Database/Batchable.cls#Database.Batchable2>apexlib://resources/StandardApexLibrary/Database/Batchable.cls8�
database.batchablecontextBatchableContextDatabase *_apexlib://resources/StandardApexLibrary/Database/BatchableContext.cls#Database.BatchableContext2Eapexlib://resources/StandardApexLibrary/Database/BatchableContext.cls8�
database.cursorCursorDatabase *Kapexlib://resources/StandardApexLibrary/Database/Cursor.cls#Database.Cursor2;apexlib://resources/StandardApexLibrary/Database/Cursor.cls8�
database.cursorfetchresultCursorFetchResultDatabase *aapexlib://resources/StandardApexLibrary/Database/CursorFetchResult.cls#Database.CursorFetchResult2Fapexlib://resources/StandardApexLibrary/Database/CursorFetchResult.cls8�
database.dmloptions
DMLOptionsDatabase *Sapexlib://resources/StandardApexLibrary/Database/DMLOptions.cls#Database.DMLOptions2?apexlib://resources/StandardApexLibrary/Database/DMLOptions.cls8�
database.deleteresultDeleteResultDatabase *Wapexlib://resources/StandardApexLibrary/Database/DeleteResult.cls#Database.DeleteResult2Aapexlib://resources/StandardApexLibrary/Database/DeleteResult.cls8�
database.deletedrecordDeletedRecordDatabase *Yapexlib://resources/StandardApexLibrary/Database/DeletedRecord.cls#Database.DeletedRecord2Bapexlib://resources/StandardApexLibrary/Database/DeletedRecord.cls8�
database.duplicateerrorDuplicateErrorDatabase *[apexlib://resources/StandardApexLibrary/Database/DuplicateError.cls#Database.DuplicateError2Capexlib://resources/StandardApexLibrary/Database/DuplicateError.cls8�
database.duplicateruleheaderDuplicateRuleHeaderDatabase *eapexlib://resources/StandardApexLibrary/Database/DuplicateRuleHeader.cls#Database.DuplicateRuleHeader2Hapexlib://resources/StandardApexLibrary/Database/DuplicateRuleHeader.cls8�
database.emailheaderEmailHeaderDatabase *Uapexlib://resources/StandardApexLibrary/Database/EmailHeader.cls#Database.EmailHeader2@apexlib://resources/StandardApexLibrary/Database/EmailHeader.cls8�
database.emptyrecyclebinresultEmptyRecycleBinResultDatabase *iapexlib://resources/StandardApexLibrary/Database/EmptyRecycleBinResult.cls#Database.EmptyRecycleBinResult2Japexlib://resources/StandardApexLibrary/Database/EmptyRecycleBinResult.cls8�
database.errorErrorDatabase *Iapexlib://resources/StandardApexLibrary/Database/Error.cls#Database.Error2:apexlib://resources/StandardApexLibrary/Database/Error.cls8�
database.getdeletedresultGetDeletedResultDatabase *_apexlib://resources/StandardApexLibrary/Database/GetDeletedResult.cls#Database.GetDeletedResult2Eapexlib://resources/StandardApexLibrary/Database/GetDeletedResult.cls8�
database.getupdatedresultGetUpdatedResultDatabase *_apexlib://resources/StandardApexLibrary/Database/GetUpdatedResult.cls#Database.GetUpdatedResult2Eapexlib://resources/StandardApexLibrary/Database/GetUpdatedResult.cls8�
database.leadconvertLeadConvertDatabase *Uapexlib://resources/StandardApexLibrary/Database/LeadConvert.cls#Database.LeadConvert2@apexlib://resources/StandardApexLibrary/Database/LeadConvert.cls8�
database.leadconvertresultLeadConvertResultDatabase *aapexlib://resources/StandardApexLibrary/Database/LeadConvertResult.cls#Database.LeadConvertResult2Fapexlib://resources/StandardApexLibrary/Database/LeadConvertResult.cls8�
database.mergeresultMergeResultDatabase *Uapexlib://resources/StandardApexLibrary/Database/MergeResult.cls#Database.MergeResult2@apexlib://resources/StandardApexLibrary/Database/MergeResult.cls8�
database.paginationcursorPaginationCursorDatabase *_apexlib://resources/StandardApexLibrary/Database/PaginationCursor.cls#Database.PaginationCursor2Eapexlib://resources/StandardApexLibrary/Database/PaginationCursor.cls8�
database.querylocatorQueryLocatorDatabase *Wapexlib://resources/StandardApexLibrary/Database/QueryLocator.cls#Database.QueryLocator2Aapexlib://resources/StandardApexLibrary/Database/QueryLocator.cls8�
database.querylocatoriteratorQueryLocatorIteratorDatabase *gapexlib://resources/StandardApexLibrary/Database/QueryLocatorIterator.cls#Database.QueryLocatorIterator2Iapexlib://resources/StandardApexLibrary/Database/QueryLocatorIterator.cls8�
database.saveresult
SaveResultDatabase *Sapexlib://resources/StandardApexLibrary/Database/SaveResult.cls#Database.SaveResult2?apexlib://resources/StandardApexLibrary/Database/SaveResult.cls8�
database.undeleteresultUndeleteResultDatabase *[apexlib://resources/StandardApexLibrary/Database/UndeleteResult.cls#Database.UndeleteResult2Capexlib://resources/StandardApexLibrary/Database/UndeleteResult.cls8�
database.upsertresultUpsertResultDatabase *Wapexlib://resources/StandardApexLibrary/Database/UpsertResult.cls#Database.UpsertResult2Aapexlib://resources/StandardApexLibrary/Database/UpsertResult.cls8�
"datacloud.additionalinformationmapAdditionalInformationMap	Datacloud *qapexlib://resources/StandardApexLibrary/Datacloud/AdditionalInformationMap.cls#Datacloud.AdditionalInformationMap2Napexlib://resources/StandardApexLibrary/Datacloud/AdditionalInformationMap.cls8�
datacloud.duplicateresultDuplicateResult	Datacloud *_apexlib://resources/StandardApexLibrary/Datacloud/DuplicateResult.cls#Datacloud.DuplicateResult2Eapexlib://resources/StandardApexLibrary/Datacloud/DuplicateResult.cls8�
datacloud.fielddiff	FieldDiff	Datacloud *Sapexlib://resources/StandardApexLibrary/Datacloud/FieldDiff.cls#Datacloud.FieldDiff2?apexlib://resources/StandardApexLibrary/Datacloud/FieldDiff.cls8�
datacloud.findduplicatesFindDuplicates	Datacloud *]apexlib://resources/StandardApexLibrary/Datacloud/FindDuplicates.cls#Datacloud.FindDuplicates2Dapexlib://resources/StandardApexLibrary/Datacloud/FindDuplicates.cls8�
datacloud.findduplicatesbyidsFindDuplicatesByIds	Datacloud *gapexlib://resources/StandardApexLibrary/Datacloud/FindDuplicatesByIds.cls#Datacloud.FindDuplicatesByIds2Iapexlib://resources/StandardApexLibrary/Datacloud/FindDuplicatesByIds.cls8�
datacloud.findduplicatesresultFindDuplicatesResult	Datacloud *iapexlib://resources/StandardApexLibrary/Datacloud/FindDuplicatesResult.cls#Datacloud.FindDuplicatesResult2Japexlib://resources/StandardApexLibrary/Datacloud/FindDuplicatesResult.cls8�
datacloud.matchrecordMatchRecord	Datacloud *Wapexlib://resources/StandardApexLibrary/Datacloud/MatchRecord.cls#Datacloud.MatchRecord2Aapexlib://resources/StandardApexLibrary/Datacloud/MatchRecord.cls8�
datacloud.matchresultMatchResult	Datacloud *Wapexlib://resources/StandardApexLibrary/Datacloud/MatchResult.cls#Datacloud.MatchResult2Aapexlib://resources/StandardApexLibrary/Datacloud/MatchResult.cls8�
dom.documentDocumentDom *Eapexlib://resources/StandardApexLibrary/Dom/Document.cls#Dom.Document28apexlib://resources/StandardApexLibrary/Dom/Document.cls8�
dom.xmlnodeXmlNodeDom *Capexlib://resources/StandardApexLibrary/Dom/XmlNode.cls#Dom.XmlNode27apexlib://resources/StandardApexLibrary/Dom/XmlNode.cls8�
dom.xmlnodetypeXmlNodeTypeDom *Kapexlib://resources/StandardApexLibrary/Dom/XmlNodeType.cls#Dom.XmlNodeType2;apexlib://resources/StandardApexLibrary/Dom/XmlNodeType.cls8�
eventbus.changeeventheaderChangeEventHeaderEventBus *aapexlib://resources/StandardApexLibrary/EventBus/ChangeEventHeader.cls#EventBus.ChangeEventHeader2Fapexlib://resources/StandardApexLibrary/EventBus/ChangeEventHeader.cls8�
$eventbus.eventpublishfailurecallbackEventPublishFailureCallbackEventBus *uapexlib://resources/StandardApexLibrary/EventBus/EventPublishFailureCallback.cls#EventBus.EventPublishFailureCallback2Papexlib://resources/StandardApexLibrary/EventBus/EventPublishFailureCallback.cls8�
$eventbus.eventpublishsuccesscallbackEventPublishSuccessCallbackEventBus *uapexlib://resources/StandardApexLibrary/EventBus/EventPublishSuccessCallback.cls#EventBus.EventPublishSuccessCallback2Papexlib://resources/StandardApexLibrary/EventBus/EventPublishSuccessCallback.cls8�
eventbus.failureresultFailureResultEventBus *Yapexlib://resources/StandardApexLibrary/EventBus/FailureResult.cls#EventBus.FailureResult2Bapexlib://resources/StandardApexLibrary/EventBus/FailureResult.cls8�
eventbus.successresultSuccessResultEventBus *Yapexlib://resources/StandardApexLibrary/EventBus/SuccessResult.cls#EventBus.SuccessResult2Bapexlib://resources/StandardApexLibrary/EventBus/SuccessResult.cls8�
eventbus.testbroker
TestBrokerEventBus *Sapexlib://resources/StandardApexLibrary/EventBus/TestBroker.cls#EventBus.TestBroker2?apexlib://resources/StandardApexLibrary/EventBus/TestBroker.cls8�
eventbus.triggercontextTriggerContextEventBus *[apexlib://resources/StandardApexLibrary/EventBus/TriggerContext.cls#EventBus.TriggerContext2Capexlib://resources/StandardApexLibrary/EventBus/TriggerContext.cls8�
flow.interview	InterviewFlow *Iapexlib://resources/StandardApexLibrary/Flow/Interview.cls#Flow.Interview2:apexlib://resources/StandardApexLibrary/Flow/Interview.cls8�
formulaeval.formulabuilderFormulaBuilderFormulaEval *aapexlib://resources/StandardApexLibrary/FormulaEval/FormulaBuilder.cls#FormulaEval.FormulaBuilder2Fapexlib://resources/StandardApexLibrary/FormulaEval/FormulaBuilder.cls8�
formulaeval.formulaglobalFormulaGlobalFormulaEval *_apexlib://resources/StandardApexLibrary/FormulaEval/FormulaGlobal.cls#FormulaEval.FormulaGlobal2Eapexlib://resources/StandardApexLibrary/FormulaEval/FormulaGlobal.cls8�
formulaeval.formulainstanceFormulaInstanceFormulaEval *capexlib://resources/StandardApexLibrary/FormulaEval/FormulaInstance.cls#FormulaEval.FormulaInstance2Gapexlib://resources/StandardApexLibrary/FormulaEval/FormulaInstance.cls8�
formulaeval.formulareturntypeFormulaReturnTypeFormulaEval *gapexlib://resources/StandardApexLibrary/FormulaEval/FormulaReturnType.cls#FormulaEval.FormulaReturnType2Iapexlib://resources/StandardApexLibrary/FormulaEval/FormulaReturnType.cls8�
functions.functionFunction	Functions *Qapexlib://resources/StandardApexLibrary/Functions/Function.cls#Functions.Function2>apexlib://resources/StandardApexLibrary/Functions/Function.cls8�
functions.functioncallbackFunctionCallback	Functions *aapexlib://resources/StandardApexLibrary/Functions/FunctionCallback.cls#Functions.FunctionCallback2Fapexlib://resources/StandardApexLibrary/Functions/FunctionCallback.cls8�
functions.functionerrortypeFunctionErrorType	Functions *capexlib://resources/StandardApexLibrary/Functions/FunctionErrorType.cls#Functions.FunctionErrorType2Gapexlib://resources/StandardApexLibrary/Functions/FunctionErrorType.cls8�
functions.functioninvocationFunctionInvocation	Functions *eapexlib://resources/StandardApexLibrary/Functions/FunctionInvocation.cls#Functions.FunctionInvocation2Hapexlib://resources/StandardApexLibrary/Functions/FunctionInvocation.cls8�
!functions.functioninvocationerrorFunctionInvocationError	Functions *oapexlib://resources/StandardApexLibrary/Functions/FunctionInvocationError.cls#Functions.FunctionInvocationError2Mapexlib://resources/StandardApexLibrary/Functions/FunctionInvocationError.cls8�
"functions.functioninvocationstatusFunctionInvocationStatus	Functions *qapexlib://resources/StandardApexLibrary/Functions/FunctionInvocationStatus.cls#Functions.FunctionInvocationStatus2Napexlib://resources/StandardApexLibrary/Functions/FunctionInvocationStatus.cls8�
functions.functioninvokemockFunctionInvokeMock	Functions *eapexlib://resources/StandardApexLibrary/Functions/FunctionInvokeMock.cls#Functions.FunctionInvokeMock2Hapexlib://resources/StandardApexLibrary/Functions/FunctionInvokeMock.cls8�
'functions.mockfunctioninvocationfactoryMockFunctionInvocationFactory	Functions *{apexlib://resources/StandardApexLibrary/Functions/MockFunctionInvocationFactory.cls#Functions.MockFunctionInvocationFactory2Sapexlib://resources/StandardApexLibrary/Functions/MockFunctionInvocationFactory.cls8�
invocable.actionAction	Invocable *Mapexlib://resources/StandardApexLibrary/Invocable/Action.cls#Invocable.Action2<apexlib://resources/StandardApexLibrary/Invocable/Action.cls8�
invocable.errorError	Invocable *Kapexlib://resources/StandardApexLibrary/Invocable/Error.cls#Invocable.Error2;apexlib://resources/StandardApexLibrary/Invocable/Error.cls8�
invocable.resultResult	Invocable *Mapexlib://resources/StandardApexLibrary/Invocable/Result.cls#Invocable.Result2<apexlib://resources/StandardApexLibrary/Invocable/Result.cls8�
isvpartners.appanalyticsAppAnalyticsIsvPartners *]apexlib://resources/StandardApexLibrary/IsvPartners/AppAnalytics.cls#IsvPartners.AppAnalytics2Dapexlib://resources/StandardApexLibrary/IsvPartners/AppAnalytics.cls8�
kbmanagement.publishingservicePublishingServiceKbManagement *iapexlib://resources/StandardApexLibrary/KbManagement/PublishingService.cls#KbManagement.PublishingService2Japexlib://resources/StandardApexLibrary/KbManagement/PublishingService.cls8�
)lxscheduler.getappointmentcandidatesinputGetAppointmentCandidatesInputLxScheduler *apexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentCandidatesInput.cls#LxScheduler.GetAppointmentCandidatesInput2Uapexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentCandidatesInput.cls8�
0lxscheduler.getappointmentcandidatesinputbuilder$GetAppointmentCandidatesInputBuilderLxScheduler *�apexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentCandidatesInputBuilder.cls#LxScheduler.GetAppointmentCandidatesInputBuilder2\apexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentCandidatesInputBuilder.cls8�
$lxscheduler.getappointmentslotsinputGetAppointmentSlotsInputLxScheduler *uapexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentSlotsInput.cls#LxScheduler.GetAppointmentSlotsInput2Papexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentSlotsInput.cls8�
+lxscheduler.getappointmentslotsinputbuilderGetAppointmentSlotsInputBuilderLxScheduler *�apexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentSlotsInputBuilder.cls#LxScheduler.GetAppointmentSlotsInputBuilder2Wapexlib://resources/StandardApexLibrary/LxScheduler/GetAppointmentSlotsInputBuilder.cls8�
lxscheduler.schedulerresourcesSchedulerResourcesLxScheduler *iapexlib://resources/StandardApexLibrary/LxScheduler/SchedulerResources.cls#LxScheduler.SchedulerResources2Japexlib://resources/StandardApexLibrary/LxScheduler/SchedulerResources.cls8�
)lxscheduler.serviceappointmentrequestinfoServiceAppointmentRequestInfoLxScheduler *apexlib://resources/StandardApexLibrary/LxScheduler/ServiceAppointmentRequestInfo.cls#LxScheduler.ServiceAppointmentRequestInfo2Uapexlib://resources/StandardApexLibrary/LxScheduler/ServiceAppointmentRequestInfo.cls8�
lxscheduler.serviceresourceinfoServiceResourceInfoLxScheduler *kapexlib://resources/StandardApexLibrary/LxScheduler/ServiceResourceInfo.cls#LxScheduler.ServiceResourceInfo2Kapexlib://resources/StandardApexLibrary/LxScheduler/ServiceResourceInfo.cls8�
#lxscheduler.serviceresourcescheduleServiceResourceScheduleLxScheduler *sapexlib://resources/StandardApexLibrary/LxScheduler/ServiceResourceSchedule.cls#LxScheduler.ServiceResourceSchedule2Oapexlib://resources/StandardApexLibrary/LxScheduler/ServiceResourceSchedule.cls8�
*lxscheduler.serviceresourceschedulehandlerServiceResourceScheduleHandlerLxScheduler *�apexlib://resources/StandardApexLibrary/LxScheduler/ServiceResourceScheduleHandler.cls#LxScheduler.ServiceResourceScheduleHandler2Vapexlib://resources/StandardApexLibrary/LxScheduler/ServiceResourceScheduleHandler.cls8�
lxscheduler.skillrequirementSkillRequirementLxScheduler *eapexlib://resources/StandardApexLibrary/LxScheduler/SkillRequirement.cls#LxScheduler.SkillRequirement2Hapexlib://resources/StandardApexLibrary/LxScheduler/SkillRequirement.cls8�
#lxscheduler.skillrequirementbuilderSkillRequirementBuilderLxScheduler *sapexlib://resources/StandardApexLibrary/LxScheduler/SkillRequirementBuilder.cls#LxScheduler.SkillRequirementBuilder2Oapexlib://resources/StandardApexLibrary/LxScheduler/SkillRequirementBuilder.cls8�
lxscheduler.unavailabletimeslotUnavailableTimeslotLxScheduler *kapexlib://resources/StandardApexLibrary/LxScheduler/UnavailableTimeslot.cls#LxScheduler.UnavailableTimeslot2Kapexlib://resources/StandardApexLibrary/LxScheduler/UnavailableTimeslot.cls8�
lxscheduler.worktypeWorkTypeLxScheduler *Uapexlib://resources/StandardApexLibrary/LxScheduler/WorkType.cls#LxScheduler.WorkType2@apexlib://resources/StandardApexLibrary/LxScheduler/WorkType.cls8�
lxscheduler.worktypebuilderWorkTypeBuilderLxScheduler *capexlib://resources/StandardApexLibrary/LxScheduler/WorkTypeBuilder.cls#LxScheduler.WorkTypeBuilder2Gapexlib://resources/StandardApexLibrary/LxScheduler/WorkTypeBuilder.cls8�
#messaging.attachmentretrievaloptionAttachmentRetrievalOption	Messaging *sapexlib://resources/StandardApexLibrary/Messaging/AttachmentRetrievalOption.cls#Messaging.AttachmentRetrievalOption2Oapexlib://resources/StandardApexLibrary/Messaging/AttachmentRetrievalOption.cls8�
messaging.authenticationresultAuthenticationResult	Messaging *iapexlib://resources/StandardApexLibrary/Messaging/AuthenticationResult.cls#Messaging.AuthenticationResult2Japexlib://resources/StandardApexLibrary/Messaging/AuthenticationResult.cls8�
#messaging.authenticationresultfieldAuthenticationResultField	Messaging *sapexlib://resources/StandardApexLibrary/Messaging/AuthenticationResultField.cls#Messaging.AuthenticationResultField2Oapexlib://resources/StandardApexLibrary/Messaging/AuthenticationResultField.cls8�
messaging.binaryattachmentBinaryAttachment	Messaging *aapexlib://resources/StandardApexLibrary/Messaging/BinaryAttachment.cls#Messaging.BinaryAttachment2Fapexlib://resources/StandardApexLibrary/Messaging/BinaryAttachment.cls8�
messaging.customnotificationCustomNotification	Messaging *eapexlib://resources/StandardApexLibrary/Messaging/CustomNotification.cls#Messaging.CustomNotification2Hapexlib://resources/StandardApexLibrary/Messaging/CustomNotification.cls8�
messaging.emailfileattachmentEmailFileAttachment	Messaging *gapexlib://resources/StandardApexLibrary/Messaging/EmailFileAttachment.cls#Messaging.EmailFileAttachment2Iapexlib://resources/StandardApexLibrary/Messaging/EmailFileAttachment.cls8�
messaging.headerHeader	Messaging *Mapexlib://resources/StandardApexLibrary/Messaging/Header.cls#Messaging.Header2<apexlib://resources/StandardApexLibrary/Messaging/Header.cls8�
messaging.inboundemailInboundEmail	Messaging *Yapexlib://resources/StandardApexLibrary/Messaging/InboundEmail.cls#Messaging.InboundEmail2Bapexlib://resources/StandardApexLibrary/Messaging/InboundEmail.cls8�
messaging.inboundemailresultInboundEmailResult	Messaging *eapexlib://resources/StandardApexLibrary/Messaging/InboundEmailResult.cls#Messaging.InboundEmailResult2Hapexlib://resources/StandardApexLibrary/Messaging/InboundEmailResult.cls8�
messaging.inboundenvelopeInboundEnvelope	Messaging *_apexlib://resources/StandardApexLibrary/Messaging/InboundEnvelope.cls#Messaging.InboundEnvelope2Eapexlib://resources/StandardApexLibrary/Messaging/InboundEnvelope.cls8�
messaging.massemailmessageMassEmailMessage	Messaging *aapexlib://resources/StandardApexLibrary/Messaging/MassEmailMessage.cls#Messaging.MassEmailMessage2Fapexlib://resources/StandardApexLibrary/Messaging/MassEmailMessage.cls8�
messaging.pushnotificationPushNotification	Messaging *aapexlib://resources/StandardApexLibrary/Messaging/PushNotification.cls#Messaging.PushNotification2Fapexlib://resources/StandardApexLibrary/Messaging/PushNotification.cls8�
!messaging.pushnotificationpayloadPushNotificationPayload	Messaging *oapexlib://resources/StandardApexLibrary/Messaging/PushNotificationPayload.cls#Messaging.PushNotificationPayload2Mapexlib://resources/StandardApexLibrary/Messaging/PushNotificationPayload.cls8�
'messaging.renderemailtemplatebodyresultRenderEmailTemplateBodyResult	Messaging *{apexlib://resources/StandardApexLibrary/Messaging/RenderEmailTemplateBodyResult.cls#Messaging.RenderEmailTemplateBodyResult2Sapexlib://resources/StandardApexLibrary/Messaging/RenderEmailTemplateBodyResult.cls8�
"messaging.renderemailtemplateerrorRenderEmailTemplateError	Messaging *qapexlib://resources/StandardApexLibrary/Messaging/RenderEmailTemplateError.cls#Messaging.RenderEmailTemplateError2Napexlib://resources/StandardApexLibrary/Messaging/RenderEmailTemplateError.cls8�
messaging.sendemailerrorSendEmailError	Messaging *]apexlib://resources/StandardApexLibrary/Messaging/SendEmailError.cls#Messaging.SendEmailError2Dapexlib://resources/StandardApexLibrary/Messaging/SendEmailError.cls8�
messaging.sendemailresultSendEmailResult	Messaging *_apexlib://resources/StandardApexLibrary/Messaging/SendEmailResult.cls#Messaging.SendEmailResult2Eapexlib://resources/StandardApexLibrary/Messaging/SendEmailResult.cls8�
messaging.singleemailmessageSingleEmailMessage	Messaging *eapexlib://resources/StandardApexLibrary/Messaging/SingleEmailMessage.cls#Messaging.SingleEmailMessage2Hapexlib://resources/StandardApexLibrary/Messaging/SingleEmailMessage.cls8�
messaging.textattachmentTextAttachment	Messaging *]apexlib://resources/StandardApexLibrary/Messaging/TextAttachment.cls#Messaging.TextAttachment2Dapexlib://resources/StandardApexLibrary/Messaging/TextAttachment.cls8�
*metadata.analyticscloudcomponentlayoutitem!AnalyticsCloudComponentLayoutItemMetadata *�apexlib://resources/StandardApexLibrary/Metadata/AnalyticsCloudComponentLayoutItem.cls#Metadata.AnalyticsCloudComponentLayoutItem2Vapexlib://resources/StandardApexLibrary/Metadata/AnalyticsCloudComponentLayoutItem.cls8�
metadata.consolecomponentConsoleComponentMetadata *_apexlib://resources/StandardApexLibrary/Metadata/ConsoleComponent.cls#Metadata.ConsoleComponent2Eapexlib://resources/StandardApexLibrary/Metadata/ConsoleComponent.cls8�
metadata.container	ContainerMetadata *Qapexlib://resources/StandardApexLibrary/Metadata/Container.cls#Metadata.Container2>apexlib://resources/StandardApexLibrary/Metadata/Container.cls8�
 metadata.customconsolecomponentsCustomConsoleComponentsMetadata *mapexlib://resources/StandardApexLibrary/Metadata/CustomConsoleComponents.cls#Metadata.CustomConsoleComponents2Lapexlib://resources/StandardApexLibrary/Metadata/CustomConsoleComponents.cls8�
metadata.custommetadataCustomMetadataMetadata *[apexlib://resources/StandardApexLibrary/Metadata/CustomMetadata.cls#Metadata.CustomMetadata2Capexlib://resources/StandardApexLibrary/Metadata/CustomMetadata.cls8�
metadata.custommetadatavalueCustomMetadataValueMetadata *eapexlib://resources/StandardApexLibrary/Metadata/CustomMetadataValue.cls#Metadata.CustomMetadataValue2Hapexlib://resources/StandardApexLibrary/Metadata/CustomMetadataValue.cls8�
metadata.deploycallbackDeployCallbackMetadata *[apexlib://resources/StandardApexLibrary/Metadata/DeployCallback.cls#Metadata.DeployCallback2Capexlib://resources/StandardApexLibrary/Metadata/DeployCallback.cls8�
metadata.deploycallbackcontextDeployCallbackContextMetadata *iapexlib://resources/StandardApexLibrary/Metadata/DeployCallbackContext.cls#Metadata.DeployCallbackContext2Japexlib://resources/StandardApexLibrary/Metadata/DeployCallbackContext.cls8�
metadata.deploycontainerDeployContainerMetadata *]apexlib://resources/StandardApexLibrary/Metadata/DeployContainer.cls#Metadata.DeployContainer2Dapexlib://resources/StandardApexLibrary/Metadata/DeployContainer.cls8�
metadata.deploydetailsDeployDetailsMetadata *Yapexlib://resources/StandardApexLibrary/Metadata/DeployDetails.cls#Metadata.DeployDetails2Bapexlib://resources/StandardApexLibrary/Metadata/DeployDetails.cls8�
metadata.deploymessageDeployMessageMetadata *Yapexlib://resources/StandardApexLibrary/Metadata/DeployMessage.cls#Metadata.DeployMessage2Bapexlib://resources/StandardApexLibrary/Metadata/DeployMessage.cls8�
metadata.deployproblemtypeDeployProblemTypeMetadata *aapexlib://resources/StandardApexLibrary/Metadata/DeployProblemType.cls#Metadata.DeployProblemType2Fapexlib://resources/StandardApexLibrary/Metadata/DeployProblemType.cls8�
metadata.deployresultDeployResultMetadata *Wapexlib://resources/StandardApexLibrary/Metadata/DeployResult.cls#Metadata.DeployResult2Aapexlib://resources/StandardApexLibrary/Metadata/DeployResult.cls8�
metadata.deploystatusDeployStatusMetadata *Wapexlib://resources/StandardApexLibrary/Metadata/DeployStatus.cls#Metadata.DeployStatus2Aapexlib://resources/StandardApexLibrary/Metadata/DeployStatus.cls8�
metadata.feeditemtypeenumFeedItemTypeEnumMetadata *_apexlib://resources/StandardApexLibrary/Metadata/FeedItemTypeEnum.cls#Metadata.FeedItemTypeEnum2Eapexlib://resources/StandardApexLibrary/Metadata/FeedItemTypeEnum.cls8�
metadata.feedlayout
FeedLayoutMetadata *Sapexlib://resources/StandardApexLibrary/Metadata/FeedLayout.cls#Metadata.FeedLayout2?apexlib://resources/StandardApexLibrary/Metadata/FeedLayout.cls8�
metadata.feedlayoutcomponentFeedLayoutComponentMetadata *eapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutComponent.cls#Metadata.FeedLayoutComponent2Hapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutComponent.cls8�
 metadata.feedlayoutcomponenttypeFeedLayoutComponentTypeMetadata *mapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutComponentType.cls#Metadata.FeedLayoutComponentType2Lapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutComponentType.cls8�
metadata.feedlayoutfilterFeedLayoutFilterMetadata *_apexlib://resources/StandardApexLibrary/Metadata/FeedLayoutFilter.cls#Metadata.FeedLayoutFilter2Eapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutFilter.cls8�
!metadata.feedlayoutfilterpositionFeedLayoutFilterPositionMetadata *oapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutFilterPosition.cls#Metadata.FeedLayoutFilterPosition2Mapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutFilterPosition.cls8�
metadata.feedlayoutfiltertypeFeedLayoutFilterTypeMetadata *gapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutFilterType.cls#Metadata.FeedLayoutFilterType2Iapexlib://resources/StandardApexLibrary/Metadata/FeedLayoutFilterType.cls8�
metadata.layoutLayoutMetadata *Kapexlib://resources/StandardApexLibrary/Metadata/Layout.cls#Metadata.Layout2;apexlib://resources/StandardApexLibrary/Metadata/Layout.cls8�
metadata.layoutcolumnLayoutColumnMetadata *Wapexlib://resources/StandardApexLibrary/Metadata/LayoutColumn.cls#Metadata.LayoutColumn2Aapexlib://resources/StandardApexLibrary/Metadata/LayoutColumn.cls8�
metadata.layoutheaderLayoutHeaderMetadata *Wapexlib://resources/StandardApexLibrary/Metadata/LayoutHeader.cls#Metadata.LayoutHeader2Aapexlib://resources/StandardApexLibrary/Metadata/LayoutHeader.cls8�
metadata.layoutitem
LayoutItemMetadata *Sapexlib://resources/StandardApexLibrary/Metadata/LayoutItem.cls#Metadata.LayoutItem2?apexlib://resources/StandardApexLibrary/Metadata/LayoutItem.cls8�
metadata.layoutsectionLayoutSectionMetadata *Yapexlib://resources/StandardApexLibrary/Metadata/LayoutSection.cls#Metadata.LayoutSection2Bapexlib://resources/StandardApexLibrary/Metadata/LayoutSection.cls8�
metadata.layoutsectionstyleLayoutSectionStyleMetadata *capexlib://resources/StandardApexLibrary/Metadata/LayoutSectionStyle.cls#Metadata.LayoutSectionStyle2Gapexlib://resources/StandardApexLibrary/Metadata/LayoutSectionStyle.cls8�
metadata.metadataMetadataMetadata *Oapexlib://resources/StandardApexLibrary/Metadata/Metadata.cls#Metadata.Metadata2=apexlib://resources/StandardApexLibrary/Metadata/Metadata.cls8�
metadata.metadatatypeMetadataTypeMetadata *Wapexlib://resources/StandardApexLibrary/Metadata/MetadataType.cls#Metadata.MetadataType2Aapexlib://resources/StandardApexLibrary/Metadata/MetadataType.cls8�
metadata.metadatavalueMetadataValueMetadata *Yapexlib://resources/StandardApexLibrary/Metadata/MetadataValue.cls#Metadata.MetadataValue2Bapexlib://resources/StandardApexLibrary/Metadata/MetadataValue.cls8�
metadata.minilayout
MiniLayoutMetadata *Sapexlib://resources/StandardApexLibrary/Metadata/MiniLayout.cls#Metadata.MiniLayout2?apexlib://resources/StandardApexLibrary/Metadata/MiniLayout.cls8�
metadata.operations
OperationsMetadata *Sapexlib://resources/StandardApexLibrary/Metadata/Operations.cls#Metadata.Operations2?apexlib://resources/StandardApexLibrary/Metadata/Operations.cls8�
metadata.platformactionlistPlatformActionListMetadata *capexlib://resources/StandardApexLibrary/Metadata/PlatformActionList.cls#Metadata.PlatformActionList2Gapexlib://resources/StandardApexLibrary/Metadata/PlatformActionList.cls8�
&metadata.platformactionlistcontextenumPlatformActionListContextEnumMetadata *yapexlib://resources/StandardApexLibrary/Metadata/PlatformActionListContextEnum.cls#Metadata.PlatformActionListContextEnum2Rapexlib://resources/StandardApexLibrary/Metadata/PlatformActionListContextEnum.cls8�
metadata.platformactionlistitemPlatformActionListItemMetadata *kapexlib://resources/StandardApexLibrary/Metadata/PlatformActionListItem.cls#Metadata.PlatformActionListItem2Kapexlib://resources/StandardApexLibrary/Metadata/PlatformActionListItem.cls8�
metadata.platformactiontypeenumPlatformActionTypeEnumMetadata *kapexlib://resources/StandardApexLibrary/Metadata/PlatformActionTypeEnum.cls#Metadata.PlatformActionTypeEnum2Kapexlib://resources/StandardApexLibrary/Metadata/PlatformActionTypeEnum.cls8�
metadata.primarytabcomponentsPrimaryTabComponentsMetadata *gapexlib://resources/StandardApexLibrary/Metadata/PrimaryTabComponents.cls#Metadata.PrimaryTabComponents2Iapexlib://resources/StandardApexLibrary/Metadata/PrimaryTabComponents.cls8�
metadata.quickactionlistQuickActionListMetadata *]apexlib://resources/StandardApexLibrary/Metadata/QuickActionList.cls#Metadata.QuickActionList2Dapexlib://resources/StandardApexLibrary/Metadata/QuickActionList.cls8�
metadata.quickactionlistitemQuickActionListItemMetadata *eapexlib://resources/StandardApexLibrary/Metadata/QuickActionListItem.cls#Metadata.QuickActionListItem2Hapexlib://resources/StandardApexLibrary/Metadata/QuickActionListItem.cls8�
metadata.relatedcontentRelatedContentMetadata *[apexlib://resources/StandardApexLibrary/Metadata/RelatedContent.cls#Metadata.RelatedContent2Capexlib://resources/StandardApexLibrary/Metadata/RelatedContent.cls8�
metadata.relatedcontentitemRelatedContentItemMetadata *capexlib://resources/StandardApexLibrary/Metadata/RelatedContentItem.cls#Metadata.RelatedContentItem2Gapexlib://resources/StandardApexLibrary/Metadata/RelatedContentItem.cls8�
metadata.relatedlistRelatedListMetadata *Uapexlib://resources/StandardApexLibrary/Metadata/RelatedList.cls#Metadata.RelatedList2@apexlib://resources/StandardApexLibrary/Metadata/RelatedList.cls8�
metadata.relatedlistitemRelatedListItemMetadata *]apexlib://resources/StandardApexLibrary/Metadata/RelatedListItem.cls#Metadata.RelatedListItem2Dapexlib://resources/StandardApexLibrary/Metadata/RelatedListItem.cls8�
'metadata.reportchartcomponentlayoutitemReportChartComponentLayoutItemMetadata *{apexlib://resources/StandardApexLibrary/Metadata/ReportChartComponentLayoutItem.cls#Metadata.ReportChartComponentLayoutItem2Sapexlib://resources/StandardApexLibrary/Metadata/ReportChartComponentLayoutItem.cls8�
!metadata.reportchartcomponentsizeReportChartComponentSizeMetadata *oapexlib://resources/StandardApexLibrary/Metadata/ReportChartComponentSize.cls#Metadata.ReportChartComponentSize2Mapexlib://resources/StandardApexLibrary/Metadata/ReportChartComponentSize.cls8�
metadata.sidebarcomponentSidebarComponentMetadata *_apexlib://resources/StandardApexLibrary/Metadata/SidebarComponent.cls#Metadata.SidebarComponent2Eapexlib://resources/StandardApexLibrary/Metadata/SidebarComponent.cls8�
metadata.sortorder	SortOrderMetadata *Qapexlib://resources/StandardApexLibrary/Metadata/SortOrder.cls#Metadata.SortOrder2>apexlib://resources/StandardApexLibrary/Metadata/SortOrder.cls8�
metadata.statuscode
StatusCodeMetadata *Sapexlib://resources/StandardApexLibrary/Metadata/StatusCode.cls#Metadata.StatusCode2?apexlib://resources/StandardApexLibrary/Metadata/StatusCode.cls8�
metadata.subtabcomponentsSubtabComponentsMetadata *_apexlib://resources/StandardApexLibrary/Metadata/SubtabComponents.cls#Metadata.SubtabComponents2Eapexlib://resources/StandardApexLibrary/Metadata/SubtabComponents.cls8�
metadata.summarylayoutSummaryLayoutMetadata *Yapexlib://resources/StandardApexLibrary/Metadata/SummaryLayout.cls#Metadata.SummaryLayout2Bapexlib://resources/StandardApexLibrary/Metadata/SummaryLayout.cls8�
metadata.summarylayoutitemSummaryLayoutItemMetadata *aapexlib://resources/StandardApexLibrary/Metadata/SummaryLayoutItem.cls#Metadata.SummaryLayoutItem2Fapexlib://resources/StandardApexLibrary/Metadata/SummaryLayoutItem.cls8�
metadata.summarylayoutstyleenumSummaryLayoutStyleEnumMetadata *kapexlib://resources/StandardApexLibrary/Metadata/SummaryLayoutStyleEnum.cls#Metadata.SummaryLayoutStyleEnum2Kapexlib://resources/StandardApexLibrary/Metadata/SummaryLayoutStyleEnum.cls8�
metadata.uibehavior
UiBehaviorMetadata *Sapexlib://resources/StandardApexLibrary/Metadata/UiBehavior.cls#Metadata.UiBehavior2?apexlib://resources/StandardApexLibrary/Metadata/UiBehavior.cls8�
pref_center.loadformdataLoadFormDataPref_center *]apexlib://resources/StandardApexLibrary/Pref_center/LoadFormData.cls#Pref_center.LoadFormData2Dapexlib://resources/StandardApexLibrary/Pref_center/LoadFormData.cls8�
pref_center.loadparametersLoadParametersPref_center *aapexlib://resources/StandardApexLibrary/Pref_center/LoadParameters.cls#Pref_center.LoadParameters2Fapexlib://resources/StandardApexLibrary/Pref_center/LoadParameters.cls8�
'pref_center.preferencecenterapexhandlerPreferenceCenterApexHandlerPref_center *{apexlib://resources/StandardApexLibrary/Pref_center/PreferenceCenterApexHandler.cls#Pref_center.PreferenceCenterApexHandler2Sapexlib://resources/StandardApexLibrary/Pref_center/PreferenceCenterApexHandler.cls8�
pref_center.submitformdataSubmitFormDataPref_center *aapexlib://resources/StandardApexLibrary/Pref_center/SubmitFormData.cls#Pref_center.SubmitFormData2Fapexlib://resources/StandardApexLibrary/Pref_center/SubmitFormData.cls8�
pref_center.submitparametersSubmitParametersPref_center *eapexlib://resources/StandardApexLibrary/Pref_center/SubmitParameters.cls#Pref_center.SubmitParameters2Hapexlib://resources/StandardApexLibrary/Pref_center/SubmitParameters.cls8�
pref_center.tokentype	TokenTypePref_center *Wapexlib://resources/StandardApexLibrary/Pref_center/TokenType.cls#Pref_center.TokenType2Aapexlib://resources/StandardApexLibrary/Pref_center/TokenType.cls8�
pref_center.tokenutilityTokenUtilityPref_center *]apexlib://resources/StandardApexLibrary/Pref_center/TokenUtility.cls#Pref_center.TokenUtility2Dapexlib://resources/StandardApexLibrary/Pref_center/TokenUtility.cls8�
pref_center.validationresultValidationResultPref_center *eapexlib://resources/StandardApexLibrary/Pref_center/ValidationResult.cls#Pref_center.ValidationResult2Hapexlib://resources/StandardApexLibrary/Pref_center/ValidationResult.cls8�
process.inputparameterInputParameterProcess *Yapexlib://resources/StandardApexLibrary/Process/InputParameter.cls#Process.InputParameter2Bapexlib://resources/StandardApexLibrary/Process/InputParameter.cls8�
process.outputparameterOutputParameterProcess *[apexlib://resources/StandardApexLibrary/Process/OutputParameter.cls#Process.OutputParameter2Capexlib://resources/StandardApexLibrary/Process/OutputParameter.cls8�
process.parametertypeParameterTypeProcess *Wapexlib://resources/StandardApexLibrary/Process/ParameterType.cls#Process.ParameterType2Aapexlib://resources/StandardApexLibrary/Process/ParameterType.cls8�
process.pluginPluginProcess *Iapexlib://resources/StandardApexLibrary/Process/Plugin.cls#Process.Plugin2:apexlib://resources/StandardApexLibrary/Process/Plugin.cls8�
process.plugindescriberesultPluginDescribeResultProcess *eapexlib://resources/StandardApexLibrary/Process/PluginDescribeResult.cls#Process.PluginDescribeResult2Hapexlib://resources/StandardApexLibrary/Process/PluginDescribeResult.cls8�
process.pluginrequestPluginRequestProcess *Wapexlib://resources/StandardApexLibrary/Process/PluginRequest.cls#Process.PluginRequest2Aapexlib://resources/StandardApexLibrary/Process/PluginRequest.cls8�
process.pluginresultPluginResultProcess *Uapexlib://resources/StandardApexLibrary/Process/PluginResult.cls#Process.PluginResult2@apexlib://resources/StandardApexLibrary/Process/PluginResult.cls8�
.quickaction.describeavailablequickactionresult"DescribeAvailableQuickActionResultQuickAction *�apexlib://resources/StandardApexLibrary/QuickAction/DescribeAvailableQuickActionResult.cls#QuickAction.DescribeAvailableQuickActionResult2Zapexlib://resources/StandardApexLibrary/QuickAction/DescribeAvailableQuickActionResult.cls8�
#quickaction.describelayoutcomponentDescribeLayoutComponentQuickAction *sapexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutComponent.cls#QuickAction.DescribeLayoutComponent2Oapexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutComponent.cls8�
quickaction.describelayoutitemDescribeLayoutItemQuickAction *iapexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutItem.cls#QuickAction.DescribeLayoutItem2Japexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutItem.cls8�
quickaction.describelayoutrowDescribeLayoutRowQuickAction *gapexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutRow.cls#QuickAction.DescribeLayoutRow2Iapexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutRow.cls8�
!quickaction.describelayoutsectionDescribeLayoutSectionQuickAction *oapexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutSection.cls#QuickAction.DescribeLayoutSection2Mapexlib://resources/StandardApexLibrary/QuickAction/DescribeLayoutSection.cls8�
+quickaction.describequickactiondefaultvalueDescribeQuickActionDefaultValueQuickAction *�apexlib://resources/StandardApexLibrary/QuickAction/DescribeQuickActionDefaultValue.cls#QuickAction.DescribeQuickActionDefaultValue2Wapexlib://resources/StandardApexLibrary/QuickAction/DescribeQuickActionDefaultValue.cls8�
(quickaction.describequickactionparameterDescribeQuickActionParameterQuickAction *}apexlib://resources/StandardApexLibrary/QuickAction/DescribeQuickActionParameter.cls#QuickAction.DescribeQuickActionParameter2Tapexlib://resources/StandardApexLibrary/QuickAction/DescribeQuickActionParameter.cls8�
%quickaction.describequickactionresultDescribeQuickActionResultQuickAction *wapexlib://resources/StandardApexLibrary/QuickAction/DescribeQuickActionResult.cls#QuickAction.DescribeQuickActionResult2Qapexlib://resources/StandardApexLibrary/QuickAction/DescribeQuickActionResult.cls8�
quickaction.quickactiondefaultsQuickActionDefaultsQuickAction *kapexlib://resources/StandardApexLibrary/QuickAction/QuickActionDefaults.cls#QuickAction.QuickActionDefaults2Kapexlib://resources/StandardApexLibrary/QuickAction/QuickActionDefaults.cls8�
&quickaction.quickactiondefaultshandlerQuickActionDefaultsHandlerQuickAction *yapexlib://resources/StandardApexLibrary/QuickAction/QuickActionDefaultsHandler.cls#QuickAction.QuickActionDefaultsHandler2Rapexlib://resources/StandardApexLibrary/QuickAction/QuickActionDefaultsHandler.cls8�
quickaction.quickactionrequestQuickActionRequestQuickAction *iapexlib://resources/StandardApexLibrary/QuickAction/QuickActionRequest.cls#QuickAction.QuickActionRequest2Japexlib://resources/StandardApexLibrary/QuickAction/QuickActionRequest.cls8�
quickaction.quickactionresultQuickActionResultQuickAction *gapexlib://resources/StandardApexLibrary/QuickAction/QuickActionResult.cls#QuickAction.QuickActionResult2Iapexlib://resources/StandardApexLibrary/QuickAction/QuickActionResult.cls8�
(quickaction.sendemailquickactiondefaultsSendEmailQuickActionDefaultsQuickAction *}apexlib://resources/StandardApexLibrary/QuickAction/SendEmailQuickActionDefaults.cls#QuickAction.SendEmailQuickActionDefaults2Tapexlib://resources/StandardApexLibrary/QuickAction/SendEmailQuickActionDefaults.cls8�
reports.aggregatecolumnAggregateColumnReports *[apexlib://resources/StandardApexLibrary/Reports/AggregateColumn.cls#Reports.AggregateColumn2Capexlib://resources/StandardApexLibrary/Reports/AggregateColumn.cls8�
reports.bucketfieldBucketFieldReports *Sapexlib://resources/StandardApexLibrary/Reports/BucketField.cls#Reports.BucketField2?apexlib://resources/StandardApexLibrary/Reports/BucketField.cls8�
reports.bucketfieldvalueBucketFieldValueReports *]apexlib://resources/StandardApexLibrary/Reports/BucketFieldValue.cls#Reports.BucketFieldValue2Dapexlib://resources/StandardApexLibrary/Reports/BucketFieldValue.cls8�
reports.buckettype
BucketTypeReports *Qapexlib://resources/StandardApexLibrary/Reports/BucketType.cls#Reports.BucketType2>apexlib://resources/StandardApexLibrary/Reports/BucketType.cls8�
reports.columndatatypeColumnDataTypeReports *Yapexlib://resources/StandardApexLibrary/Reports/ColumnDataType.cls#Reports.ColumnDataType2Bapexlib://resources/StandardApexLibrary/Reports/ColumnDataType.cls8�
reports.columnsortorderColumnSortOrderReports *[apexlib://resources/StandardApexLibrary/Reports/ColumnSortOrder.cls#Reports.ColumnSortOrder2Capexlib://resources/StandardApexLibrary/Reports/ColumnSortOrder.cls8�
reports.crossfilterCrossFilterReports *Sapexlib://resources/StandardApexLibrary/Reports/CrossFilter.cls#Reports.CrossFilter2?apexlib://resources/StandardApexLibrary/Reports/CrossFilter.cls8�
reports.csfgrouptypeCsfGroupTypeReports *Uapexlib://resources/StandardApexLibrary/Reports/CsfGroupType.cls#Reports.CsfGroupType2@apexlib://resources/StandardApexLibrary/Reports/CsfGroupType.cls8�
reports.dategranularityDateGranularityReports *[apexlib://resources/StandardApexLibrary/Reports/DateGranularity.cls#Reports.DateGranularity2Capexlib://resources/StandardApexLibrary/Reports/DateGranularity.cls8�
reports.detailcolumnDetailColumnReports *Uapexlib://resources/StandardApexLibrary/Reports/DetailColumn.cls#Reports.DetailColumn2@apexlib://resources/StandardApexLibrary/Reports/DetailColumn.cls8�
reports.dimension	DimensionReports *Oapexlib://resources/StandardApexLibrary/Reports/Dimension.cls#Reports.Dimension2=apexlib://resources/StandardApexLibrary/Reports/Dimension.cls8�
reports.evaluatedconditionEvaluatedConditionReports *aapexlib://resources/StandardApexLibrary/Reports/EvaluatedCondition.cls#Reports.EvaluatedCondition2Fapexlib://resources/StandardApexLibrary/Reports/EvaluatedCondition.cls8�
"reports.evaluatedconditionoperatorEvaluatedConditionOperatorReports *qapexlib://resources/StandardApexLibrary/Reports/EvaluatedConditionOperator.cls#Reports.EvaluatedConditionOperator2Napexlib://resources/StandardApexLibrary/Reports/EvaluatedConditionOperator.cls8�
$reports.featurenotsupportedexceptionFeatureNotSupportedExceptionReports *uapexlib://resources/StandardApexLibrary/Reports/FeatureNotSupportedException.cls#Reports.FeatureNotSupportedException2Papexlib://resources/StandardApexLibrary/Reports/FeatureNotSupportedException.cls8�
reports.filteroperatorFilterOperatorReports *Yapexlib://resources/StandardApexLibrary/Reports/FilterOperator.cls#Reports.FilterOperator2Bapexlib://resources/StandardApexLibrary/Reports/FilterOperator.cls8�
reports.filtervalueFilterValueReports *Sapexlib://resources/StandardApexLibrary/Reports/FilterValue.cls#Reports.FilterValue2?apexlib://resources/StandardApexLibrary/Reports/FilterValue.cls8�
reports.formulatypeFormulaTypeReports *Sapexlib://resources/StandardApexLibrary/Reports/FormulaType.cls#Reports.FormulaType2?apexlib://resources/StandardApexLibrary/Reports/FormulaType.cls8�
reports.groupingcolumnGroupingColumnReports *Yapexlib://resources/StandardApexLibrary/Reports/GroupingColumn.cls#Reports.GroupingColumn2Bapexlib://resources/StandardApexLibrary/Reports/GroupingColumn.cls8�
reports.groupinginfoGroupingInfoReports *Uapexlib://resources/StandardApexLibrary/Reports/GroupingInfo.cls#Reports.GroupingInfo2@apexlib://resources/StandardApexLibrary/Reports/GroupingInfo.cls8�
reports.groupingvalueGroupingValueReports *Wapexlib://resources/StandardApexLibrary/Reports/GroupingValue.cls#Reports.GroupingValue2Aapexlib://resources/StandardApexLibrary/Reports/GroupingValue.cls8�
reports.instanceaccessexceptionInstanceAccessExceptionReports *kapexlib://resources/StandardApexLibrary/Reports/InstanceAccessException.cls#Reports.InstanceAccessException2Kapexlib://resources/StandardApexLibrary/Reports/InstanceAccessException.cls8�
reports.invalidfilterexceptionInvalidFilterExceptionReports *iapexlib://resources/StandardApexLibrary/Reports/InvalidFilterException.cls#Reports.InvalidFilterException2Japexlib://resources/StandardApexLibrary/Reports/InvalidFilterException.cls8�
&reports.invalidreportmetadataexceptionInvalidReportMetadataExceptionReports *yapexlib://resources/StandardApexLibrary/Reports/InvalidReportMetadataException.cls#Reports.InvalidReportMetadataException2Rapexlib://resources/StandardApexLibrary/Reports/InvalidReportMetadataException.cls8�
$reports.invalidsnapshotdateexceptionInvalidSnapshotDateExceptionReports *uapexlib://resources/StandardApexLibrary/Reports/InvalidSnapshotDateException.cls#Reports.InvalidSnapshotDateException2Papexlib://resources/StandardApexLibrary/Reports/InvalidSnapshotDateException.cls8�
reports.metadataexceptionMetadataExceptionReports *_apexlib://resources/StandardApexLibrary/Reports/MetadataException.cls#Reports.MetadataException2Eapexlib://resources/StandardApexLibrary/Reports/MetadataException.cls8�
reports.notificationactionNotificationActionReports *aapexlib://resources/StandardApexLibrary/Reports/NotificationAction.cls#Reports.NotificationAction2Fapexlib://resources/StandardApexLibrary/Reports/NotificationAction.cls8�
!reports.notificationactioncontextNotificationActionContextReports *oapexlib://resources/StandardApexLibrary/Reports/NotificationActionContext.cls#Reports.NotificationActionContext2Mapexlib://resources/StandardApexLibrary/Reports/NotificationActionContext.cls8�
reports.reportcsf	ReportCsfReports *Oapexlib://resources/StandardApexLibrary/Reports/ReportCsf.cls#Reports.ReportCsf2=apexlib://resources/StandardApexLibrary/Reports/ReportCsf.cls8�
reports.reportcurrencyReportCurrencyReports *Yapexlib://resources/StandardApexLibrary/Reports/ReportCurrency.cls#Reports.ReportCurrency2Bapexlib://resources/StandardApexLibrary/Reports/ReportCurrency.cls8�
reports.reportdatacellReportDataCellReports *Yapexlib://resources/StandardApexLibrary/Reports/ReportDataCell.cls#Reports.ReportDataCell2Bapexlib://resources/StandardApexLibrary/Reports/ReportDataCell.cls8�
reports.reportdescriberesultReportDescribeResultReports *eapexlib://resources/StandardApexLibrary/Reports/ReportDescribeResult.cls#Reports.ReportDescribeResult2Hapexlib://resources/StandardApexLibrary/Reports/ReportDescribeResult.cls8�
reports.reportdetailrowReportDetailRowReports *[apexlib://resources/StandardApexLibrary/Reports/ReportDetailRow.cls#Reports.ReportDetailRow2Capexlib://resources/StandardApexLibrary/Reports/ReportDetailRow.cls8�
reports.reportdivisioninfoReportDivisionInfoReports *aapexlib://resources/StandardApexLibrary/Reports/ReportDivisionInfo.cls#Reports.ReportDivisionInfo2Fapexlib://resources/StandardApexLibrary/Reports/ReportDivisionInfo.cls8�
reports.reportextendedmetadataReportExtendedMetadataReports *iapexlib://resources/StandardApexLibrary/Reports/ReportExtendedMetadata.cls#Reports.ReportExtendedMetadata2Japexlib://resources/StandardApexLibrary/Reports/ReportExtendedMetadata.cls8�
reports.reportfact
ReportFactReports *Qapexlib://resources/StandardApexLibrary/Reports/ReportFact.cls#Reports.ReportFact2>apexlib://resources/StandardApexLibrary/Reports/ReportFact.cls8�
reports.reportfactwithdetailsReportFactWithDetailsReports *gapexlib://resources/StandardApexLibrary/Reports/ReportFactWithDetails.cls#Reports.ReportFactWithDetails2Iapexlib://resources/StandardApexLibrary/Reports/ReportFactWithDetails.cls8�
reports.reportfactwithsummariesReportFactWithSummariesReports *kapexlib://resources/StandardApexLibrary/Reports/ReportFactWithSummaries.cls#Reports.ReportFactWithSummaries2Kapexlib://resources/StandardApexLibrary/Reports/ReportFactWithSummaries.cls8�
reports.reportfilterReportFilterReports *Uapexlib://resources/StandardApexLibrary/Reports/ReportFilter.cls#Reports.ReportFilter2@apexlib://resources/StandardApexLibrary/Reports/ReportFilter.cls8�
reports.reportfiltertypeReportFilterTypeReports *]apexlib://resources/StandardApexLibrary/Reports/ReportFilterType.cls#Reports.ReportFilterType2Dapexlib://resources/StandardApexLibrary/Reports/ReportFilterType.cls8�
reports.reportformatReportFormatReports *Uapexlib://resources/StandardApexLibrary/Reports/ReportFormat.cls#Reports.ReportFormat2@apexlib://resources/StandardApexLibrary/Reports/ReportFormat.cls8�
reports.reportinstanceReportInstanceReports *Yapexlib://resources/StandardApexLibrary/Reports/ReportInstance.cls#Reports.ReportInstance2Bapexlib://resources/StandardApexLibrary/Reports/ReportInstance.cls8�
reports.reportmanagerReportManagerReports *Wapexlib://resources/StandardApexLibrary/Reports/ReportManager.cls#Reports.ReportManager2Aapexlib://resources/StandardApexLibrary/Reports/ReportManager.cls8�
reports.reportmetadataReportMetadataReports *Yapexlib://resources/StandardApexLibrary/Reports/ReportMetadata.cls#Reports.ReportMetadata2Bapexlib://resources/StandardApexLibrary/Reports/ReportMetadata.cls8�
reports.reportresultsReportResultsReports *Wapexlib://resources/StandardApexLibrary/Reports/ReportResults.cls#Reports.ReportResults2Aapexlib://resources/StandardApexLibrary/Reports/ReportResults.cls8�
reports.reportrunexceptionReportRunExceptionReports *aapexlib://resources/StandardApexLibrary/Reports/ReportRunException.cls#Reports.ReportRunException2Fapexlib://resources/StandardApexLibrary/Reports/ReportRunException.cls8�
reports.reportscopeinfoReportScopeInfoReports *[apexlib://resources/StandardApexLibrary/Reports/ReportScopeInfo.cls#Reports.ReportScopeInfo2Capexlib://resources/StandardApexLibrary/Reports/ReportScopeInfo.cls8�
reports.reportscopevalueReportScopeValueReports *]apexlib://resources/StandardApexLibrary/Reports/ReportScopeValue.cls#Reports.ReportScopeValue2Dapexlib://resources/StandardApexLibrary/Reports/ReportScopeValue.cls8�
reports.reporttype
ReportTypeReports *Qapexlib://resources/StandardApexLibrary/Reports/ReportType.cls#Reports.ReportType2>apexlib://resources/StandardApexLibrary/Reports/ReportType.cls8�
reports.reporttypecolumnReportTypeColumnReports *]apexlib://resources/StandardApexLibrary/Reports/ReportTypeColumn.cls#Reports.ReportTypeColumn2Dapexlib://resources/StandardApexLibrary/Reports/ReportTypeColumn.cls8�
 reports.reporttypecolumncategoryReportTypeColumnCategoryReports *mapexlib://resources/StandardApexLibrary/Reports/ReportTypeColumnCategory.cls#Reports.ReportTypeColumnCategory2Lapexlib://resources/StandardApexLibrary/Reports/ReportTypeColumnCategory.cls8�
reports.reporttypemetadataReportTypeMetadataReports *aapexlib://resources/StandardApexLibrary/Reports/ReportTypeMetadata.cls#Reports.ReportTypeMetadata2Fapexlib://resources/StandardApexLibrary/Reports/ReportTypeMetadata.cls8�
reports.sortcolumn
SortColumnReports *Qapexlib://resources/StandardApexLibrary/Reports/SortColumn.cls#Reports.SortColumn2>apexlib://resources/StandardApexLibrary/Reports/SortColumn.cls8�
reports.standarddatefilterStandardDateFilterReports *aapexlib://resources/StandardApexLibrary/Reports/StandardDateFilter.cls#Reports.StandardDateFilter2Fapexlib://resources/StandardApexLibrary/Reports/StandardDateFilter.cls8�
"reports.standarddatefilterdurationStandardDateFilterDurationReports *qapexlib://resources/StandardApexLibrary/Reports/StandardDateFilterDuration.cls#Reports.StandardDateFilterDuration2Napexlib://resources/StandardApexLibrary/Reports/StandardDateFilterDuration.cls8�
'reports.standarddatefilterdurationgroupStandardDateFilterDurationGroupReports *{apexlib://resources/StandardApexLibrary/Reports/StandardDateFilterDurationGroup.cls#Reports.StandardDateFilterDurationGroup2Sapexlib://resources/StandardApexLibrary/Reports/StandardDateFilterDurationGroup.cls8�
reports.standardfilterStandardFilterReports *Yapexlib://resources/StandardApexLibrary/Reports/StandardFilter.cls#Reports.StandardFilter2Bapexlib://resources/StandardApexLibrary/Reports/StandardFilter.cls8�
reports.standardfilterinfoStandardFilterInfoReports *aapexlib://resources/StandardApexLibrary/Reports/StandardFilterInfo.cls#Reports.StandardFilterInfo2Fapexlib://resources/StandardApexLibrary/Reports/StandardFilterInfo.cls8�
"reports.standardfilterinfopicklistStandardFilterInfoPicklistReports *qapexlib://resources/StandardApexLibrary/Reports/StandardFilterInfoPicklist.cls#Reports.StandardFilterInfoPicklist2Napexlib://resources/StandardApexLibrary/Reports/StandardFilterInfoPicklist.cls8�
reports.standardfiltertypeStandardFilterTypeReports *aapexlib://resources/StandardApexLibrary/Reports/StandardFilterType.cls#Reports.StandardFilterType2Fapexlib://resources/StandardApexLibrary/Reports/StandardFilterType.cls8�
reports.summaryvalueSummaryValueReports *Uapexlib://resources/StandardApexLibrary/Reports/SummaryValue.cls#Reports.SummaryValue2@apexlib://resources/StandardApexLibrary/Reports/SummaryValue.cls8�
reports.thresholdinformationThresholdInformationReports *eapexlib://resources/StandardApexLibrary/Reports/ThresholdInformation.cls#Reports.ThresholdInformation2Hapexlib://resources/StandardApexLibrary/Reports/ThresholdInformation.cls8�
reports.toprowsTopRowsReports *Kapexlib://resources/StandardApexLibrary/Reports/TopRows.cls#Reports.TopRows2;apexlib://resources/StandardApexLibrary/Reports/TopRows.cls8�
%reports.unsupportedoperationexceptionUnsupportedOperationExceptionReports *wapexlib://resources/StandardApexLibrary/Reports/UnsupportedOperationException.cls#Reports.UnsupportedOperationException2Qapexlib://resources/StandardApexLibrary/Reports/UnsupportedOperationException.cls8�
richmessaging.abstracttimingAbstractTimingRichMessaging *eapexlib://resources/StandardApexLibrary/RichMessaging/AbstractTiming.cls#RichMessaging.AbstractTiming2Hapexlib://resources/StandardApexLibrary/RichMessaging/AbstractTiming.cls8�
 richmessaging.addressablecontactAddressableContactRichMessaging *mapexlib://resources/StandardApexLibrary/RichMessaging/AddressableContact.cls#RichMessaging.AddressableContact2Lapexlib://resources/StandardApexLibrary/RichMessaging/AddressableContact.cls8�
 richmessaging.authrequesthandlerAuthRequestHandlerRichMessaging *mapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestHandler.cls#RichMessaging.AuthRequestHandler2Lapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestHandler.cls8�
!richmessaging.authrequestresponseAuthRequestResponseRichMessaging *oapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestResponse.cls#RichMessaging.AuthRequestResponse2Mapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestResponse.cls8�
richmessaging.authrequestresultAuthRequestResultRichMessaging *kapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestResult.cls#RichMessaging.AuthRequestResult2Kapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestResult.cls8�
%richmessaging.authrequestresultstatusAuthRequestResultStatusRichMessaging *wapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestResultStatus.cls#RichMessaging.AuthRequestResultStatus2Qapexlib://resources/StandardApexLibrary/RichMessaging/AuthRequestResultStatus.cls8�
richmessaging.deferredtimingDeferredTimingRichMessaging *eapexlib://resources/StandardApexLibrary/RichMessaging/DeferredTiming.cls#RichMessaging.DeferredTiming2Hapexlib://resources/StandardApexLibrary/RichMessaging/DeferredTiming.cls8�
-richmessaging.messagedefinitioninputparameterMessageDefinitionInputParameterRichMessaging *�apexlib://resources/StandardApexLibrary/RichMessaging/MessageDefinitionInputParameter.cls#RichMessaging.MessageDefinitionInputParameter2Yapexlib://resources/StandardApexLibrary/RichMessaging/MessageDefinitionInputParameter.cls8�
richmessaging.paymentitemstatusPaymentItemStatusRichMessaging *kapexlib://resources/StandardApexLibrary/RichMessaging/PaymentItemStatus.cls#RichMessaging.PaymentItemStatus2Kapexlib://resources/StandardApexLibrary/RichMessaging/PaymentItemStatus.cls8�
richmessaging.paymentlineitemPaymentLineItemRichMessaging *gapexlib://resources/StandardApexLibrary/RichMessaging/PaymentLineItem.cls#RichMessaging.PaymentLineItem2Iapexlib://resources/StandardApexLibrary/RichMessaging/PaymentLineItem.cls8�
richmessaging.paymentmethodPaymentMethodRichMessaging *capexlib://resources/StandardApexLibrary/RichMessaging/PaymentMethod.cls#RichMessaging.PaymentMethod2Gapexlib://resources/StandardApexLibrary/RichMessaging/PaymentMethod.cls8�
richmessaging.postaladdressPostalAddressRichMessaging *capexlib://resources/StandardApexLibrary/RichMessaging/PostalAddress.cls#RichMessaging.PostalAddress2Gapexlib://resources/StandardApexLibrary/RichMessaging/PostalAddress.cls8�
 richmessaging.processformhandlerProcessFormHandlerRichMessaging *mapexlib://resources/StandardApexLibrary/RichMessaging/ProcessFormHandler.cls#RichMessaging.ProcessFormHandler2Lapexlib://resources/StandardApexLibrary/RichMessaging/ProcessFormHandler.cls8�
#richmessaging.processpaymenthandlerProcessPaymentHandlerRichMessaging *sapexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentHandler.cls#RichMessaging.ProcessPaymentHandler2Oapexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentHandler.cls8�
#richmessaging.processpaymentrequestProcessPaymentRequestRichMessaging *sapexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentRequest.cls#RichMessaging.ProcessPaymentRequest2Oapexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentRequest.cls8�
"richmessaging.processpaymentresultProcessPaymentResultRichMessaging *qapexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentResult.cls#RichMessaging.ProcessPaymentResult2Napexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentResult.cls8�
(richmessaging.processpaymentresultstatusProcessPaymentResultStatusRichMessaging *}apexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentResultStatus.cls#RichMessaging.ProcessPaymentResultStatus2Tapexlib://resources/StandardApexLibrary/RichMessaging/ProcessPaymentResultStatus.cls8�
richmessaging.recurringtimingRecurringTimingRichMessaging *gapexlib://resources/StandardApexLibrary/RichMessaging/RecurringTiming.cls#RichMessaging.RecurringTiming2Iapexlib://resources/StandardApexLibrary/RichMessaging/RecurringTiming.cls8�
richmessaging.shippingmethodShippingMethodRichMessaging *eapexlib://resources/StandardApexLibrary/RichMessaging/ShippingMethod.cls#RichMessaging.ShippingMethod2Hapexlib://resources/StandardApexLibrary/RichMessaging/ShippingMethod.cls8�
richmessaging.timeslotoptionTimeSlotOptionRichMessaging *eapexlib://resources/StandardApexLibrary/RichMessaging/TimeSlotOption.cls#RichMessaging.TimeSlotOption2Hapexlib://resources/StandardApexLibrary/RichMessaging/TimeSlotOption.cls8�
 richmessaging.timingintervalunitTimingIntervalUnitRichMessaging *mapexlib://resources/StandardApexLibrary/RichMessaging/TimingIntervalUnit.cls#RichMessaging.TimingIntervalUnit2Lapexlib://resources/StandardApexLibrary/RichMessaging/TimingIntervalUnit.cls8�
richmessaging.timingtype
TimingTypeRichMessaging *]apexlib://resources/StandardApexLibrary/RichMessaging/TimingType.cls#RichMessaging.TimingType2Dapexlib://resources/StandardApexLibrary/RichMessaging/TimingType.cls8�
schema.childrelationshipChildRelationshipSchema *]apexlib://resources/StandardApexLibrary/Schema/ChildRelationship.cls#Schema.ChildRelationship2Dapexlib://resources/StandardApexLibrary/Schema/ChildRelationship.cls8�
schema.datacategoryDataCategorySchema *Sapexlib://resources/StandardApexLibrary/Schema/DataCategory.cls#Schema.DataCategory2?apexlib://resources/StandardApexLibrary/Schema/DataCategory.cls8�
'schema.datacategorygroupsobjecttypepair DataCategoryGroupSobjectTypePairSchema *{apexlib://resources/StandardApexLibrary/Schema/DataCategoryGroupSobjectTypePair.cls#Schema.DataCategoryGroupSobjectTypePair2Sapexlib://resources/StandardApexLibrary/Schema/DataCategoryGroupSobjectTypePair.cls8�
schema.describecolorresultDescribeColorResultSchema *aapexlib://resources/StandardApexLibrary/Schema/DescribeColorResult.cls#Schema.DescribeColorResult2Fapexlib://resources/StandardApexLibrary/Schema/DescribeColorResult.cls8�
&schema.describedatacategorygroupresultDescribeDataCategoryGroupResultSchema *yapexlib://resources/StandardApexLibrary/Schema/DescribeDataCategoryGroupResult.cls#Schema.DescribeDataCategoryGroupResult2Rapexlib://resources/StandardApexLibrary/Schema/DescribeDataCategoryGroupResult.cls8�
/schema.describedatacategorygroupstructureresult(DescribeDataCategoryGroupStructureResultSchema *�apexlib://resources/StandardApexLibrary/Schema/DescribeDataCategoryGroupStructureResult.cls#Schema.DescribeDataCategoryGroupStructureResult2[apexlib://resources/StandardApexLibrary/Schema/DescribeDataCategoryGroupStructureResult.cls8�
schema.describefieldresultDescribeFieldResultSchema *aapexlib://resources/StandardApexLibrary/Schema/DescribeFieldResult.cls#Schema.DescribeFieldResult2Fapexlib://resources/StandardApexLibrary/Schema/DescribeFieldResult.cls8�
schema.describeiconresultDescribeIconResultSchema *_apexlib://resources/StandardApexLibrary/Schema/DescribeIconResult.cls#Schema.DescribeIconResult2Eapexlib://resources/StandardApexLibrary/Schema/DescribeIconResult.cls8�
schema.describesobjectresultDescribeSObjectResultSchema *eapexlib://resources/StandardApexLibrary/Schema/DescribeSObjectResult.cls#Schema.DescribeSObjectResult2Hapexlib://resources/StandardApexLibrary/Schema/DescribeSObjectResult.cls8�
schema.describetabresultDescribeTabResultSchema *]apexlib://resources/StandardApexLibrary/Schema/DescribeTabResult.cls#Schema.DescribeTabResult2Dapexlib://resources/StandardApexLibrary/Schema/DescribeTabResult.cls8�
schema.describetabsetresultDescribeTabSetResultSchema *capexlib://resources/StandardApexLibrary/Schema/DescribeTabSetResult.cls#Schema.DescribeTabSetResult2Gapexlib://resources/StandardApexLibrary/Schema/DescribeTabSetResult.cls8�
schema.displaytypeDisplayTypeSchema *Qapexlib://resources/StandardApexLibrary/Schema/DisplayType.cls#Schema.DisplayType2>apexlib://resources/StandardApexLibrary/Schema/DisplayType.cls8�
schema.fielddescribeoptionsFieldDescribeOptionsSchema *capexlib://resources/StandardApexLibrary/Schema/FieldDescribeOptions.cls#Schema.FieldDescribeOptions2Gapexlib://resources/StandardApexLibrary/Schema/FieldDescribeOptions.cls8�
schema.fieldsetFieldSetSchema *Kapexlib://resources/StandardApexLibrary/Schema/FieldSet.cls#Schema.FieldSet2;apexlib://resources/StandardApexLibrary/Schema/FieldSet.cls8�
schema.fieldsetmemberFieldSetMemberSchema *Wapexlib://resources/StandardApexLibrary/Schema/FieldSetMember.cls#Schema.FieldSetMember2Aapexlib://resources/StandardApexLibrary/Schema/FieldSetMember.cls8�
schema.picklistentryPicklistEntrySchema *Uapexlib://resources/StandardApexLibrary/Schema/PicklistEntry.cls#Schema.PicklistEntry2@apexlib://resources/StandardApexLibrary/Schema/PicklistEntry.cls8�
schema.recordtypeinfoRecordTypeInfoSchema *Wapexlib://resources/StandardApexLibrary/Schema/RecordTypeInfo.cls#Schema.RecordTypeInfo2Aapexlib://resources/StandardApexLibrary/Schema/RecordTypeInfo.cls8�
schema.sobjectdescribeoptionsSObjectDescribeOptionsSchema *gapexlib://resources/StandardApexLibrary/Schema/SObjectDescribeOptions.cls#Schema.SObjectDescribeOptions2Iapexlib://resources/StandardApexLibrary/Schema/SObjectDescribeOptions.cls8�
schema.sobjectfieldSObjectFieldSchema *Sapexlib://resources/StandardApexLibrary/Schema/SObjectField.cls#Schema.SObjectField2?apexlib://resources/StandardApexLibrary/Schema/SObjectField.cls8�
schema.sobjecttypeSObjectTypeSchema *Qapexlib://resources/StandardApexLibrary/Schema/SObjectType.cls#Schema.SObjectType2>apexlib://resources/StandardApexLibrary/Schema/SObjectType.cls8�
schema.soaptypeSOAPTypeSchema *Kapexlib://resources/StandardApexLibrary/Schema/SoapType.cls#Schema.SOAPType2;apexlib://resources/StandardApexLibrary/Schema/SoapType.cls8�
 search.knowledgesuggestionfilterKnowledgeSuggestionFilterSearch *mapexlib://resources/StandardApexLibrary/Search/KnowledgeSuggestionFilter.cls#Search.KnowledgeSuggestionFilter2Lapexlib://resources/StandardApexLibrary/Search/KnowledgeSuggestionFilter.cls8�
search.questionsuggestionfilterQuestionSuggestionFilterSearch *kapexlib://resources/StandardApexLibrary/Search/QuestionSuggestionFilter.cls#Search.QuestionSuggestionFilter2Kapexlib://resources/StandardApexLibrary/Search/QuestionSuggestionFilter.cls8�
search.searchresultSearchResultSearch *Sapexlib://resources/StandardApexLibrary/Search/SearchResult.cls#Search.SearchResult2?apexlib://resources/StandardApexLibrary/Search/SearchResult.cls8�
search.searchresultsSearchResultsSearch *Uapexlib://resources/StandardApexLibrary/Search/SearchResults.cls#Search.SearchResults2@apexlib://resources/StandardApexLibrary/Search/SearchResults.cls8�
search.suggestionoptionSuggestionOptionSearch *[apexlib://resources/StandardApexLibrary/Search/SuggestionOption.cls#Search.SuggestionOption2Capexlib://resources/StandardApexLibrary/Search/SuggestionOption.cls8�
search.suggestionresultSuggestionResultSearch *[apexlib://resources/StandardApexLibrary/Search/SuggestionResult.cls#Search.SuggestionResult2Capexlib://resources/StandardApexLibrary/Search/SuggestionResult.cls8�
search.suggestionresultsSuggestionResultsSearch *]apexlib://resources/StandardApexLibrary/Search/SuggestionResults.cls#Search.SuggestionResults2Dapexlib://resources/StandardApexLibrary/Search/SuggestionResults.cls8�
sfc.contentdownloadcontextContentDownloadContextSfc *aapexlib://resources/StandardApexLibrary/Sfc/ContentDownloadContext.cls#Sfc.ContentDownloadContext2Fapexlib://resources/StandardApexLibrary/Sfc/ContentDownloadContext.cls8�
sfc.contentdownloadhandlerContentDownloadHandlerSfc *aapexlib://resources/StandardApexLibrary/Sfc/ContentDownloadHandler.cls#Sfc.ContentDownloadHandler2Fapexlib://resources/StandardApexLibrary/Sfc/ContentDownloadHandler.cls8�
!sfc.contentdownloadhandlerfactoryContentDownloadHandlerFactorySfc *oapexlib://resources/StandardApexLibrary/Sfc/ContentDownloadHandlerFactory.cls#Sfc.ContentDownloadHandlerFactory2Mapexlib://resources/StandardApexLibrary/Sfc/ContentDownloadHandlerFactory.cls8�
 sfdc_checkout.asynccartprocessorAsyncCartProcessorSfdc_Checkout *mapexlib://resources/StandardApexLibrary/Sfdc_Checkout/AsyncCartProcessor.cls#Sfdc_Checkout.AsyncCartProcessor2Lapexlib://resources/StandardApexLibrary/Sfdc_Checkout/AsyncCartProcessor.cls8�
#sfdc_checkout.b2bcheckoutcontrollerB2BCheckoutControllerSfdc_Checkout *sapexlib://resources/StandardApexLibrary/Sfdc_Checkout/B2BCheckoutController.cls#Sfdc_Checkout.B2BCheckoutController2Oapexlib://resources/StandardApexLibrary/Sfdc_Checkout/B2BCheckoutController.cls8�
sfdc_checkout.integrationinfoIntegrationInfoSfdc_Checkout *gapexlib://resources/StandardApexLibrary/Sfdc_Checkout/IntegrationInfo.cls#Sfdc_Checkout.IntegrationInfo2Iapexlib://resources/StandardApexLibrary/Sfdc_Checkout/IntegrationInfo.cls8�
sfdc_checkout.integrationstatusIntegrationStatusSfdc_Checkout *kapexlib://resources/StandardApexLibrary/Sfdc_Checkout/IntegrationStatus.cls#Sfdc_Checkout.IntegrationStatus2Kapexlib://resources/StandardApexLibrary/Sfdc_Checkout/IntegrationStatus.cls8�
sfdc_checkout.statusStatusSfdc_Checkout *Uapexlib://resources/StandardApexLibrary/Sfdc_Checkout/Status.cls#Sfdc_Checkout.Status2@apexlib://resources/StandardApexLibrary/Sfdc_Checkout/Status.cls8�
"sfdc_enablement.learningevaluationLearningEvaluationSfdc_Enablement *qapexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningEvaluation.cls#Sfdc_Enablement.LearningEvaluation2Napexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningEvaluation.cls8�
(sfdc_enablement.learningevaluationresultLearningEvaluationResultSfdc_Enablement *}apexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningEvaluationResult.cls#Sfdc_Enablement.LearningEvaluationResult2Tapexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningEvaluationResult.cls8�
-sfdc_enablement.learningitemevaluationhandlerLearningItemEvaluationHandlerSfdc_Enablement *�apexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningItemEvaluationHandler.cls#Sfdc_Enablement.LearningItemEvaluationHandler2Yapexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningItemEvaluationHandler.cls8�
*sfdc_enablement.learningitemprogressstatusLearningItemProgressStatusSfdc_Enablement *�apexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningItemProgressStatus.cls#Sfdc_Enablement.LearningItemProgressStatus2Vapexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningItemProgressStatus.cls8�
1sfdc_enablement.learningitemserializedeserializer!LearningItemSerializeDeserializerSfdc_Enablement *�apexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningItemSerializeDeserializer.cls#Sfdc_Enablement.LearningItemSerializeDeserializer2]apexlib://resources/StandardApexLibrary/Sfdc_Enablement/LearningItemSerializeDeserializer.cls8�
 site.externalusercreateexceptionExternalUserCreateExceptionSite *mapexlib://resources/StandardApexLibrary/Site/ExternalUserCreateException.cls#Site.ExternalUserCreateException2Lapexlib://resources/StandardApexLibrary/Site/ExternalUserCreateException.cls8�
site.urlrewriterUrlRewriterSite *Mapexlib://resources/StandardApexLibrary/Site/UrlRewriter.cls#Site.UrlRewriter2<apexlib://resources/StandardApexLibrary/Site/UrlRewriter.cls8�
slack.actionActionSlack *Eapexlib://resources/StandardApexLibrary/Slack/Action.cls#Slack.Action28apexlib://resources/StandardApexLibrary/Slack/Action.cls8�
	slack.appAppSlack *?apexlib://resources/StandardApexLibrary/Slack/App.cls#Slack.App25apexlib://resources/StandardApexLibrary/Slack/App.cls8�
slack.appclient	AppClientSlack *Kapexlib://resources/StandardApexLibrary/Slack/AppClient.cls#Slack.AppClient2;apexlib://resources/StandardApexLibrary/Slack/AppClient.cls8�
slack.apprequest
AppRequestSlack *Mapexlib://resources/StandardApexLibrary/Slack/AppRequest.cls#Slack.AppRequest2<apexlib://resources/StandardApexLibrary/Slack/AppRequest.cls8�

slack.appsAppsSlack *Aapexlib://resources/StandardApexLibrary/Slack/Apps.cls#Slack.Apps26apexlib://resources/StandardApexLibrary/Slack/Apps.cls8�

slack.authAuthSlack *Aapexlib://resources/StandardApexLibrary/Slack/Auth.cls#Slack.Auth26apexlib://resources/StandardApexLibrary/Slack/Auth.cls8�
slack.botclient	BotClientSlack *Kapexlib://resources/StandardApexLibrary/Slack/BotClient.cls#Slack.BotClient2;apexlib://resources/StandardApexLibrary/Slack/BotClient.cls8�
slack.botsinfoBotsInfoSlack *Iapexlib://resources/StandardApexLibrary/Slack/BotsInfo.cls#Slack.BotsInfo2:apexlib://resources/StandardApexLibrary/Slack/BotsInfo.cls8�

slack.callCallSlack *Aapexlib://resources/StandardApexLibrary/Slack/Call.cls#Slack.Call26apexlib://resources/StandardApexLibrary/Slack/Call.cls8�
slack.channelChannelSlack *Gapexlib://resources/StandardApexLibrary/Slack/Channel.cls#Slack.Channel29apexlib://resources/StandardApexLibrary/Slack/Channel.cls8�

slack.chatChatSlack *Aapexlib://resources/StandardApexLibrary/Slack/Chat.cls#Slack.Chat26apexlib://resources/StandardApexLibrary/Slack/Chat.cls8�
slack.conversationConversationSlack *Qapexlib://resources/StandardApexLibrary/Slack/Conversation.cls#Slack.Conversation2>apexlib://resources/StandardApexLibrary/Slack/Conversation.cls8�
	slack.dndDndSlack *?apexlib://resources/StandardApexLibrary/Slack/Dnd.cls#Slack.Dnd25apexlib://resources/StandardApexLibrary/Slack/Dnd.cls8�
slack.emojiEmojiSlack *Capexlib://resources/StandardApexLibrary/Slack/Emoji.cls#Slack.Emoji27apexlib://resources/StandardApexLibrary/Slack/Emoji.cls8�
slack.eventEventSlack *Capexlib://resources/StandardApexLibrary/Slack/Event.cls#Slack.Event27apexlib://resources/StandardApexLibrary/Slack/Event.cls8�
slack.fieldFieldSlack *Capexlib://resources/StandardApexLibrary/Slack/Field.cls#Slack.Field27apexlib://resources/StandardApexLibrary/Slack/Field.cls8�

slack.fileFileSlack *Aapexlib://resources/StandardApexLibrary/Slack/File.cls#Slack.File26apexlib://resources/StandardApexLibrary/Slack/File.cls8�
slack.latestLatestSlack *Eapexlib://resources/StandardApexLibrary/Slack/Latest.cls#Slack.Latest28apexlib://resources/StandardApexLibrary/Slack/Latest.cls8�
slack.messageMessageSlack *Gapexlib://resources/StandardApexLibrary/Slack/Message.cls#Slack.Message29apexlib://resources/StandardApexLibrary/Slack/Message.cls8�
slack.migrationexchangeMigrationExchangeSlack *[apexlib://resources/StandardApexLibrary/Slack/MigrationExchange.cls#Slack.MigrationExchange2Capexlib://resources/StandardApexLibrary/Slack/MigrationExchange.cls8�
slack.modalsModalsSlack *Eapexlib://resources/StandardApexLibrary/Slack/Modals.cls#Slack.Modals28apexlib://resources/StandardApexLibrary/Slack/Modals.cls8�
slack.optionsOptionsSlack *Gapexlib://resources/StandardApexLibrary/Slack/Options.cls#Slack.Options29apexlib://resources/StandardApexLibrary/Slack/Options.cls8�
slack.pagingPagingSlack *Eapexlib://resources/StandardApexLibrary/Slack/Paging.cls#Slack.Paging28apexlib://resources/StandardApexLibrary/Slack/Paging.cls8�
	slack.pinPinSlack *?apexlib://resources/StandardApexLibrary/Slack/Pin.cls#Slack.Pin25apexlib://resources/StandardApexLibrary/Slack/Pin.cls8�
slack.purposePurposeSlack *Gapexlib://resources/StandardApexLibrary/Slack/Purpose.cls#Slack.Purpose29apexlib://resources/StandardApexLibrary/Slack/Purpose.cls8�
slack.reactionReactionSlack *Iapexlib://resources/StandardApexLibrary/Slack/Reaction.cls#Slack.Reaction2:apexlib://resources/StandardApexLibrary/Slack/Reaction.cls8�
slack.reminderReminderSlack *Iapexlib://resources/StandardApexLibrary/Slack/Reminder.cls#Slack.Reminder2:apexlib://resources/StandardApexLibrary/Slack/Reminder.cls8�
slack.requestcontextRequestContextSlack *Uapexlib://resources/StandardApexLibrary/Slack/RequestContext.cls#Slack.RequestContext2@apexlib://resources/StandardApexLibrary/Slack/RequestContext.cls8�
slack.responsemetadataResponseMetadataSlack *Yapexlib://resources/StandardApexLibrary/Slack/ResponseMetadata.cls#Slack.ResponseMetadata2Bapexlib://resources/StandardApexLibrary/Slack/ResponseMetadata.cls8�
slack.runnablehandlerRunnableHandlerSlack *Wapexlib://resources/StandardApexLibrary/Slack/RunnableHandler.cls#Slack.RunnableHandler2Aapexlib://resources/StandardApexLibrary/Slack/RunnableHandler.cls8�
slack.searchSearchSlack *Eapexlib://resources/StandardApexLibrary/Slack/Search.cls#Slack.Search28apexlib://resources/StandardApexLibrary/Slack/Search.cls8�
slack.shortcutShortcutSlack *Iapexlib://resources/StandardApexLibrary/Slack/Shortcut.cls#Slack.Shortcut2:apexlib://resources/StandardApexLibrary/Slack/Shortcut.cls8�
slack.slackcommandSlackCommandSlack *Qapexlib://resources/StandardApexLibrary/Slack/SlackCommand.cls#Slack.SlackCommand2>apexlib://resources/StandardApexLibrary/Slack/SlackCommand.cls8�

slack.starStarSlack *Aapexlib://resources/StandardApexLibrary/Slack/Star.cls#Slack.Star26apexlib://resources/StandardApexLibrary/Slack/Star.cls8�

slack.teamTeamSlack *Aapexlib://resources/StandardApexLibrary/Slack/Team.cls#Slack.Team26apexlib://resources/StandardApexLibrary/Slack/Team.cls8�
slack.testharnessTestHarnessSlack *Oapexlib://resources/StandardApexLibrary/Slack/TestHarness.cls#Slack.TestHarness2=apexlib://resources/StandardApexLibrary/Slack/TestHarness.cls8�
slack.topicTopicSlack *Capexlib://resources/StandardApexLibrary/Slack/Topic.cls#Slack.Topic27apexlib://resources/StandardApexLibrary/Slack/Topic.cls8�

slack.userUserSlack *Aapexlib://resources/StandardApexLibrary/Slack/User.cls#Slack.User26apexlib://resources/StandardApexLibrary/Slack/User.cls8�
slack.userclient
UserClientSlack *Mapexlib://resources/StandardApexLibrary/Slack/UserClient.cls#Slack.UserClient2<apexlib://resources/StandardApexLibrary/Slack/UserClient.cls8�
slack.usermappingUserMappingSlack *Wapexlib://resources/StandardApexLibrary/Slack/UserMapping Service.cls#Slack.UserMapping2Eapexlib://resources/StandardApexLibrary/Slack/UserMapping Service.cls8�
slack.usergroup	UsergroupSlack *Kapexlib://resources/StandardApexLibrary/Slack/Usergroup.cls#Slack.Usergroup2;apexlib://resources/StandardApexLibrary/Slack/Usergroup.cls8�
slack.viewsViewsSlack *Capexlib://resources/StandardApexLibrary/Slack/Views.cls#Slack.Views27apexlib://resources/StandardApexLibrary/Slack/Views.cls8�
slack.workflowWorkflowSlack *Iapexlib://resources/StandardApexLibrary/Slack/Workflow.cls#Slack.Workflow2:apexlib://resources/StandardApexLibrary/Slack/Workflow.cls8�
support.emailtemplateselectorEmailTemplateSelectorSupport *gapexlib://resources/StandardApexLibrary/Support/EmailTemplateSelector.cls#Support.EmailTemplateSelector2Iapexlib://resources/StandardApexLibrary/Support/EmailTemplateSelector.cls8�
&support.milestonetriggertimecalculatorMilestoneTriggerTimeCalculatorSupport *yapexlib://resources/StandardApexLibrary/Support/MilestoneTriggerTimeCalculator.cls#Support.MilestoneTriggerTimeCalculator2Rapexlib://resources/StandardApexLibrary/Support/MilestoneTriggerTimeCalculator.cls8�
system.accesslevelAccessLevelSystem *Qapexlib://resources/StandardApexLibrary/System/AccessLevel.cls#System.AccessLevel2>apexlib://resources/StandardApexLibrary/System/AccessLevel.cls8�
system.accesstype
AccessTypeSystem *Oapexlib://resources/StandardApexLibrary/System/AccessType.cls#System.AccessType2=apexlib://resources/StandardApexLibrary/System/AccessType.cls8�
system.addressAddressSystem *Iapexlib://resources/StandardApexLibrary/System/Address.cls#System.Address2:apexlib://resources/StandardApexLibrary/System/Address.cls8�
system.answersAnswersSystem *Iapexlib://resources/StandardApexLibrary/System/Answers.cls#System.Answers2:apexlib://resources/StandardApexLibrary/System/Answers.cls8�
system.apexpages	ApexPagesSystem *Mapexlib://resources/StandardApexLibrary/System/ApexPages.cls#System.ApexPages2<apexlib://resources/StandardApexLibrary/System/ApexPages.cls8�
system.approvalApprovalSystem *Kapexlib://resources/StandardApexLibrary/System/Approval.cls#System.Approval2;apexlib://resources/StandardApexLibrary/System/Approval.cls8�
system.assertAssertSystem *Gapexlib://resources/StandardApexLibrary/System/Assert.cls#System.Assert29apexlib://resources/StandardApexLibrary/System/Assert.cls8�
system.assertexceptionAssertExceptionSystem *Yapexlib://resources/StandardApexLibrary/System/AssertException.cls#System.AssertException2Bapexlib://resources/StandardApexLibrary/System/AssertException.cls8�
system.asyncexceptionAsyncExceptionSystem *Wapexlib://resources/StandardApexLibrary/System/AsyncException.cls#System.AsyncException2Aapexlib://resources/StandardApexLibrary/System/AsyncException.cls8�
system.asyncinfo	AsyncInfoSystem *Mapexlib://resources/StandardApexLibrary/System/AsyncInfo.cls#System.AsyncInfo2<apexlib://resources/StandardApexLibrary/System/AsyncInfo.cls8�
system.asyncoptionsAsyncOptionsSystem *Sapexlib://resources/StandardApexLibrary/System/AsyncOptions.cls#System.AsyncOptions2?apexlib://resources/StandardApexLibrary/System/AsyncOptions.cls8�
system.auraexceptionAuraExceptionSystem *Uapexlib://resources/StandardApexLibrary/System/AuraException.cls#System.AuraException2@apexlib://resources/StandardApexLibrary/System/AuraException.cls8�
system.aurahandledexceptionAuraHandledExceptionSystem *capexlib://resources/StandardApexLibrary/System/AuraHandledException.cls#System.AuraHandledException2Gapexlib://resources/StandardApexLibrary/System/AuraHandledException.cls8�
system.bigobjectexceptionBigObjectExceptionSystem *_apexlib://resources/StandardApexLibrary/System/BigObjectException.cls#System.BigObjectException2Eapexlib://resources/StandardApexLibrary/System/BigObjectException.cls8�
system.booleanBooleanSystem *Iapexlib://resources/StandardApexLibrary/System/Boolean.cls#System.Boolean2:apexlib://resources/StandardApexLibrary/System/Boolean.cls8�
system.builderBuilderSystem *Iapexlib://resources/StandardApexLibrary/System/Builder.cls#System.Builder2:apexlib://resources/StandardApexLibrary/System/Builder.cls8�
system.businesshoursBusinessHoursSystem *Uapexlib://resources/StandardApexLibrary/System/BusinessHours.cls#System.BusinessHours2@apexlib://resources/StandardApexLibrary/System/BusinessHours.cls8�
system.callableCallableSystem *Kapexlib://resources/StandardApexLibrary/System/Callable.cls#System.Callable2;apexlib://resources/StandardApexLibrary/System/Callable.cls8�
system.callbackstatusCallbackStatusSystem *Wapexlib://resources/StandardApexLibrary/System/CallbackStatus.cls#System.CallbackStatus2Aapexlib://resources/StandardApexLibrary/System/CallbackStatus.cls8�
system.calloutexceptionCalloutExceptionSystem *[apexlib://resources/StandardApexLibrary/System/CalloutException.cls#System.CalloutException2Capexlib://resources/StandardApexLibrary/System/CalloutException.cls8�
system.casesCasesSystem *Eapexlib://resources/StandardApexLibrary/System/Cases.cls#System.Cases28apexlib://resources/StandardApexLibrary/System/Cases.cls8�
system.collatorCollatorSystem *Kapexlib://resources/StandardApexLibrary/System/Collator.cls#System.Collator2;apexlib://resources/StandardApexLibrary/System/Collator.cls8�
system.comparable
ComparableSystem *Oapexlib://resources/StandardApexLibrary/System/Comparable.cls#System.Comparable2=apexlib://resources/StandardApexLibrary/System/Comparable.cls8�
system.comparator
ComparatorSystem *Oapexlib://resources/StandardApexLibrary/System/Comparator.cls#System.Comparator2=apexlib://resources/StandardApexLibrary/System/Comparator.cls8�
system.continuationContinuationSystem *Sapexlib://resources/StandardApexLibrary/System/Continuation.cls#System.Continuation2?apexlib://resources/StandardApexLibrary/System/Continuation.cls8�
system.cookieCookieSystem *Gapexlib://resources/StandardApexLibrary/System/Cookie.cls#System.Cookie29apexlib://resources/StandardApexLibrary/System/Cookie.cls8�
system.cryptoCryptoSystem *Gapexlib://resources/StandardApexLibrary/System/Crypto.cls#System.Crypto29apexlib://resources/StandardApexLibrary/System/Crypto.cls8�
system.dataweavescriptexceptionDataWeaveScriptExceptionSystem *kapexlib://resources/StandardApexLibrary/System/DataWeaveScriptException.cls#System.DataWeaveScriptException2Kapexlib://resources/StandardApexLibrary/System/DataWeaveScriptException.cls8�
system.databaseDatabaseSystem *Kapexlib://resources/StandardApexLibrary/System/Database.cls#System.Database2;apexlib://resources/StandardApexLibrary/System/Database.cls8�
system.dateDateSystem *Capexlib://resources/StandardApexLibrary/System/Date.cls#System.Date27apexlib://resources/StandardApexLibrary/System/Date.cls8�
system.datetimeDatetimeSystem *Kapexlib://resources/StandardApexLibrary/System/Datetime.cls#System.Datetime2;apexlib://resources/StandardApexLibrary/System/Datetime.cls8�
system.decimalDecimalSystem *Iapexlib://resources/StandardApexLibrary/System/Decimal.cls#System.Decimal2:apexlib://resources/StandardApexLibrary/System/Decimal.cls8�
system.dmlexceptionDmlExceptionSystem *Sapexlib://resources/StandardApexLibrary/System/DmlException.cls#System.DmlException2?apexlib://resources/StandardApexLibrary/System/DmlException.cls8�
system.domainDomainSystem *Gapexlib://resources/StandardApexLibrary/System/Domain.cls#System.Domain29apexlib://resources/StandardApexLibrary/System/Domain.cls8�
system.domaincreatorDomainCreatorSystem *Uapexlib://resources/StandardApexLibrary/System/DomainCreator.cls#System.DomainCreator2@apexlib://resources/StandardApexLibrary/System/DomainCreator.cls8�
system.domainparserDomainParserSystem *Sapexlib://resources/StandardApexLibrary/System/DomainParser.cls#System.DomainParser2?apexlib://resources/StandardApexLibrary/System/DomainParser.cls8�
system.domaintype
DomainTypeSystem *Oapexlib://resources/StandardApexLibrary/System/DomainType.cls#System.DomainType2=apexlib://resources/StandardApexLibrary/System/DomainType.cls8�
system.doubleDoubleSystem *Gapexlib://resources/StandardApexLibrary/System/Double.cls#System.Double29apexlib://resources/StandardApexLibrary/System/Double.cls8�
 system.duplicatemessageexceptionDuplicateMessageExceptionSystem *mapexlib://resources/StandardApexLibrary/System/DuplicateMessageException.cls#System.DuplicateMessageException2Lapexlib://resources/StandardApexLibrary/System/DuplicateMessageException.cls8�
system.emailexceptionEmailExceptionSystem *Wapexlib://resources/StandardApexLibrary/System/EmailException.cls#System.EmailException2Aapexlib://resources/StandardApexLibrary/System/EmailException.cls8�
system.emailmessagesEmailMessagesSystem *Uapexlib://resources/StandardApexLibrary/System/EmailMessages.cls#System.EmailMessages2@apexlib://resources/StandardApexLibrary/System/EmailMessages.cls8�
system.encodingutilEncodingUtilSystem *Sapexlib://resources/StandardApexLibrary/System/EncodingUtil.cls#System.EncodingUtil2?apexlib://resources/StandardApexLibrary/System/EncodingUtil.cls8�
system.eventbusEventBusSystem *Kapexlib://resources/StandardApexLibrary/System/EventBus.cls#System.EventBus2;apexlib://resources/StandardApexLibrary/System/EventBus.cls8�
system.externalobjectexceptionExternalObjectExceptionSystem *iapexlib://resources/StandardApexLibrary/System/ExternalObjectException.cls#System.ExternalObjectException2Japexlib://resources/StandardApexLibrary/System/ExternalObjectException.cls8�
system.externalservicetestExternalServiceTestSystem *aapexlib://resources/StandardApexLibrary/System/ExternalServiceTest.cls#System.ExternalServiceTest2Fapexlib://resources/StandardApexLibrary/System/ExternalServiceTest.cls8�
system.fatalcursorexceptionFatalCursorExceptionSystem *capexlib://resources/StandardApexLibrary/System/FatalCursorException.cls#System.FatalCursorException2Gapexlib://resources/StandardApexLibrary/System/FatalCursorException.cls8�
system.featuremanagementFeatureManagementSystem *]apexlib://resources/StandardApexLibrary/System/FeatureManagement.cls#System.FeatureManagement2Dapexlib://resources/StandardApexLibrary/System/FeatureManagement.cls8�
system.finalexceptionFinalExceptionSystem *Wapexlib://resources/StandardApexLibrary/System/FinalException.cls#System.FinalException2Aapexlib://resources/StandardApexLibrary/System/FinalException.cls8�
system.flexqueue	FlexQueueSystem *Mapexlib://resources/StandardApexLibrary/System/FlexQueue.cls#System.FlexQueue2<apexlib://resources/StandardApexLibrary/System/FlexQueue.cls8�
system.flowexceptionFlowExceptionSystem *Uapexlib://resources/StandardApexLibrary/System/FlowException.cls#System.FlowException2@apexlib://resources/StandardApexLibrary/System/FlowException.cls8�
system.formulaFormulaSystem *Iapexlib://resources/StandardApexLibrary/System/Formula.cls#System.Formula2:apexlib://resources/StandardApexLibrary/System/Formula.cls8�
system.formularecalcfielderrorFormulaRecalcFieldErrorSystem *iapexlib://resources/StandardApexLibrary/System/FormulaRecalcFieldError.cls#System.FormulaRecalcFieldError2Japexlib://resources/StandardApexLibrary/System/FormulaRecalcFieldError.cls8�
system.formularecalcresultFormulaRecalcResultSystem *aapexlib://resources/StandardApexLibrary/System/FormulaRecalcResult.cls#System.FormulaRecalcResult2Fapexlib://resources/StandardApexLibrary/System/FormulaRecalcResult.cls8�
system.handledexceptionHandledExceptionSystem *[apexlib://resources/StandardApexLibrary/System/HandledException.cls#System.HandledException2Capexlib://resources/StandardApexLibrary/System/HandledException.cls8�
system.httpHttpSystem *Capexlib://resources/StandardApexLibrary/System/Http.cls#System.Http27apexlib://resources/StandardApexLibrary/System/Http.cls8�
system.httpcalloutmockHttpCalloutMockSystem *Yapexlib://resources/StandardApexLibrary/System/HttpCalloutMock.cls#System.HttpCalloutMock2Bapexlib://resources/StandardApexLibrary/System/HttpCalloutMock.cls8�
system.httprequestHttpRequestSystem *Qapexlib://resources/StandardApexLibrary/System/HttpRequest.cls#System.HttpRequest2>apexlib://resources/StandardApexLibrary/System/HttpRequest.cls8�
system.httpresponseHttpResponseSystem *Sapexlib://resources/StandardApexLibrary/System/HttpResponse.cls#System.HttpResponse2?apexlib://resources/StandardApexLibrary/System/HttpResponse.cls8�
	system.idIdSystem *?apexlib://resources/StandardApexLibrary/System/Id.cls#System.Id25apexlib://resources/StandardApexLibrary/System/Id.cls8�
system.ideasIdeasSystem *Eapexlib://resources/StandardApexLibrary/System/Ideas.cls#System.Ideas28apexlib://resources/StandardApexLibrary/System/Ideas.cls8�
system.illegalargumentexceptionIllegalArgumentExceptionSystem *kapexlib://resources/StandardApexLibrary/System/IllegalArgumentException.cls#System.IllegalArgumentException2Kapexlib://resources/StandardApexLibrary/System/IllegalArgumentException.cls8�
system.installhandlerInstallHandlerSystem *Wapexlib://resources/StandardApexLibrary/System/InstallHandler.cls#System.InstallHandler2Aapexlib://resources/StandardApexLibrary/System/InstallHandler.cls8�
%system.invalidparametervalueexceptionInvalidParameterValueExceptionSystem *wapexlib://resources/StandardApexLibrary/System/InvalidParameterValueException.cls#System.InvalidParameterValueException2Qapexlib://resources/StandardApexLibrary/System/InvalidParameterValueException.cls8�
system.jsonJSONSystem *Capexlib://resources/StandardApexLibrary/System/JSON.cls#System.JSON27apexlib://resources/StandardApexLibrary/System/JSON.cls8�
system.jsonexceptionJSONExceptionSystem *Uapexlib://resources/StandardApexLibrary/System/JSONException.cls#System.JSONException2@apexlib://resources/StandardApexLibrary/System/JSONException.cls8�
system.jsongeneratorJSONGeneratorSystem *Uapexlib://resources/StandardApexLibrary/System/JSONGenerator.cls#System.JSONGenerator2@apexlib://resources/StandardApexLibrary/System/JSONGenerator.cls8�
system.jsonparser
JSONParserSystem *Oapexlib://resources/StandardApexLibrary/System/JSONParser.cls#System.JSONParser2=apexlib://resources/StandardApexLibrary/System/JSONParser.cls8�
system.jsontoken	JSONTokenSystem *Mapexlib://resources/StandardApexLibrary/System/JSONToken.cls#System.JSONToken2<apexlib://resources/StandardApexLibrary/System/JSONToken.cls8�
system.labelLabelSystem *Eapexlib://resources/StandardApexLibrary/System/Label.cls#System.Label28apexlib://resources/StandardApexLibrary/System/Label.cls8�
system.limitexceptionLimitExceptionSystem *Wapexlib://resources/StandardApexLibrary/System/LimitException.cls#System.LimitException2Aapexlib://resources/StandardApexLibrary/System/LimitException.cls8�
system.limitsLimitsSystem *Gapexlib://resources/StandardApexLibrary/System/Limits.cls#System.Limits29apexlib://resources/StandardApexLibrary/System/Limits.cls8�
system.listListSystem *Kapexlib://resources/StandardApexLibrary/System/List.cls#System.unknownClass27apexlib://resources/StandardApexLibrary/System/List.cls8�
system.listexceptionListExceptionSystem *Uapexlib://resources/StandardApexLibrary/System/ListException.cls#System.ListException2@apexlib://resources/StandardApexLibrary/System/ListException.cls8�
system.locationLocationSystem *Kapexlib://resources/StandardApexLibrary/System/Location.cls#System.Location2;apexlib://resources/StandardApexLibrary/System/Location.cls8�
system.logginglevelLoggingLevelSystem *Sapexlib://resources/StandardApexLibrary/System/LoggingLevel.cls#System.LoggingLevel2?apexlib://resources/StandardApexLibrary/System/LoggingLevel.cls8�

system.mapMapSystem *Japexlib://resources/StandardApexLibrary/System/Map.cls#System.unknownClass26apexlib://resources/StandardApexLibrary/System/Map.cls8�
system.matcherMatcherSystem *Iapexlib://resources/StandardApexLibrary/System/Matcher.cls#System.Matcher2:apexlib://resources/StandardApexLibrary/System/Matcher.cls8�
system.mathMathSystem *Capexlib://resources/StandardApexLibrary/System/Math.cls#System.Math27apexlib://resources/StandardApexLibrary/System/Math.cls8�
system.mathexceptionMathExceptionSystem *Uapexlib://resources/StandardApexLibrary/System/MathException.cls#System.MathException2@apexlib://resources/StandardApexLibrary/System/MathException.cls8�
system.messaging	MessagingSystem *Mapexlib://resources/StandardApexLibrary/System/Messaging.cls#System.Messaging2<apexlib://resources/StandardApexLibrary/System/Messaging.cls8�
%system.multistaticresourcecalloutmockMultiStaticResourceCalloutMockSystem *wapexlib://resources/StandardApexLibrary/System/MultiStaticResourceCalloutMock.cls#System.MultiStaticResourceCalloutMock2Qapexlib://resources/StandardApexLibrary/System/MultiStaticResourceCalloutMock.cls8�
system.networkNetworkSystem *Iapexlib://resources/StandardApexLibrary/System/Network.cls#System.Network2:apexlib://resources/StandardApexLibrary/System/Network.cls8�
system.noaccessexceptionNoAccessExceptionSystem *]apexlib://resources/StandardApexLibrary/System/NoAccessException.cls#System.NoAccessException2Dapexlib://resources/StandardApexLibrary/System/NoAccessException.cls8�
system.nodatafoundexceptionNoDataFoundExceptionSystem *capexlib://resources/StandardApexLibrary/System/NoDataFoundException.cls#System.NoDataFoundException2Gapexlib://resources/StandardApexLibrary/System/NoDataFoundException.cls8�
system.nosuchelementexceptionNoSuchElementExceptionSystem *gapexlib://resources/StandardApexLibrary/System/NoSuchElementException.cls#System.NoSuchElementException2Iapexlib://resources/StandardApexLibrary/System/NoSuchElementException.cls8�
system.nullpointerexceptionNullPointerExceptionSystem *capexlib://resources/StandardApexLibrary/System/NullPointerException.cls#System.NullPointerException2Gapexlib://resources/StandardApexLibrary/System/NullPointerException.cls8�
system.orglimitOrgLimitSystem *Kapexlib://resources/StandardApexLibrary/System/OrgLimit.cls#System.OrgLimit2;apexlib://resources/StandardApexLibrary/System/OrgLimit.cls8�
system.orglimits	OrgLimitsSystem *Mapexlib://resources/StandardApexLibrary/System/OrgLimits.cls#System.OrgLimits2<apexlib://resources/StandardApexLibrary/System/OrgLimits.cls8�
system.packaging	PackagingSystem *Mapexlib://resources/StandardApexLibrary/System/Packaging.cls#System.Packaging2<apexlib://resources/StandardApexLibrary/System/Packaging.cls8�
system.pagereferencePageReferenceSystem *Uapexlib://resources/StandardApexLibrary/System/PageReference.cls#System.PageReference2@apexlib://resources/StandardApexLibrary/System/PageReference.cls8�
system.patternPatternSystem *Iapexlib://resources/StandardApexLibrary/System/Pattern.cls#System.Pattern2:apexlib://resources/StandardApexLibrary/System/Pattern.cls8�
system.queryexceptionQueryExceptionSystem *Wapexlib://resources/StandardApexLibrary/System/QueryException.cls#System.QueryException2Aapexlib://resources/StandardApexLibrary/System/QueryException.cls8�
system.queueable	QueueableSystem *Mapexlib://resources/StandardApexLibrary/System/Queueable.cls#System.Queueable2<apexlib://resources/StandardApexLibrary/System/Queueable.cls8�
system.queueablecontextQueueableContextSystem *[apexlib://resources/StandardApexLibrary/System/QueueableContext.cls#System.QueueableContext2Capexlib://resources/StandardApexLibrary/System/QueueableContext.cls8�
"system.queueableduplicatesignatureQueueableDuplicateSignatureSystem *qapexlib://resources/StandardApexLibrary/System/QueueableDuplicateSignature.cls#System.QueueableDuplicateSignature2Napexlib://resources/StandardApexLibrary/System/QueueableDuplicateSignature.cls8�
system.quickactionQuickActionSystem *Qapexlib://resources/StandardApexLibrary/System/QuickAction.cls#System.QuickAction2>apexlib://resources/StandardApexLibrary/System/QuickAction.cls8�
system.quiddityQuidditySystem *Kapexlib://resources/StandardApexLibrary/System/Quiddity.cls#System.Quiddity2;apexlib://resources/StandardApexLibrary/System/Quiddity.cls8�
system.remoteobjectcontrollerRemoteObjectControllerSystem *gapexlib://resources/StandardApexLibrary/System/RemoteObjectController.cls#System.RemoteObjectController2Iapexlib://resources/StandardApexLibrary/System/RemoteObjectController.cls8�
system.requestRequestSystem *Iapexlib://resources/StandardApexLibrary/System/Request.cls#System.Request2:apexlib://resources/StandardApexLibrary/System/Request.cls8�
system.resetpasswordresultResetPasswordResultSystem *aapexlib://resources/StandardApexLibrary/System/ResetPasswordResult.cls#System.ResetPasswordResult2Fapexlib://resources/StandardApexLibrary/System/ResetPasswordResult.cls8�
system.restcontextRestContextSystem *Qapexlib://resources/StandardApexLibrary/System/RestContext.cls#System.RestContext2>apexlib://resources/StandardApexLibrary/System/RestContext.cls8�
system.restrequestRestRequestSystem *Qapexlib://resources/StandardApexLibrary/System/RestRequest.cls#System.RestRequest2>apexlib://resources/StandardApexLibrary/System/RestRequest.cls8�
system.restresponseRestResponseSystem *Sapexlib://resources/StandardApexLibrary/System/RestResponse.cls#System.RestResponse2?apexlib://resources/StandardApexLibrary/System/RestResponse.cls8�
system.sobjectSObjectSystem *Iapexlib://resources/StandardApexLibrary/System/SObject.cls#System.SObject2:apexlib://resources/StandardApexLibrary/System/SObject.cls8�
system.sobjectaccessdecisionSObjectAccessDecisionSystem *eapexlib://resources/StandardApexLibrary/System/SObjectAccessDecision.cls#System.SObjectAccessDecision2Hapexlib://resources/StandardApexLibrary/System/SObjectAccessDecision.cls8�
system.sobjectexceptionSObjectExceptionSystem *[apexlib://resources/StandardApexLibrary/System/SObjectException.cls#System.SObjectException2Capexlib://resources/StandardApexLibrary/System/SObjectException.cls8�
system.sandboxpostcopySandboxPostCopySystem *Yapexlib://resources/StandardApexLibrary/System/SandboxPostCopy.cls#System.SandboxPostCopy2Bapexlib://resources/StandardApexLibrary/System/SandboxPostCopy.cls8�
system.schedulableSchedulableSystem *Qapexlib://resources/StandardApexLibrary/System/Schedulable.cls#System.Schedulable2>apexlib://resources/StandardApexLibrary/System/Schedulable.cls8�
system.schedulablecontextSchedulableContextSystem *_apexlib://resources/StandardApexLibrary/System/SchedulableContext.cls#System.SchedulableContext2Eapexlib://resources/StandardApexLibrary/System/SchedulableContext.cls8�
system.schemaSchemaSystem *Gapexlib://resources/StandardApexLibrary/System/Schema.cls#System.Schema29apexlib://resources/StandardApexLibrary/System/Schema.cls8�
system.searchSearchSystem *Gapexlib://resources/StandardApexLibrary/System/Search.cls#System.Search29apexlib://resources/StandardApexLibrary/System/Search.cls8�
system.searchexceptionSearchExceptionSystem *Yapexlib://resources/StandardApexLibrary/System/SearchException.cls#System.SearchException2Bapexlib://resources/StandardApexLibrary/System/SearchException.cls8�
system.securitySecuritySystem *Kapexlib://resources/StandardApexLibrary/System/Security.cls#System.Security2;apexlib://resources/StandardApexLibrary/System/Security.cls8�
system.securityexceptionSecurityExceptionSystem *]apexlib://resources/StandardApexLibrary/System/SecurityException.cls#System.SecurityException2Dapexlib://resources/StandardApexLibrary/System/SecurityException.cls8�
system.selectoptionSelectOptionSystem *Sapexlib://resources/StandardApexLibrary/System/SelectOption.cls#System.SelectOption2?apexlib://resources/StandardApexLibrary/System/SelectOption.cls8�
system.serializationexceptionSerializationExceptionSystem *gapexlib://resources/StandardApexLibrary/System/SerializationException.cls#System.SerializationException2Iapexlib://resources/StandardApexLibrary/System/SerializationException.cls8�

system.setSetSystem *Aapexlib://resources/StandardApexLibrary/System/Set.cls#System.Set26apexlib://resources/StandardApexLibrary/System/Set.cls8�
system.siteSiteSystem *Capexlib://resources/StandardApexLibrary/System/Site.cls#System.Site27apexlib://resources/StandardApexLibrary/System/Site.cls8�
system.soqlstubproviderSoqlStubProviderSystem *[apexlib://resources/StandardApexLibrary/System/SoqlStubProvider.cls#System.SoqlStubProvider2Capexlib://resources/StandardApexLibrary/System/SoqlStubProvider.cls8�
 system.staticresourcecalloutmockStaticResourceCalloutMockSystem *mapexlib://resources/StandardApexLibrary/System/StaticResourceCalloutMock.cls#System.StaticResourceCalloutMock2Lapexlib://resources/StandardApexLibrary/System/StaticResourceCalloutMock.cls8�
system.stringStringSystem *Gapexlib://resources/StandardApexLibrary/System/String.cls#System.String29apexlib://resources/StandardApexLibrary/System/String.cls8�
system.stringexceptionStringExceptionSystem *Yapexlib://resources/StandardApexLibrary/System/StringException.cls#System.StringException2Bapexlib://resources/StandardApexLibrary/System/StringException.cls8�
system.stubproviderStubProviderSystem *Sapexlib://resources/StandardApexLibrary/System/StubProvider.cls#System.StubProvider2?apexlib://resources/StandardApexLibrary/System/StubProvider.cls8�
system.systemSystemSystem *Gapexlib://resources/StandardApexLibrary/System/System.cls#System.System29apexlib://resources/StandardApexLibrary/System/System.cls8�
system.testTestSystem *Capexlib://resources/StandardApexLibrary/System/Test.cls#System.Test27apexlib://resources/StandardApexLibrary/System/Test.cls8�
system.timeTimeSystem *Capexlib://resources/StandardApexLibrary/System/Time.cls#System.Time27apexlib://resources/StandardApexLibrary/System/Time.cls8�
system.timezoneTimeZoneSystem *Kapexlib://resources/StandardApexLibrary/System/TimeZone.cls#System.TimeZone2;apexlib://resources/StandardApexLibrary/System/TimeZone.cls8�
system.transientcursorexceptionTransientCursorExceptionSystem *kapexlib://resources/StandardApexLibrary/System/TransientCursorException.cls#System.TransientCursorException2Kapexlib://resources/StandardApexLibrary/System/TransientCursorException.cls8�
system.triggerTriggerSystem *Iapexlib://resources/StandardApexLibrary/System/Trigger.cls#System.Trigger2:apexlib://resources/StandardApexLibrary/System/Trigger.cls8�
system.triggeroperationTriggerOperationSystem *[apexlib://resources/StandardApexLibrary/System/TriggerOperation.cls#System.TriggerOperation2Capexlib://resources/StandardApexLibrary/System/TriggerOperation.cls8�
system.typeTypeSystem *Capexlib://resources/StandardApexLibrary/System/Type.cls#System.Type27apexlib://resources/StandardApexLibrary/System/Type.cls8�
system.typeexceptionTypeExceptionSystem *Uapexlib://resources/StandardApexLibrary/System/TypeException.cls#System.TypeException2@apexlib://resources/StandardApexLibrary/System/TypeException.cls8�
system.uuidUUIDSystem *Capexlib://resources/StandardApexLibrary/System/UUID.cls#System.UUID27apexlib://resources/StandardApexLibrary/System/UUID.cls8�
system.unexpectedexceptionUnexpectedExceptionSystem *aapexlib://resources/StandardApexLibrary/System/UnexpectedException.cls#System.UnexpectedException2Fapexlib://resources/StandardApexLibrary/System/UnexpectedException.cls8�
system.uninstallhandlerUninstallHandlerSystem *[apexlib://resources/StandardApexLibrary/System/UninstallHandler.cls#System.UninstallHandler2Capexlib://resources/StandardApexLibrary/System/UninstallHandler.cls8�

system.urlURLSystem *Aapexlib://resources/StandardApexLibrary/System/Url.cls#System.URL26apexlib://resources/StandardApexLibrary/System/Url.cls8�
system.userinfoUserInfoSystem *Kapexlib://resources/StandardApexLibrary/System/UserInfo.cls#System.UserInfo2;apexlib://resources/StandardApexLibrary/System/UserInfo.cls8�
system.usermanagementUserManagementSystem *Wapexlib://resources/StandardApexLibrary/System/UserManagement.cls#System.UserManagement2Aapexlib://resources/StandardApexLibrary/System/UserManagement.cls8�
system.versionVersionSystem *Iapexlib://resources/StandardApexLibrary/System/Version.cls#System.Version2:apexlib://resources/StandardApexLibrary/System/Version.cls8�
system.visualforceexceptionVisualforceExceptionSystem *capexlib://resources/StandardApexLibrary/System/VisualforceException.cls#System.VisualforceException2Gapexlib://resources/StandardApexLibrary/System/VisualforceException.cls8�
system.webservicecalloutWebServiceCalloutSystem *]apexlib://resources/StandardApexLibrary/System/WebServiceCallout.cls#System.WebServiceCallout2Dapexlib://resources/StandardApexLibrary/System/WebServiceCallout.cls8�
system.webservicemockWebServiceMockSystem *Wapexlib://resources/StandardApexLibrary/System/WebServiceMock.cls#System.WebServiceMock2Aapexlib://resources/StandardApexLibrary/System/WebServiceMock.cls8�
system.xmlexceptionXmlExceptionSystem *Sapexlib://resources/StandardApexLibrary/System/XmlException.cls#System.XmlException2?apexlib://resources/StandardApexLibrary/System/XmlException.cls8�
system.xmlstreamwriterXmlStreamWriterSystem *Yapexlib://resources/StandardApexLibrary/System/XmlStreamWriter.cls#System.XmlStreamWriter2Bapexlib://resources/StandardApexLibrary/System/XmlStreamWriter.cls8�
system.blobBlobSystem *Capexlib://resources/StandardApexLibrary/System/Blob.cls#System.Blob27apexlib://resources/StandardApexLibrary/System/Blob.cls8�
system.datetimeDateTimeSystem *Kapexlib://resources/StandardApexLibrary/System/DateTime.cls#System.DateTime2;apexlib://resources/StandardApexLibrary/System/DateTime.cls8�
system.integerIntegerSystem *Iapexlib://resources/StandardApexLibrary/System/Integer.cls#System.Integer2:apexlib://resources/StandardApexLibrary/System/Integer.cls8�
system.longLongSystem *Capexlib://resources/StandardApexLibrary/System/Long.cls#System.Long27apexlib://resources/StandardApexLibrary/System/Long.cls8�
system.objectObjectSystem *Gapexlib://resources/StandardApexLibrary/System/Object.cls#System.Object29apexlib://resources/StandardApexLibrary/System/Object.cls8�
3territorymgmt.opportunityterritory2assignmentfilter%OpportunityTerritory2AssignmentFilterTerritoryMgmt *�apexlib://resources/StandardApexLibrary/TerritoryMgmt/OpportunityTerritory2AssignmentFilter.cls#TerritoryMgmt.OpportunityTerritory2AssignmentFilter2_apexlib://resources/StandardApexLibrary/TerritoryMgmt/OpportunityTerritory2AssignmentFilter.cls8�
txnsecurity.asyncconditionAsyncConditionTxnSecurity *aapexlib://resources/StandardApexLibrary/TxnSecurity/AsyncCondition.cls#TxnSecurity.AsyncCondition2Fapexlib://resources/StandardApexLibrary/TxnSecurity/AsyncCondition.cls8�
txnsecurity.eventEventTxnSecurity *Oapexlib://resources/StandardApexLibrary/TxnSecurity/Event.cls#TxnSecurity.Event2=apexlib://resources/StandardApexLibrary/TxnSecurity/Event.cls8�
txnsecurity.eventconditionEventConditionTxnSecurity *aapexlib://resources/StandardApexLibrary/TxnSecurity/EventCondition.cls#TxnSecurity.EventCondition2Fapexlib://resources/StandardApexLibrary/TxnSecurity/EventCondition.cls8�
txnsecurity.policyconditionPolicyConditionTxnSecurity *capexlib://resources/StandardApexLibrary/TxnSecurity/PolicyCondition.cls#TxnSecurity.PolicyCondition2Gapexlib://resources/StandardApexLibrary/TxnSecurity/PolicyCondition.cls8�
"userprovisioning.connectortestutilConnectorTestUtilUserProvisioning *qapexlib://resources/StandardApexLibrary/UserProvisioning/ConnectorTestUtil.cls#UserProvisioning.ConnectorTestUtil2Napexlib://resources/StandardApexLibrary/UserProvisioning/ConnectorTestUtil.cls8�
$userprovisioning.userprovisioninglogUserProvisioningLogUserProvisioning *uapexlib://resources/StandardApexLibrary/UserProvisioning/UserProvisioningLog.cls#UserProvisioning.UserProvisioningLog2Papexlib://resources/StandardApexLibrary/UserProvisioning/UserProvisioningLog.cls8�
'userprovisioning.userprovisioningpluginUserProvisioningPluginUserProvisioning *{apexlib://resources/StandardApexLibrary/UserProvisioning/UserProvisioningPlugin.cls#UserProvisioning.UserProvisioningPlugin2Sapexlib://resources/StandardApexLibrary/UserProvisioning/UserProvisioningPlugin.cls8�
visualeditor.datarowDataRowVisualEditor *Uapexlib://resources/StandardApexLibrary/VisualEditor/DataRow.cls#VisualEditor.DataRow2@apexlib://resources/StandardApexLibrary/VisualEditor/DataRow.cls8�
"visualeditor.designtimepagecontextDesignTimePageContextVisualEditor *qapexlib://resources/StandardApexLibrary/VisualEditor/DesignTimePageContext.cls#VisualEditor.DesignTimePageContext2Napexlib://resources/StandardApexLibrary/VisualEditor/DesignTimePageContext.cls8�
visualeditor.dynamicpicklistDynamicPickListVisualEditor *eapexlib://resources/StandardApexLibrary/VisualEditor/DynamicPickList.cls#VisualEditor.DynamicPickList2Hapexlib://resources/StandardApexLibrary/VisualEditor/DynamicPickList.cls8�
 visualeditor.dynamicpicklistrowsDynamicPickListRowsVisualEditor *mapexlib://resources/StandardApexLibrary/VisualEditor/DynamicPickListRows.cls#VisualEditor.DynamicPickListRows2Lapexlib://resources/StandardApexLibrary/VisualEditor/DynamicPickListRows.cls8�
wave.projectionnodeProjectionNodeWave *Sapexlib://resources/StandardApexLibrary/Wave/ProjectionNode.cls#Wave.ProjectionNode2?apexlib://resources/StandardApexLibrary/Wave/ProjectionNode.cls8�
wave.querybuilderQueryBuilderWave *Oapexlib://resources/StandardApexLibrary/Wave/QueryBuilder.cls#Wave.QueryBuilder2=apexlib://resources/StandardApexLibrary/Wave/QueryBuilder.cls8�
wave.querynode	QueryNodeWave *Iapexlib://resources/StandardApexLibrary/Wave/QueryNode.cls#Wave.QueryNode2:apexlib://resources/StandardApexLibrary/Wave/QueryNode.cls8�
wave.templates	TemplatesWave *Iapexlib://resources/StandardApexLibrary/Wave/Templates.cls#Wave.Templates2:apexlib://resources/StandardApexLibrary/Wave/Templates.cls8�
wave.templatessearchoptionsTemplatesSearchOptionsWave *capexlib://resources/StandardApexLibrary/Wave/TemplatesSearchOptions.cls#Wave.TemplatesSearchOptions2Gapexlib://resources/StandardApexLibrary/Wave/TemplatesSearchOptions.cls8�
embeddedai.apexmapApexMap
embeddedai *Qapexlib://resources/StandardApexLibrary/embeddedai/ApexMap.cls#embeddedai.ApexMap2>apexlib://resources/StandardApexLibrary/embeddedai/ApexMap.cls8�
#embeddedai.recordapexrepresentationRecordApexRepresentation
embeddedai *sapexlib://resources/StandardApexLibrary/embeddedai/RecordApexRepresentation.cls#embeddedai.RecordApexRepresentation2Oapexlib://resources/StandardApexLibrary/embeddedai/RecordApexRepresentation.cls8�
flowuiruntime.toastlink	ToastLinkflowuiruntime *[apexlib://resources/StandardApexLibrary/flowuiruntime/ToastLink.cls#flowuiruntime.ToastLink2Capexlib://resources/StandardApexLibrary/flowuiruntime/ToastLink.cls8�
fsccashflow.fsccashflowutilFSCCashFlowUtilfsccashflow *capexlib://resources/StandardApexLibrary/fsccashflow/FSCCashFlowUtil.cls#fsccashflow.FSCCashFlowUtil2Gapexlib://resources/StandardApexLibrary/fsccashflow/FSCCashFlowUtil.cls8�
industriesnlpsvc.nlpresponseNlpResponseindustriesNlpSvc *eapexlib://resources/StandardApexLibrary/industriesNlpSvc/NlpResponse.cls#industriesNlpSvc.NlpResponse2Hapexlib://resources/StandardApexLibrary/industriesNlpSvc/NlpResponse.cls8�
'industriesnlpsvc.nlpsummarizationresultNlpSummarizationResultindustriesNlpSvc *{apexlib://resources/StandardApexLibrary/industriesNlpSvc/NlpSummarizationResult.cls#industriesNlpSvc.NlpSummarizationResult2Sapexlib://resources/StandardApexLibrary/industriesNlpSvc/NlpSummarizationResult.cls8�
ise_bots_apex.dynamicmenuitemDynamicMenuItemise_bots_apex *gapexlib://resources/StandardApexLibrary/ise_bots_apex/DynamicMenuItem.cls#ise_bots_apex.DynamicMenuItem2Iapexlib://resources/StandardApexLibrary/ise_bots_apex/DynamicMenuItem.cls8�
*sfdc_surveys.surveyinvitationlinkshortenerSurveyInvitationLinkShortenersfdc_surveys *�apexlib://resources/StandardApexLibrary/sfdc_surveys/SurveyInvitationLinkShortener.cls#sfdc_surveys.SurveyInvitationLinkShortener2Vapexlib://resources/StandardApexLibrary/sfdc_surveys/SurveyInvitationLinkShortener.cls8